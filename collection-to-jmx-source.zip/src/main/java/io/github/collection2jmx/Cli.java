package io.github.collection2jmx;

import io.github.collection2jmx.jmx.JmxGenerator;
import io.github.collection2jmx.model.ApiCollection;
import io.github.collection2jmx.parser.CollectionParser;

import java.io.File;

/**
 * Command line conversion, handy for CI:
 * <pre>java -cp "collection-importer.jar:$JMETER_HOME/lib/*" io.github.collection2jmx.Cli collection.json [-e env.json] [-o plan.jmx] [-t recording.jmx]</pre>
 */
public final class Cli {

    private Cli() {
    }

    public static void main(String[] args) {
        try {
            System.exit(run(args));
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(1);
        }
    }

    static int run(String[] args) throws Exception {
        File input = null;
        File env = null;
        File output = null;
        File template = null;
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (("-e".equals(a) || "--env".equals(a)) && i + 1 < args.length) {
                env = new File(args[++i]);
            } else if (("-o".equals(a) || "--output".equals(a)) && i + 1 < args.length) {
                output = new File(args[++i]);
            } else if (("-t".equals(a) || "--template".equals(a)) && i + 1 < args.length) {
                template = new File(args[++i]);
            } else if (a.startsWith("-")) {
                return usage();
            } else {
                input = new File(a);
            }
        }
        if (input == null) {
            return usage();
        }
        ApiCollection collection = CollectionParser.parse(input);
        if (env != null) {
            CollectionParser.applyEnvironment(collection, env);
        }
        if (output == null) {
            output = new File(input.getAbsoluteFile().getParentFile(), baseNameOf(input.getName()) + ".jmx");
        }
        JmxGenerator generator = template != null ? new JmxGenerator(template)
                : JmxGenerator.forJMeterHome(System.getenv("JMETER_HOME"));
        generator.write(collection, output);
        System.out.println("Converted " + collection.getRequests().size() + " requests from "
                + collection.getFormat() + " collection '" + collection.getName() + "' to " + output);
        for (String w : collection.getWarnings()) {
            System.out.println("  warning: " + w);
        }
        return 0;
    }

    public static String baseNameOf(String fileName) {
        String n = fileName.replaceAll("(?i)\\.(postman_collection\\.json|json|ya?ml)$", "");
        return n.isEmpty() ? "collection" : n;
    }

    private static int usage() {
        System.err.println("Usage: Cli <collection.json|yaml> [-e postman_environment.json] [-o output.jmx] [-t recording.jmx]");
        return 2;
    }
}
