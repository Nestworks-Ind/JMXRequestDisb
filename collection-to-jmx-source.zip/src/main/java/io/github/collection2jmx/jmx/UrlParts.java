package io.github.collection2jmx.jmx;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Splits a (possibly variable based) URL into the fields of a JMeter HTTP sampler. */
final class UrlParts {

    private static final Pattern SCHEME = Pattern.compile("^(?i)(https?)://");
    private static final Pattern LEADING_VAR = Pattern.compile("^\\$\\{([^}]+)}");

    String protocol = "";
    String domain = "";
    String port = "";
    String path = "";

    static UrlParts parse(String url, Map<String, String> variables) {
        UrlParts p = new UrlParts();
        String u = url == null ? "" : url.trim();
        Matcher scheme = SCHEME.matcher(u);
        if (scheme.find()) {
            p.protocol = scheme.group(1).toLowerCase();
            p.splitAuthority(u.substring(scheme.end()));
            return p;
        }
        Matcher var = LEADING_VAR.matcher(u);
        if (var.find()) {
            String value = variables.get(var.group(1));
            boolean valueIsHostOnly = value != null && !value.isEmpty() && !SCHEME.matcher(value).find()
                    && !value.startsWith("${") && !value.contains("/");
            if (valueIsHostOnly) {
                // e.g. {{host}}/api with host=api.example.com -> domain ${host}
                p.protocol = "https";
                p.splitAuthority(u);
            } else {
                // ${baseUrl}/users: JMeter treats an absolute path (after substitution) as the full URL
                p.path = u;
            }
            return p;
        }
        if (u.startsWith("/") || u.isEmpty()) {
            p.path = u;
            return p;
        }
        // "example.com/path": Postman assumes http
        p.protocol = "http";
        p.splitAuthority(u);
        return p;
    }

    private void splitAuthority(String rest) {
        int end = rest.length();
        for (int i = 0; i < rest.length(); i++) {
            char c = rest.charAt(i);
            if (c == '$' && i + 1 < rest.length() && rest.charAt(i + 1) == '{') {
                int close = rest.indexOf('}', i);
                if (close > 0) {
                    i = close;
                    continue;
                }
            }
            if (c == '/' || c == '?' || c == '#') {
                end = i;
                break;
            }
        }
        String authority = rest.substring(0, end);
        String remainder = rest.substring(end);
        int at = authority.lastIndexOf('@');
        if (at >= 0) {
            authority = authority.substring(at + 1);
        }
        int colon = portSeparator(authority);
        if (colon > 0) {
            port = authority.substring(colon + 1);
            domain = authority.substring(0, colon);
        } else {
            domain = authority;
        }
        int hash = remainder.indexOf('#');
        if (hash >= 0) {
            remainder = remainder.substring(0, hash);
        }
        path = remainder.isEmpty() ? "/" : remainder;
        if (path.startsWith("?")) {
            path = "/" + path;
        }
    }

    /** Index of the ':' before the port, ignoring colons inside ${...} and IPv6 brackets; -1 if none. */
    private static int portSeparator(String authority) {
        int depth = 0;
        boolean inBrackets = false;
        int found = -1;
        for (int i = 0; i < authority.length(); i++) {
            char c = authority.charAt(i);
            if (c == '{') {
                depth++;
            } else if (c == '}') {
                depth = Math.max(0, depth - 1);
            } else if (c == '[') {
                inBrackets = true;
            } else if (c == ']') {
                inBrackets = false;
            } else if (c == ':' && depth == 0 && !inBrackets) {
                found = i;
            }
        }
        return found;
    }

    boolean isAbsolutePath() {
        return protocol.isEmpty() && domain.isEmpty() && path.startsWith("${");
    }
}
