package io.github.collection2jmx.jmx;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.github.collection2jmx.model.ApiCollection;
import io.github.collection2jmx.model.ApiRequest;
import io.github.collection2jmx.model.BodyType;
import io.github.collection2jmx.model.FormField;
import io.github.collection2jmx.model.KeyValue;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Builds a JMeter test plan from JMeter's "Recording" template: every request of the collection is
 * placed in its own Simple Controller under the Thread Group.
 */
public final class JmxGenerator {

    /** Template bundled in the plugin JAR (copy of JMeter 5.6.3 bin/templates/recording.jmx). */
    public static final String BUNDLED_TEMPLATE = "/io/github/collection2jmx/recording.jmx";

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private final File templateFile;

    /** @param templateFile recording template to use, or null for the bundled copy */
    public JmxGenerator(File templateFile) {
        this.templateFile = templateFile;
    }

    /** Uses JMETER_HOME/bin/templates/recording.jmx when it exists, otherwise the bundled template. */
    public static JmxGenerator forJMeterHome(String jmeterHome) {
        if (jmeterHome != null && !jmeterHome.isEmpty()) {
            File f = new File(new File(new File(jmeterHome, "bin"), "templates"), "recording.jmx");
            if (f.isFile()) {
                return new JmxGenerator(f);
            }
        }
        return new JmxGenerator(null);
    }

    public void write(ApiCollection collection, File output) throws IOException {
        File parent = output.getAbsoluteFile().getParentFile();
        if (parent != null) {
            Files.createDirectories(parent.toPath());
        }
        try (OutputStream out = Files.newOutputStream(output.toPath())) {
            out.write(generate(collection).getBytes(StandardCharsets.UTF_8));
        }
    }

    public String generate(ApiCollection collection) throws IOException {
        HostDefaults defaults = HostDefaults.of(collection);
        Document doc = parse(fillTemplateParameters(loadTemplate(), defaults));
        Element rootTree = firstChildElement(doc.getDocumentElement(), "hashTree");
        Element testPlan = firstChildElement(rootTree, "TestPlan");
        if (testPlan == null) {
            throw new IOException("Template has no TestPlan element");
        }
        testPlan.setAttribute("testname", collection.getName());
        Element planTree = nextHashTree(testPlan);

        addCollectionVariables(doc, planTree, collection);

        Element threadGroup = firstChildElement(planTree, "ThreadGroup");
        if (threadGroup == null) {
            throw new IOException("Template has no Thread Group under the Test Plan");
        }
        Element tgTree = nextHashTree(threadGroup);
        removeRecordingController(tgTree);

        for (ApiRequest request : collection.getRequests()) {
            Element controller = el(doc, "GenericController");
            controller.setAttribute("guiclass", "LogicControllerGui");
            controller.setAttribute("testclass", "GenericController");
            controller.setAttribute("testname", request.getDisplayPath());
            controller.setAttribute("enabled", "true");
            tgTree.appendChild(controller);
            Element controllerTree = el(doc, "hashTree");
            tgTree.appendChild(controllerTree);

            controllerTree.appendChild(sampler(doc, request, defaults, collection));
            Element samplerTree = el(doc, "hashTree");
            controllerTree.appendChild(samplerTree);
            List<KeyValue> headers = headersFor(request);
            if (!headers.isEmpty()) {
                samplerTree.appendChild(headerManager(doc, headers));
                samplerTree.appendChild(el(doc, "hashTree"));
            }
        }
        return serialize(doc);
    }

    // ------------------------------------------------------------------ template

    private String loadTemplate() throws IOException {
        if (templateFile != null) {
            return new String(Files.readAllBytes(templateFile.toPath()), StandardCharsets.UTF_8);
        }
        try (InputStream in = JmxGenerator.class.getResourceAsStream(BUNDLED_TEMPLATE)) {
            if (in == null) {
                throw new IOException("Bundled recording template not found");
            }
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) {
                bos.write(buf, 0, n);
            }
            return new String(bos.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    /** The template uses FreeMarker style parameters, filled the way JMeter's template dialog would. */
    private static String fillTemplateParameters(String template, HostDefaults defaults) {
        return template
                .replace("[=hostToRecord]", xmlEscape(defaults.domain))
                .replace("[=schemeToRecord]", xmlEscape(defaults.protocol.isEmpty() ? "https" : defaults.protocol))
                .replace("[=recordingOutputFile]", "recording.xml");
    }

    private static void addCollectionVariables(Document doc, Element planTree, ApiCollection collection) {
        if (collection.getVariables().isEmpty()) {
            return;
        }
        Element args = el(doc, "Arguments");
        args.setAttribute("guiclass", "ArgumentsPanel");
        args.setAttribute("testclass", "Arguments");
        args.setAttribute("testname", "Collection Variables");
        args.setAttribute("enabled", "true");
        Element coll = collectionProp(doc, "Arguments.arguments");
        args.appendChild(coll);
        for (Map.Entry<String, String> v : collection.getVariables().entrySet()) {
            Element arg = elementProp(doc, v.getKey(), "Argument");
            arg.appendChild(stringProp(doc, "Argument.name", v.getKey()));
            arg.appendChild(stringProp(doc, "Argument.value", v.getValue()));
            arg.appendChild(stringProp(doc, "Argument.metadata", "="));
            coll.appendChild(arg);
        }
        // After the template's own "User Defined Variables" so that collection values take precedence
        Element templateArgs = firstChildElement(planTree, "Arguments");
        Node insertBefore = templateArgs != null ? nextHashTree(templateArgs).getNextSibling() : planTree.getFirstChild();
        planTree.insertBefore(args, insertBefore);
        planTree.insertBefore(el(doc, "hashTree"), insertBefore);
    }

    private static void removeRecordingController(Element tgTree) {
        Element rc = firstChildElement(tgTree, "RecordingController");
        if (rc != null) {
            Element rcTree = nextHashTree(rc);
            tgTree.removeChild(rc);
            if (rcTree != null) {
                tgTree.removeChild(rcTree);
            }
        }
    }

    // ------------------------------------------------------------------ samplers

    private static Element sampler(Document doc, ApiRequest r, HostDefaults defaults, ApiCollection collection) {
        boolean graphql = r.getBodyType() == BodyType.GRAPHQL;
        boolean graphqlGet = graphql && "GET".equals(r.getMethod());
        String method = graphql && !graphqlGet ? "POST" : r.getMethod();

        Element s = el(doc, "HTTPSamplerProxy");
        s.setAttribute("guiclass", graphql ? "GraphQLHTTPSamplerGui" : "HttpTestSampleGui");
        s.setAttribute("testclass", "HTTPSamplerProxy");
        s.setAttribute("testname", r.getName());
        s.setAttribute("enabled", "true");
        if (!r.getDescription().isEmpty()) {
            s.appendChild(stringProp(doc, "TestPlan.comments", r.getDescription()));
        }

        Element args = elementProp(doc, "HTTPsampler.Arguments", "Arguments");
        Element argList = collectionProp(doc, "Arguments.arguments");
        args.appendChild(argList);
        boolean rawBody = false;
        boolean multipart = false;
        List<FormField> files = new ArrayList<>();

        switch (r.getBodyType()) {
            case RAW:
                rawBody = true;
                argList.appendChild(httpArgument(doc, "", r.getRawBody(), false));
                break;
            case URLENCODED:
                for (KeyValue kv : r.getUrlEncodedParams()) {
                    argList.appendChild(httpArgument(doc, kv.getKey(), kv.getValue(), true));
                }
                break;
            case MULTIPART:
                multipart = true;
                for (FormField f : r.getFormFields()) {
                    if (f.isFile()) {
                        files.add(f);
                    } else {
                        argList.appendChild(httpArgument(doc, f.getName(), f.getValue(), false));
                    }
                }
                break;
            case FILE:
                files.add(new FormField("", r.getBodyFilePath(), true, header(r, "Content-Type")));
                break;
            case GRAPHQL:
                if (graphqlGet) {
                    argList.appendChild(httpArgument(doc, "query", r.getGraphqlQuery(), true));
                    if (!r.getGraphqlOperationName().isEmpty()) {
                        argList.appendChild(httpArgument(doc, "operationName", r.getGraphqlOperationName(), true));
                    }
                    if (!r.getGraphqlVariables().isEmpty()) {
                        argList.appendChild(httpArgument(doc, "variables", compactJson(r.getGraphqlVariables()), true));
                    }
                } else {
                    rawBody = true;
                    argList.appendChild(httpArgument(doc, "", graphqlBody(r), false));
                }
                break;
            default:
                break;
        }
        if (rawBody) {
            s.appendChild(boolProp(doc, "HTTPSampler.postBodyRaw", true));
        } else {
            args.setAttribute("guiclass", "HTTPArgumentsPanel");
            args.setAttribute("testclass", "Arguments");
            args.setAttribute("testname", "User Defined Variables");
        }
        s.appendChild(args);

        if (!files.isEmpty()) {
            Element fileArgs = elementProp(doc, "HTTPsampler.Files", "HTTPFileArgs");
            Element fileList = collectionProp(doc, "HTTPFileArgs.files");
            fileArgs.appendChild(fileList);
            for (FormField f : files) {
                Element fa = elementProp(doc, f.getValue(), "HTTPFileArg");
                fa.appendChild(stringProp(doc, "File.path", f.getValue()));
                fa.appendChild(stringProp(doc, "File.paramname", f.getName()));
                fa.appendChild(stringProp(doc, "File.mimetype",
                        f.getContentType().isEmpty() ? "application/octet-stream" : f.getContentType()));
                fileList.appendChild(fa);
            }
            s.appendChild(fileArgs);
            if (r.getBodyType() == BodyType.MULTIPART || r.getBodyType() == BodyType.FILE) {
                for (FormField f : files) {
                    if (f.getValue().isEmpty()) {
                        collection.getWarnings().add("'" + r.getDisplayPath()
                                + "': file upload has no file path, set it in the sampler's Files Upload tab");
                    }
                }
            }
        }

        UrlParts url = UrlParts.parse(r.getUrl(), collection.getVariables());
        boolean useDefaults = defaults.matches(url);
        s.appendChild(stringProp(doc, "HTTPSampler.domain", useDefaults ? "" : url.domain));
        s.appendChild(stringProp(doc, "HTTPSampler.port", useDefaults ? "" : url.port));
        s.appendChild(stringProp(doc, "HTTPSampler.protocol", useDefaults ? "" : url.protocol));
        s.appendChild(stringProp(doc, "HTTPSampler.contentEncoding", "UTF-8"));
        s.appendChild(stringProp(doc, "HTTPSampler.path", url.path));
        s.appendChild(stringProp(doc, "HTTPSampler.method", method));
        s.appendChild(boolProp(doc, "HTTPSampler.follow_redirects", true));
        s.appendChild(boolProp(doc, "HTTPSampler.auto_redirects", false));
        s.appendChild(boolProp(doc, "HTTPSampler.use_keepalive", true));
        s.appendChild(boolProp(doc, "HTTPSampler.DO_MULTIPART_POST", multipart));
        s.appendChild(stringProp(doc, "HTTPSampler.embedded_url_re", ""));
        s.appendChild(stringProp(doc, "HTTPSampler.connect_timeout", ""));
        s.appendChild(stringProp(doc, "HTTPSampler.response_timeout", ""));
        if (graphql) {
            // Read back by the GraphQL HTTP Request GUI
            s.appendChild(stringProp(doc, "GraphQLHTTPSampler.operationName", r.getGraphqlOperationName()));
            s.appendChild(stringProp(doc, "GraphQLHTTPSampler.query", r.getGraphqlQuery()));
            s.appendChild(stringProp(doc, "GraphQLHTTPSampler.variables", r.getGraphqlVariables()));
        }
        return s;
    }

    /** Same JSON envelope JMeter's GraphQL sampler sends: {"operationName":..,"variables":..,"query":..} */
    static String graphqlBody(ApiRequest r) {
        StringBuilder sb = new StringBuilder("{");
        sb.append("\"operationName\":");
        sb.append(r.getGraphqlOperationName().isEmpty() ? "null" : jsonString(r.getGraphqlOperationName()));
        sb.append(",\"variables\":");
        String vars = r.getGraphqlVariables().trim();
        // Variables may contain unquoted ${...} placeholders, so they are inserted as-is rather than re-encoded
        sb.append(vars.isEmpty() ? "{}" : compactJson(vars));
        sb.append(",\"query\":").append(jsonString(r.getGraphqlQuery()));
        sb.append('}');
        return sb.toString();
    }

    private static String compactJson(String json) {
        try {
            JsonNode node = MAPPER.readTree(json);
            return node == null ? json : MAPPER.writeValueAsString(node);
        } catch (Exception e) {
            return json;
        }
    }

    private static String jsonString(String s) {
        try {
            return MAPPER.writeValueAsString(s);
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    private static List<KeyValue> headersFor(ApiRequest r) {
        List<KeyValue> headers = new ArrayList<>();
        for (KeyValue h : r.getHeaders()) {
            boolean contentType = h.getKey().equalsIgnoreCase("Content-Type");
            if (contentType && r.getBodyType() == BodyType.MULTIPART) {
                continue; // JMeter must generate the multipart boundary itself
            }
            headers.add(h);
        }
        if (r.getBodyType() == BodyType.GRAPHQL && !"GET".equals(r.getMethod()) && !r.hasHeader("Content-Type")) {
            headers.add(new KeyValue("Content-Type", "application/json"));
        }
        return headers;
    }

    private static String header(ApiRequest r, String name) {
        for (KeyValue h : r.getHeaders()) {
            if (h.getKey().equalsIgnoreCase(name)) {
                return h.getValue();
            }
        }
        return "";
    }

    private static Element headerManager(Document doc, List<KeyValue> headers) {
        Element hm = el(doc, "HeaderManager");
        hm.setAttribute("guiclass", "HeaderPanel");
        hm.setAttribute("testclass", "HeaderManager");
        hm.setAttribute("testname", "HTTP Header Manager");
        hm.setAttribute("enabled", "true");
        Element list = collectionProp(doc, "HeaderManager.headers");
        hm.appendChild(list);
        for (KeyValue h : headers) {
            Element e = elementProp(doc, "", "Header");
            e.appendChild(stringProp(doc, "Header.name", h.getKey()));
            e.appendChild(stringProp(doc, "Header.value", h.getValue()));
            list.appendChild(e);
        }
        return hm;
    }

    private static Element httpArgument(Document doc, String name, String value, boolean encode) {
        Element arg = elementProp(doc, name, "HTTPArgument");
        arg.appendChild(boolProp(doc, "HTTPArgument.always_encode", encode));
        arg.appendChild(stringProp(doc, "Argument.value", value));
        arg.appendChild(stringProp(doc, "Argument.metadata", "="));
        if (!name.isEmpty()) {
            arg.appendChild(boolProp(doc, "HTTPArgument.use_equals", true));
            arg.appendChild(stringProp(doc, "Argument.name", name));
        }
        return arg;
    }

    // ------------------------------------------------------------------ host defaults

    /** The most used scheme/host/port becomes the template's HTTP Request Defaults, like a recording would. */
    static final class HostDefaults {
        String protocol = "";
        String domain = "";
        String port = "";

        static HostDefaults of(ApiCollection collection) {
            Map<String, Integer> counts = new HashMap<>();
            Map<String, UrlParts> samples = new HashMap<>();
            String best = null;
            for (ApiRequest r : collection.getRequests()) {
                UrlParts u = UrlParts.parse(r.getUrl(), collection.getVariables());
                if (u.domain.isEmpty() || !u.port.isEmpty() || u.domain.contains("${")) {
                    continue;
                }
                String key = u.protocol + "://" + u.domain;
                int c = counts.merge(key, 1, Integer::sum);
                samples.put(key, u);
                if (best == null || c > counts.get(best)) {
                    best = key;
                }
            }
            HostDefaults d = new HostDefaults();
            if (best != null) {
                d.protocol = samples.get(best).protocol;
                d.domain = samples.get(best).domain;
            }
            return d;
        }

        boolean matches(UrlParts u) {
            return !domain.isEmpty() && domain.equalsIgnoreCase(u.domain) && protocol.equals(u.protocol)
                    && u.port.isEmpty();
        }
    }

    // ------------------------------------------------------------------ DOM helpers

    private static Document parse(String xml) throws IOException {
        try {
            DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
            f.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            f.setExpandEntityReferences(false);
            DocumentBuilder b = f.newDocumentBuilder();
            Document doc = b.parse(new InputSource(new StringReader(xml)));
            stripWhitespace(doc.getDocumentElement());
            return doc;
        } catch (Exception e) {
            throw new IOException("Cannot read the recording template: " + e.getMessage(), e);
        }
    }

    private static void stripWhitespace(Node node) {
        NodeList children = node.getChildNodes();
        for (int i = children.getLength() - 1; i >= 0; i--) {
            Node c = children.item(i);
            if (c.getNodeType() == Node.TEXT_NODE && c.getTextContent().trim().isEmpty()
                    && node.getChildNodes().getLength() > 1) {
                node.removeChild(c);
            } else if (c.getNodeType() == Node.ELEMENT_NODE) {
                stripWhitespace(c);
            }
        }
    }

    /** Writes the document the way JMeter formats .jmx files (2-space indent, one element per line). */
    private static String serialize(Document doc) {
        StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        write(doc.getDocumentElement(), 0, sb);
        return sb.toString();
    }

    private static void write(Element e, int depth, StringBuilder sb) {
        indent(sb, depth);
        sb.append('<').append(e.getTagName());
        NamedNodeMap attrs = e.getAttributes();
        for (String name : attributeOrder(attrs)) {
            sb.append(' ').append(name).append("=\"").append(escape(e.getAttribute(name), true)).append('"');
        }
        List<Element> children = new ArrayList<>();
        for (Node n = e.getFirstChild(); n != null; n = n.getNextSibling()) {
            if (n.getNodeType() == Node.ELEMENT_NODE) {
                children.add((Element) n);
            }
        }
        if (!children.isEmpty()) {
            sb.append(">\n");
            for (Element c : children) {
                write(c, depth + 1, sb);
            }
            indent(sb, depth);
            sb.append("</").append(e.getTagName()).append(">\n");
        } else {
            String text = e.getTextContent();
            if ((text == null || text.isEmpty()) && !"stringProp".equals(e.getTagName())) {
                sb.append("/>\n");
            } else {
                sb.append('>').append(escape(text == null ? "" : text, false)).append("</").append(e.getTagName()).append(">\n");
            }
        }
    }

    /** Keeps JMeter's usual attribute order: name/elementType/guiclass/testclass/testname/enabled first. */
    private static List<String> attributeOrder(NamedNodeMap attrs) {
        List<String> preferred = java.util.Arrays.asList("name", "elementType", "guiclass", "testclass", "testname",
                "enabled", "version", "properties", "jmeter");
        List<String> names = new ArrayList<>();
        for (String p : preferred) {
            if (attrs.getNamedItem(p) != null) {
                names.add(p);
            }
        }
        for (int i = 0; i < attrs.getLength(); i++) {
            String n = attrs.item(i).getNodeName();
            if (!names.contains(n)) {
                names.add(n);
            }
        }
        return names;
    }

    private static void indent(StringBuilder sb, int depth) {
        for (int i = 0; i < depth; i++) {
            sb.append("  ");
        }
    }

    private static String escape(String s, boolean attribute) {
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '&':
                    sb.append("&amp;");
                    break;
                case '<':
                    sb.append("&lt;");
                    break;
                case '>':
                    sb.append("&gt;");
                    break;
                case '"':
                    sb.append(attribute ? "&quot;" : "\"");
                    break;
                case '\n':
                    sb.append(attribute ? "&#10;" : "\n");
                    break;
                case '\r':
                    sb.append("&#13;");
                    break;
                case '\t':
                    sb.append(attribute ? "&#9;" : "\t");
                    break;
                default:
                    if (c < 0x20) {
                        break; // not allowed in XML 1.0
                    }
                    sb.append(c);
            }
        }
        return sb.toString();
    }

    private static Element firstChildElement(Element parent, String tag) {
        if (parent == null) {
            return null;
        }
        for (Node n = parent.getFirstChild(); n != null; n = n.getNextSibling()) {
            if (n.getNodeType() == Node.ELEMENT_NODE && tag.equals(n.getNodeName())) {
                return (Element) n;
            }
        }
        return null;
    }

    /** In a JMX file each element is followed by the hashTree holding its children. */
    private static Element nextHashTree(Element element) {
        for (Node n = element.getNextSibling(); n != null; n = n.getNextSibling()) {
            if (n.getNodeType() == Node.ELEMENT_NODE) {
                return "hashTree".equals(n.getNodeName()) ? (Element) n : null;
            }
        }
        return null;
    }

    private static Element el(Document doc, String tag) {
        return doc.createElement(tag);
    }

    private static Element stringProp(Document doc, String name, String value) {
        Element e = doc.createElement("stringProp");
        e.setAttribute("name", name);
        e.setTextContent(value == null ? "" : value);
        return e;
    }

    private static Element boolProp(Document doc, String name, boolean value) {
        Element e = doc.createElement("boolProp");
        e.setAttribute("name", name);
        e.setTextContent(Boolean.toString(value));
        return e;
    }

    private static Element elementProp(Document doc, String name, String type) {
        Element e = doc.createElement("elementProp");
        e.setAttribute("name", name);
        e.setAttribute("elementType", type);
        return e;
    }

    private static Element collectionProp(Document doc, String name) {
        Element e = doc.createElement("collectionProp");
        e.setAttribute("name", name);
        return e;
    }

    private static String xmlEscape(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }
}
