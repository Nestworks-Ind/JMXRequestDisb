package io.github.collection2jmx.gui;

import org.apache.jmeter.gui.plugin.MenuCreator;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.MenuElement;

/**
 * Discovered by JMeter at start-up (any class in lib/ext implementing MenuCreator) and adds
 * "Tools &gt; Import from Postman / Insomnia collection...".
 */
public class CollectionImportMenuCreator implements MenuCreator {

    static final String MENU_TEXT = "Import from Postman / Insomnia collection...";

    @Override
    public JMenuItem[] getMenuItemsAtLocation(MENU_LOCATION location) {
        if (location != MENU_LOCATION.TOOLS) {
            return new JMenuItem[0];
        }
        JMenuItem item = new JMenuItem(MENU_TEXT);
        item.setName(CollectionImportMenuCreator.class.getName());
        item.addActionListener(e -> ImportDialog.showDialog());
        return new JMenuItem[]{item};
    }

    @Override
    public JMenu[] getTopLevelMenus() {
        return new JMenu[0];
    }

    @Override
    public boolean localeChanged(MenuElement menu) {
        return false;
    }

    @Override
    public void localeChanged() {
        // Menu text is not localised
    }
}
