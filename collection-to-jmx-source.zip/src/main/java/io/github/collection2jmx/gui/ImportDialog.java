package io.github.collection2jmx.gui;

import io.github.collection2jmx.Cli;
import io.github.collection2jmx.jmx.JmxGenerator;
import io.github.collection2jmx.model.ApiCollection;
import io.github.collection2jmx.parser.CollectionParser;
import org.apache.jmeter.gui.GuiPackage;
import org.apache.jmeter.gui.action.Load;
import org.apache.jmeter.gui.util.FileDialoger;
import org.apache.jmeter.save.SaveService;
import org.apache.jmeter.services.FileServer;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jorphan.collections.HashTree;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.io.File;
import java.util.List;

/** Dialog to pick a collection, convert it and open the generated test plan in JMeter. */
public final class ImportDialog extends JDialog {

    private static final long serialVersionUID = 1L;
    private static final Logger log = LoggerFactory.getLogger(ImportDialog.class);

    private final JTextField collectionField = new JTextField(40);
    private final JTextField environmentField = new JTextField(40);
    private final JTextField outputField = new JTextField(40);
    private final JRadioButton openNew = new JRadioButton("Open as a new test plan", true);
    private final JRadioButton merge = new JRadioButton("Merge into the current test plan");

    private ImportDialog(Frame owner) {
        super(owner, "Import Postman / Insomnia collection", true);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createEmptyBorder(10, 10, 4, 10));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(4, 4, 4, 4);
        c.anchor = GridBagConstraints.WEST;

        addRow(form, c, 0, "Collection file (Postman v2.x / Insomnia v4, v5):", collectionField,
                () -> chooseInput(collectionField, true));
        addRow(form, c, 1, "Postman environment (optional):", environmentField,
                () -> chooseInput(environmentField, false));
        addRow(form, c, 2, "Save test plan as:", outputField, this::chooseOutput);

        ButtonGroup group = new ButtonGroup();
        group.add(openNew);
        group.add(merge);
        JPanel modes = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        modes.add(openNew);
        modes.add(merge);
        c.gridx = 1;
        c.gridy = 3;
        c.gridwidth = 2;
        form.add(modes, c);

        JLabel hint = new JLabel("<html>The plan is built from the Recording template: each API is placed in its own "
                + "Simple Controller under the Thread Group;<br>GraphQL calls use GraphQL HTTP Request samplers.</html>");
        c.gridy = 4;
        form.add(hint, c);

        JButton convert = new JButton("Import");
        convert.addActionListener(this::doImport);
        JButton cancel = new JButton("Cancel");
        cancel.addActionListener(e -> dispose());
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttons.add(convert);
        buttons.add(cancel);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(form, BorderLayout.CENTER);
        getContentPane().add(buttons, BorderLayout.SOUTH);
        getRootPane().setDefaultButton(convert);
        pack();
        setLocationRelativeTo(owner);
    }

    static void showDialog() {
        GuiPackage gui = GuiPackage.getInstance();
        Frame owner = gui == null ? null : gui.getMainFrame();
        new ImportDialog(owner).setVisible(true);
    }

    private static void addRow(JPanel form, GridBagConstraints c, int row, String label, JTextField field,
                               Runnable browse) {
        c.gridwidth = 1;
        c.gridy = row;
        c.gridx = 0;
        c.fill = GridBagConstraints.NONE;
        c.weightx = 0;
        form.add(new JLabel(label), c);
        c.gridx = 1;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1;
        form.add(field, c);
        c.gridx = 2;
        c.fill = GridBagConstraints.NONE;
        c.weightx = 0;
        JButton b = new JButton("Browse...");
        b.addActionListener(e -> browse.run());
        form.add(b, c);
    }

    private void chooseInput(JTextField target, boolean isCollection) {
        JFileChooser chooser = new JFileChooser(startDir());
        chooser.setFileFilter(new FileNameExtensionFilter("Collections (*.json, *.yaml, *.yml)", "json", "yaml", "yml"));
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File f = chooser.getSelectedFile();
            target.setText(f.getAbsolutePath());
            FileDialoger.setLastJFCDirectory(f.getParent());
            if (isCollection && outputField.getText().trim().isEmpty()) {
                outputField.setText(new File(f.getParentFile(), Cli.baseNameOf(f.getName()) + ".jmx").getAbsolutePath());
            }
        }
    }

    private void chooseOutput() {
        JFileChooser chooser = new JFileChooser(startDir());
        chooser.setFileFilter(new FileNameExtensionFilter("JMeter test plan (*.jmx)", "jmx"));
        if (!outputField.getText().trim().isEmpty()) {
            chooser.setSelectedFile(new File(outputField.getText().trim()));
        }
        if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            String path = chooser.getSelectedFile().getAbsolutePath();
            outputField.setText(path.toLowerCase().endsWith(".jmx") ? path : path + ".jmx");
        }
    }

    private static File startDir() {
        String last = FileDialoger.getLastJFCDirectory();
        return last == null ? new File(System.getProperty("user.dir")) : new File(last);
    }

    private void doImport(ActionEvent event) {
        String in = collectionField.getText().trim();
        if (in.isEmpty() || !new File(in).isFile()) {
            JOptionPane.showMessageDialog(this, "Choose the collection file to import.", getTitle(),
                    JOptionPane.WARNING_MESSAGE);
            return;
        }
        File input = new File(in);
        String out = outputField.getText().trim();
        File output = out.isEmpty() ? new File(input.getAbsoluteFile().getParentFile(), Cli.baseNameOf(input.getName()) + ".jmx")
                : new File(out.toLowerCase().endsWith(".jmx") ? out : out + ".jmx");
        if (output.exists() && JOptionPane.showConfirmDialog(this, output.getName() + " already exists. Replace it?",
                getTitle(), JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) {
            return;
        }
        boolean merging = merge.isSelected();
        GuiPackage gui = GuiPackage.getInstance();
        if (!merging && gui != null && gui.isDirty() && JOptionPane.showConfirmDialog(this,
                "The current test plan has unsaved changes that will be lost. Continue?", getTitle(),
                JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) != JOptionPane.YES_OPTION) {
            return;
        }

        ApiCollection collection;
        try {
            collection = CollectionParser.parse(input);
            String env = environmentField.getText().trim();
            if (!env.isEmpty()) {
                CollectionParser.applyEnvironment(collection, new File(env));
            }
            JmxGenerator.forJMeterHome(JMeterUtils.getJMeterHome()).write(collection, output);
        } catch (Exception e) {
            log.error("Collection import failed", e);
            JOptionPane.showMessageDialog(this, e.getMessage(), "Import failed", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            openInJMeter(event, output, merging);
        } catch (Exception e) {
            log.error("Could not open generated test plan {}", output, e);
            JOptionPane.showMessageDialog(this, "The test plan was saved to " + output
                    + " but could not be opened: " + e.getMessage(), "Import", JOptionPane.ERROR_MESSAGE);
            return;
        }
        dispose();
        showSummary(collection, output);
    }

    private static void openInJMeter(ActionEvent event, File file, boolean merging) throws Exception {
        HashTree tree = SaveService.loadTree(file);
        if (!merging) {
            FileServer.getFileServer().setBaseForScript(file);
        }
        boolean isTestPlan = Load.insertLoadedTree(event.getID(), tree, merging);
        if (!merging && isTestPlan) {
            GuiPackage.getInstance().setTestPlanFile(file.getAbsolutePath());
        }
    }

    private static void showSummary(ApiCollection collection, File output) {
        StringBuilder sb = new StringBuilder();
        sb.append("Imported ").append(collection.getRequests().size()).append(" requests from ")
                .append(collection.getFormat()).append(" collection '").append(collection.getName()).append("'.\n")
                .append("Test plan saved to ").append(output.getAbsolutePath()).append('\n');
        List<String> warnings = collection.getWarnings();
        if (!warnings.isEmpty()) {
            sb.append("\nPlease review:\n");
            for (String w : warnings) {
                sb.append(" - ").append(w).append('\n');
            }
        }
        JTextArea text = new JTextArea(sb.toString(), Math.min(20, 4 + warnings.size()), 70);
        text.setEditable(false);
        text.setLineWrap(true);
        text.setWrapStyleWord(true);
        GuiPackage gui = GuiPackage.getInstance();
        JOptionPane.showMessageDialog(gui == null ? null : gui.getMainFrame(), new JScrollPane(text),
                "Collection imported", warnings.isEmpty() ? JOptionPane.INFORMATION_MESSAGE : JOptionPane.WARNING_MESSAGE);
    }
}
