package io.github.collection2jmx.model;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** A parsed collection: its requests in document order plus the variables it defines. */
public final class ApiCollection {
    private final String name;
    private final String format;
    private final List<ApiRequest> requests = new ArrayList<>();
    private final Map<String, String> variables = new LinkedHashMap<>();
    private final List<String> warnings = new ArrayList<>();

    public ApiCollection(String name, String format) {
        this.name = name == null || name.trim().isEmpty() ? "Imported collection" : name.trim();
        this.format = format;
    }

    public String getName() {
        return name;
    }

    /** Human readable source format, e.g. "Postman v2.1". */
    public String getFormat() {
        return format;
    }

    public List<ApiRequest> getRequests() {
        return requests;
    }

    public Map<String, String> getVariables() {
        return variables;
    }

    public List<String> getWarnings() {
        return warnings;
    }
}
