package io.github.collection2jmx.model;

/** A name/value pair such as a header, query parameter or form field. */
public final class KeyValue {
    private final String key;
    private final String value;

    public KeyValue(String key, String value) {
        this.key = key == null ? "" : key;
        this.value = value == null ? "" : value;
    }

    public String getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return key + "=" + value;
    }
}
