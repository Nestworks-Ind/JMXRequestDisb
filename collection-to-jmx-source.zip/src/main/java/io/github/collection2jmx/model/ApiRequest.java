package io.github.collection2jmx.model;

import java.util.ArrayList;
import java.util.List;

/**
 * One API call taken from a collection, already normalised to JMeter syntax
 * (variables are written as ${name}).
 */
public final class ApiRequest {
    private String name = "";
    private final List<String> folderPath = new ArrayList<>();
    private String method = "GET";
    private String url = "";
    private final List<KeyValue> headers = new ArrayList<>();
    private BodyType bodyType = BodyType.NONE;
    private String rawBody = "";
    private final List<KeyValue> urlEncodedParams = new ArrayList<>();
    private final List<FormField> formFields = new ArrayList<>();
    private String bodyFilePath = "";
    private String graphqlQuery = "";
    private String graphqlVariables = "";
    private String graphqlOperationName = "";
    private String description = "";

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? "" : name;
    }

    /** Folder names from the collection root down to this request (empty for top-level requests). */
    public List<String> getFolderPath() {
        return folderPath;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method == null || method.trim().isEmpty() ? "GET" : method.trim().toUpperCase();
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url == null ? "" : url.trim();
    }

    public List<KeyValue> getHeaders() {
        return headers;
    }

    public BodyType getBodyType() {
        return bodyType;
    }

    public void setBodyType(BodyType bodyType) {
        this.bodyType = bodyType;
    }

    public String getRawBody() {
        return rawBody;
    }

    public void setRawBody(String rawBody) {
        this.rawBody = rawBody == null ? "" : rawBody;
    }

    public List<KeyValue> getUrlEncodedParams() {
        return urlEncodedParams;
    }

    public List<FormField> getFormFields() {
        return formFields;
    }

    public String getBodyFilePath() {
        return bodyFilePath;
    }

    public void setBodyFilePath(String bodyFilePath) {
        this.bodyFilePath = bodyFilePath == null ? "" : bodyFilePath;
    }

    public String getGraphqlQuery() {
        return graphqlQuery;
    }

    public void setGraphqlQuery(String graphqlQuery) {
        this.graphqlQuery = graphqlQuery == null ? "" : graphqlQuery;
    }

    public String getGraphqlVariables() {
        return graphqlVariables;
    }

    public void setGraphqlVariables(String graphqlVariables) {
        this.graphqlVariables = graphqlVariables == null ? "" : graphqlVariables;
    }

    public String getGraphqlOperationName() {
        return graphqlOperationName;
    }

    public void setGraphqlOperationName(String graphqlOperationName) {
        this.graphqlOperationName = graphqlOperationName == null ? "" : graphqlOperationName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description == null ? "" : description;
    }

    public boolean hasHeader(String headerName) {
        for (KeyValue h : headers) {
            if (h.getKey().equalsIgnoreCase(headerName)) {
                return true;
            }
        }
        return false;
    }

    /** "Folder / Sub folder / Request name" */
    public String getDisplayPath() {
        if (folderPath.isEmpty()) {
            return name;
        }
        return String.join(" / ", folderPath) + " / " + name;
    }
}
