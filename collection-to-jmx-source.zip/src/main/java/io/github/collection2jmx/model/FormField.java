package io.github.collection2jmx.model;

/** A multipart form field: either a text value or a file to upload. */
public final class FormField {
    private final String name;
    private final String value;
    private final boolean file;
    private final String contentType;

    public FormField(String name, String value, boolean file, String contentType) {
        this.name = name == null ? "" : name;
        this.value = value == null ? "" : value;
        this.file = file;
        this.contentType = contentType == null ? "" : contentType;
    }

    public String getName() {
        return name;
    }

    /** Text value, or the file path when {@link #isFile()} is true. */
    public String getValue() {
        return value;
    }

    public boolean isFile() {
        return file;
    }

    public String getContentType() {
        return contentType;
    }
}
