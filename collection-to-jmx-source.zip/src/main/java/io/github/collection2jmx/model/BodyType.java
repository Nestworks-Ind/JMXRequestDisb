package io.github.collection2jmx.model;

public enum BodyType {
    NONE,
    /** Raw text body (JSON, XML, text...). */
    RAW,
    /** application/x-www-form-urlencoded parameters. */
    URLENCODED,
    /** multipart/form-data fields and files. */
    MULTIPART,
    /** Binary file sent as the whole body. */
    FILE,
    /** GraphQL query + variables. */
    GRAPHQL
}
