package io.github.collection2jmx.parser;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Rewrites Postman / Insomnia variable placeholders into JMeter ${...} syntax. */
public final class VariableSyntax {

    private static final Pattern DOUBLE_BRACES = Pattern.compile("\\{\\{\\s*([^{}]+?)\\s*}}");
    private static final Pattern INSOMNIA_TAG = Pattern.compile("\\{%\\s*(\\w+)([^%]*)%}");

    private static final Map<String, String> DYNAMIC = new HashMap<>();

    static {
        DYNAMIC.put("$guid", "${__UUID()}");
        DYNAMIC.put("$randomUUID", "${__UUID()}");
        DYNAMIC.put("$timestamp", "${__time(/1000,)}");
        DYNAMIC.put("$isoTimestamp", "${__time(yyyy-MM-dd'T'HH:mm:ss.SSS'Z',)}");
        DYNAMIC.put("$randomInt", "${__Random(0,1000,)}");
        DYNAMIC.put("$randomAlphaNumeric", "${__RandomString(1,abcdefghijklmnopqrstuvwxyz0123456789,)}");
        DYNAMIC.put("$randomBoolean", "${__groovy(new Random().nextBoolean(),)}");
        DYNAMIC.put("$randomEmail", "user${__Random(1000,999999,)}@example.com");
        DYNAMIC.put("$randomFirstName", "${__RandomString(8,abcdefghijklmnopqrstuvwxyz,)}");
        DYNAMIC.put("$randomLastName", "${__RandomString(8,abcdefghijklmnopqrstuvwxyz,)}");
        DYNAMIC.put("$randomUserName", "${__RandomString(10,abcdefghijklmnopqrstuvwxyz0123456789,)}");
    }

    private VariableSyntax() {
    }

    /**
     * Converts {{var}}, {{ _.var }}, {{$guid}} and a few Insomnia template tags to JMeter syntax.
     */
    public static String toJMeter(String text) {
        if (text == null || text.isEmpty()) {
            return text == null ? "" : text;
        }
        String converted = replaceDoubleBraces(text);
        return replaceInsomniaTags(converted);
    }

    private static String replaceDoubleBraces(String text) {
        Matcher m = DOUBLE_BRACES.matcher(text);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String name = m.group(1).trim();
            if (name.startsWith("_.")) {
                name = name.substring(2);
            }
            String replacement = DYNAMIC.get(name);
            if (replacement == null) {
                replacement = "${" + name + "}";
            }
            m.appendReplacement(sb, Matcher.quoteReplacement(replacement));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    private static String replaceInsomniaTags(String text) {
        if (text.indexOf("{%") < 0) {
            return text;
        }
        Matcher m = INSOMNIA_TAG.matcher(text);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String tag = m.group(1);
            String args = m.group(2).trim();
            String replacement;
            if ("uuid".equals(tag)) {
                replacement = "${__UUID()}";
            } else if ("now".equals(tag)) {
                replacement = args.contains("unix") ? "${__time(/1000,)}" : "${__time()}";
            } else if ("base64".equals(tag)) {
                // {% base64 'encode', 'normal', 'value' %}
                String[] parts = args.split(",");
                String value = parts.length > 0 ? unquote(parts[parts.length - 1]) : "";
                replacement = "${__groovy(new String('" + value.replace("'", "\\'")
                        + "'.bytes.encodeBase64()),)}";
            } else {
                // response chaining, prompts etc. have no JMeter equivalent: keep the text visible
                replacement = m.group(0);
            }
            m.appendReplacement(sb, Matcher.quoteReplacement(replacement));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    private static String unquote(String s) {
        String t = s.trim();
        if (t.length() >= 2 && (t.startsWith("'") && t.endsWith("'") || t.startsWith("\"") && t.endsWith("\""))) {
            return t.substring(1, t.length() - 1);
        }
        return t;
    }

    /** True if the text still contains an unconvertible Insomnia template tag. */
    public static boolean hasUnsupportedTag(String text) {
        return text != null && INSOMNIA_TAG.matcher(text).find();
    }
}
