package io.github.collection2jmx.parser;

import com.fasterxml.jackson.databind.JsonNode;
import io.github.collection2jmx.model.ApiCollection;
import io.github.collection2jmx.model.ApiRequest;
import io.github.collection2jmx.model.BodyType;
import io.github.collection2jmx.model.FormField;
import io.github.collection2jmx.model.KeyValue;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Parses Insomnia exports: the v4 format ({"_type":"export","resources":[...]}, JSON or YAML)
 * and the v5 format (YAML with "type: collection.insomnia.rest/5.0" and a nested "collection" tree).
 */
final class InsomniaParser {

    private InsomniaParser() {
    }

    static boolean acceptsV4(JsonNode root) {
        return root.isObject() && root.has("resources") && root.path("resources").isArray()
                && ("export".equals(root.path("_type").asText()) || root.has("__export_format"));
    }

    static boolean acceptsV5(JsonNode root) {
        return root.isObject() && root.path("type").asText("").startsWith("collection.insomnia.rest/");
    }

    // ---------------------------------------------------------------- v4

    static ApiCollection parseV4(JsonNode root) {
        Map<String, JsonNode> byId = new LinkedHashMap<>();
        Map<String, List<JsonNode>> children = new LinkedHashMap<>();
        List<JsonNode> workspaces = new ArrayList<>();
        for (JsonNode r : root.path("resources")) {
            String id = r.path("_id").asText("");
            byId.put(id, r);
            children.computeIfAbsent(r.path("parentId").asText(""), k -> new ArrayList<>()).add(r);
            if ("workspace".equals(r.path("_type").asText())) {
                workspaces.add(r);
            }
        }
        String name = workspaces.size() == 1 ? workspaces.get(0).path("name").asText("") : "Insomnia collection";
        ApiCollection collection = new ApiCollection(name, "Insomnia v" + root.path("__export_format").asText("4"));

        // Base environments (parent = workspace) then their first sub environment
        for (JsonNode ws : workspaces) {
            for (JsonNode env : children.getOrDefault(ws.path("_id").asText(), new ArrayList<>())) {
                if ("environment".equals(env.path("_type").asText())) {
                    flatten("", env.path("data"), collection.getVariables());
                    List<JsonNode> subs = children.getOrDefault(env.path("_id").asText(), new ArrayList<>());
                    for (JsonNode sub : subs) {
                        if ("environment".equals(sub.path("_type").asText())) {
                            flatten("", sub.path("data"), collection.getVariables());
                            break;
                        }
                    }
                }
            }
        }

        List<JsonNode> roots = new ArrayList<>();
        if (workspaces.isEmpty()) {
            // No workspace exported: treat every resource whose parent is unknown as a root
            for (JsonNode r : root.path("resources")) {
                if (!byId.containsKey(r.path("parentId").asText(""))) {
                    roots.add(r);
                }
            }
        } else {
            for (JsonNode ws : workspaces) {
                roots.addAll(children.getOrDefault(ws.path("_id").asText(), new ArrayList<>()));
            }
        }
        walkV4(sorted(roots), children, new ArrayList<>(), new ArrayList<>(), null, collection);
        return collection;
    }

    private static void walkV4(List<JsonNode> nodes, Map<String, List<JsonNode>> children, List<String> path,
                               List<KeyValue> folderHeaders, JsonNode folderAuth, ApiCollection collection) {
        for (JsonNode n : nodes) {
            String type = n.path("_type").asText("");
            if ("request_group".equals(type)) {
                List<String> childPath = new ArrayList<>(path);
                childPath.add(n.path("name").asText("Folder"));
                flatten("", n.path("environment"), collection.getVariables());
                List<KeyValue> headers = new ArrayList<>(folderHeaders);
                headers.addAll(readHeaders(n.path("headers")));
                JsonNode auth = hasAuth(n.get("authentication")) ? n.get("authentication") : folderAuth;
                walkV4(sorted(children.getOrDefault(n.path("_id").asText(), new ArrayList<>())), children,
                        childPath, headers, auth, collection);
            } else if ("request".equals(type)) {
                collection.getRequests().add(toRequest(n, path, folderHeaders, folderAuth, collection));
            } else if ("grpc_request".equals(type) || "websocket_request".equals(type)) {
                collection.getWarnings().add("'" + n.path("name").asText() + "': " + type + " is not an HTTP request, skipped");
            }
        }
    }

    /** Insomnia orders siblings by metaSortKey (lowest first). */
    private static List<JsonNode> sorted(List<JsonNode> nodes) {
        List<JsonNode> copy = new ArrayList<>(nodes);
        copy.sort((a, b) -> Double.compare(a.path("metaSortKey").asDouble(0), b.path("metaSortKey").asDouble(0)));
        return copy;
    }

    // ---------------------------------------------------------------- v5

    static ApiCollection parseV5(JsonNode root) {
        ApiCollection collection = new ApiCollection(root.path("name").asText(""),
                "Insomnia v" + root.path("type").asText("").replaceAll(".*/", ""));
        JsonNode envs = root.path("environments");
        flatten("", envs.path("data"), collection.getVariables());
        JsonNode subs = envs.path("subEnvironments");
        if (subs.isArray() && subs.size() > 0) {
            flatten("", subs.get(0).path("data"), collection.getVariables());
        }
        walkV5(root.path("collection"), new ArrayList<>(), new ArrayList<>(), null, collection);
        return collection;
    }

    private static void walkV5(JsonNode nodes, List<String> path, List<KeyValue> folderHeaders, JsonNode folderAuth,
                               ApiCollection collection) {
        for (JsonNode n : nodes) {
            if (n.has("children") || !n.has("url") && !n.has("method")) {
                List<String> childPath = new ArrayList<>(path);
                childPath.add(n.path("name").asText("Folder"));
                flatten("", n.path("environment"), collection.getVariables());
                List<KeyValue> headers = new ArrayList<>(folderHeaders);
                headers.addAll(readHeaders(n.path("headers")));
                JsonNode auth = hasAuth(n.get("authentication")) ? n.get("authentication") : folderAuth;
                walkV5(n.path("children"), childPath, headers, auth, collection);
            } else {
                collection.getRequests().add(toRequest(n, path, folderHeaders, folderAuth, collection));
            }
        }
    }

    // ---------------------------------------------------------------- shared

    private static ApiRequest toRequest(JsonNode n, List<String> path, List<KeyValue> folderHeaders, JsonNode folderAuth,
                                        ApiCollection collection) {
        ApiRequest req = new ApiRequest();
        req.getFolderPath().addAll(path);
        req.setName(n.path("name").asText("Request"));
        req.setMethod(n.path("method").asText("GET"));
        req.setDescription(n.path("description").asText(""));

        StringBuilder url = new StringBuilder(VariableSyntax.toJMeter(n.path("url").asText("")));
        for (JsonNode p : n.path("parameters")) {
            if (p.path("disabled").asBoolean(false) || p.path("name").asText("").isEmpty()) {
                continue;
            }
            url.append(url.indexOf("?") >= 0 ? '&' : '?')
                    .append(VariableSyntax.toJMeter(p.path("name").asText()))
                    .append('=')
                    .append(VariableSyntax.toJMeter(p.path("value").asText("")));
        }
        req.setUrl(url.toString());

        for (KeyValue h : folderHeaders) {
            if (!req.hasHeader(h.getKey())) {
                req.getHeaders().add(h);
            }
        }
        for (KeyValue h : readHeaders(n.path("headers"))) {
            req.getHeaders().removeIf(existing -> existing.getKey().equalsIgnoreCase(h.getKey()));
            req.getHeaders().add(h);
        }

        readBody(n.path("body"), req, collection);

        JsonNode auth = hasAuth(n.get("authentication")) ? n.get("authentication") : folderAuth;
        applyAuth(auth, req, collection);

        if (VariableSyntax.hasUnsupportedTag(req.getUrl()) || VariableSyntax.hasUnsupportedTag(req.getRawBody())) {
            collection.getWarnings().add("'" + req.getDisplayPath()
                    + "': contains Insomnia template tags (e.g. response chaining) that need a JMeter extractor");
        }
        return req;
    }

    private static List<KeyValue> readHeaders(JsonNode headers) {
        List<KeyValue> result = new ArrayList<>();
        for (JsonNode h : headers) {
            if (!h.path("disabled").asBoolean(false) && !h.path("name").asText("").isEmpty()) {
                result.add(new KeyValue(VariableSyntax.toJMeter(h.path("name").asText()),
                        VariableSyntax.toJMeter(h.path("value").asText(""))));
            }
        }
        return result;
    }

    private static void readBody(JsonNode body, ApiRequest req, ApiCollection collection) {
        if (body == null || body.isMissingNode() || body.isNull() || body.size() == 0) {
            return;
        }
        String mime = body.path("mimeType").asText("");
        String text = body.path("text").asText("");
        if ("application/graphql".equals(mime)) {
            if (!GraphQLSupport.tryFromJsonBody(req, text, true)) {
                GraphQLSupport.apply(req, text, "", "");
            }
            req.setGraphqlQuery(VariableSyntax.toJMeter(req.getGraphqlQuery()));
            req.setGraphqlVariables(VariableSyntax.toJMeter(req.getGraphqlVariables()));
            req.getHeaders().removeIf(h -> h.getKey().equalsIgnoreCase("Content-Type"));
            req.getHeaders().add(new KeyValue("Content-Type", "application/json"));
        } else if ("application/x-www-form-urlencoded".equals(mime)) {
            req.setBodyType(BodyType.URLENCODED);
            for (JsonNode p : body.path("params")) {
                if (!p.path("disabled").asBoolean(false)) {
                    req.getUrlEncodedParams().add(new KeyValue(VariableSyntax.toJMeter(p.path("name").asText()),
                            VariableSyntax.toJMeter(p.path("value").asText(""))));
                }
            }
        } else if ("multipart/form-data".equals(mime)) {
            req.setBodyType(BodyType.MULTIPART);
            // JMeter generates the multipart Content-Type with its own boundary
            req.getHeaders().removeIf(h -> h.getKey().equalsIgnoreCase("Content-Type"));
            for (JsonNode p : body.path("params")) {
                if (p.path("disabled").asBoolean(false)) {
                    continue;
                }
                boolean isFile = "file".equals(p.path("type").asText());
                String value = isFile ? p.path("fileName").asText("") : p.path("value").asText("");
                req.getFormFields().add(new FormField(VariableSyntax.toJMeter(p.path("name").asText()),
                        VariableSyntax.toJMeter(value), isFile, ""));
            }
        } else if (body.has("fileName") && text.isEmpty()) {
            req.setBodyType(BodyType.FILE);
            req.setBodyFilePath(VariableSyntax.toJMeter(body.path("fileName").asText()));
        } else if (!text.isEmpty()) {
            if (GraphQLSupport.tryFromJsonBody(req, text, false)) {
                req.setGraphqlQuery(VariableSyntax.toJMeter(req.getGraphqlQuery()));
                req.setGraphqlVariables(VariableSyntax.toJMeter(req.getGraphqlVariables()));
            } else {
                req.setBodyType(BodyType.RAW);
                req.setRawBody(VariableSyntax.toJMeter(text));
            }
            if (!mime.isEmpty() && !req.hasHeader("Content-Type")) {
                req.getHeaders().add(new KeyValue("Content-Type", mime));
            }
        }
    }

    private static boolean hasAuth(JsonNode auth) {
        return auth != null && auth.isObject() && auth.size() > 0 && !auth.path("type").asText("").isEmpty();
    }

    private static void applyAuth(JsonNode auth, ApiRequest req, ApiCollection collection) {
        if (!hasAuth(auth) || auth.path("disabled").asBoolean(false)) {
            return;
        }
        String type = auth.path("type").asText();
        switch (type) {
            case "none":
            case "noauth":
                break;
            case "bearer":
                AuthSupport.bearer(req, auth.path("token").asText(""), auth.path("prefix").asText(""));
                break;
            case "basic":
                AuthSupport.basic(req, auth.path("username").asText(""), auth.path("password").asText(""));
                break;
            case "apikey":
                AuthSupport.apiKey(req, auth.path("key").asText(""), auth.path("value").asText(""),
                        "queryParams".equals(auth.path("addTo").asText()));
                break;
            default:
                collection.getWarnings().add("'" + req.getDisplayPath() + "': auth type '" + type
                        + "' is not converted, add it manually (e.g. HTTP Authorization Manager)");
        }
    }

    /** Nested environment objects become dotted names: {"api": {"url": ..}} -> api.url */
    private static void flatten(String prefix, JsonNode data, Map<String, String> target) {
        if (data == null || !data.isObject()) {
            return;
        }
        Iterator<Map.Entry<String, JsonNode>> it = data.fields();
        while (it.hasNext()) {
            Map.Entry<String, JsonNode> e = it.next();
            String key = prefix.isEmpty() ? e.getKey() : prefix + "." + e.getKey();
            JsonNode v = e.getValue();
            if (v.isObject()) {
                flatten(key, v, target);
            } else if (v.isNull()) {
                target.put(key, "");
            } else {
                target.put(key, VariableSyntax.toJMeter(v.isTextual() ? v.asText() : v.toString()));
            }
        }
    }
}
