package io.github.collection2jmx.parser;

import io.github.collection2jmx.model.ApiRequest;
import io.github.collection2jmx.model.KeyValue;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

/** Turns collection auth settings into request headers / query parameters. */
final class AuthSupport {

    private AuthSupport() {
    }

    static void bearer(ApiRequest request, String token, String prefix) {
        if (token == null || token.isEmpty() || request.hasHeader("Authorization")) {
            return;
        }
        String p = prefix == null || prefix.trim().isEmpty() ? "Bearer" : prefix.trim();
        request.getHeaders().add(new KeyValue("Authorization", p + " " + VariableSyntax.toJMeter(token)));
    }

    static void basic(ApiRequest request, String user, String password) {
        if (request.hasHeader("Authorization")) {
            return;
        }
        String u = VariableSyntax.toJMeter(user == null ? "" : user);
        String pw = VariableSyntax.toJMeter(password == null ? "" : password);
        String credentials = u + ":" + pw;
        String value;
        if (credentials.contains("${")) {
            // Encoded at run time so that variables are resolved first
            value = "Basic ${__groovy('" + escapeGroovy(credentials)
                    + "'.getBytes('UTF-8').encodeBase64().toString(),)}";
        } else {
            value = "Basic " + Base64.getEncoder().encodeToString(credentials.getBytes(StandardCharsets.UTF_8));
        }
        request.getHeaders().add(new KeyValue("Authorization", value));
    }

    static void apiKey(ApiRequest request, String key, String value, boolean inQuery) {
        if (key == null || key.isEmpty()) {
            return;
        }
        String k = VariableSyntax.toJMeter(key);
        String v = VariableSyntax.toJMeter(value);
        if (inQuery) {
            String url = request.getUrl();
            request.setUrl(url + (url.contains("?") ? "&" : "?") + k + "=" + v);
        } else if (!request.hasHeader(k)) {
            request.getHeaders().add(new KeyValue(k, v));
        }
    }

    private static String escapeGroovy(String s) {
        // First for the Groovy single-quoted string, then for the JMeter function argument parser
        String groovy = s.replace("\\", "\\\\").replace("'", "\\'");
        return groovy.replace("\\", "\\\\").replace(",", "\\,");
    }
}
