package io.github.collection2jmx.parser;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.github.collection2jmx.model.ApiRequest;
import io.github.collection2jmx.model.BodyType;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Helpers shared by the parsers for recognising and filling GraphQL requests. */
final class GraphQLSupport {

    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final Pattern OPERATION =
            Pattern.compile("^\\s*(?:#[^\\n]*\\n\\s*)*(query|mutation|subscription)\\s+([_A-Za-z][_0-9A-Za-z]*)");
    private static final Pattern LOOKS_LIKE_QUERY =
            Pattern.compile("^\\s*(?:#[^\\n]*\\n\\s*)*(query|mutation|subscription|fragment|\\{)");

    private GraphQLSupport() {
    }

    static void apply(ApiRequest request, String query, String variables, String operationName) {
        request.setBodyType(BodyType.GRAPHQL);
        request.setGraphqlQuery(query == null ? "" : query);
        request.setGraphqlVariables(normaliseVariables(variables));
        String op = operationName;
        if (op == null || op.trim().isEmpty()) {
            op = operationNameOf(query);
        }
        request.setGraphqlOperationName(op);
    }

    static String operationNameOf(String query) {
        if (query == null) {
            return "";
        }
        Matcher m = OPERATION.matcher(query);
        return m.find() ? m.group(2) : "";
    }

    /** Pretty prints JSON variables, or returns the text as-is when it is not valid JSON (e.g. contains ${var}). */
    static String normaliseVariables(String variables) {
        if (variables == null || variables.trim().isEmpty()) {
            return "";
        }
        try {
            JsonNode node = MAPPER.readTree(variables);
            if (node == null || node.isNull() || node.isObject() && node.size() == 0) {
                return "";
            }
            return MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(node);
        } catch (Exception e) {
            return variables.trim();
        }
    }

    /**
     * If a raw JSON body is a GraphQL envelope ({"query": "...", "variables": {...}}) sent to a
     * GraphQL-looking endpoint, turns the request into a GraphQL request.
     */
    static boolean tryFromJsonBody(ApiRequest request, String body, boolean force) {
        if (body == null || body.trim().isEmpty()) {
            return false;
        }
        if (!force && !request.getUrl().toLowerCase().contains("graphql")) {
            return false;
        }
        JsonNode node;
        try {
            node = MAPPER.readTree(body);
        } catch (Exception e) {
            return false;
        }
        if (node == null || !node.isObject() || !node.path("query").isTextual()) {
            return false;
        }
        String query = node.path("query").asText();
        if (!force && !LOOKS_LIKE_QUERY.matcher(query).find()) {
            return false;
        }
        JsonNode vars = node.get("variables");
        String varsText;
        if (vars == null || vars.isNull()) {
            varsText = "";
        } else if (vars.isTextual()) {
            varsText = vars.asText();
        } else {
            varsText = vars.toString();
        }
        apply(request, query, varsText, node.path("operationName").asText(""));
        return true;
    }
}
