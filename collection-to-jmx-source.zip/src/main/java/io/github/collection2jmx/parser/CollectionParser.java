package io.github.collection2jmx.parser;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.github.collection2jmx.model.ApiCollection;
import org.yaml.snakeyaml.LoaderOptions;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.SafeConstructor;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/** Entry point: detects the collection format and parses it. */
public final class CollectionParser {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private CollectionParser() {
    }

    public static ApiCollection parse(File file) throws IOException {
        return parse(new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8), file.getName());
    }

    /**
     * @param content    file content (JSON or YAML)
     * @param sourceName used in error messages only
     */
    public static ApiCollection parse(String content, String sourceName) throws IOException {
        JsonNode root = read(content, sourceName);
        ApiCollection collection;
        if (InsomniaParser.acceptsV5(root)) {
            collection = InsomniaParser.parseV5(root);
        } else if (InsomniaParser.acceptsV4(root)) {
            collection = InsomniaParser.parseV4(root);
        } else if (PostmanParser.accepts(root)) {
            collection = PostmanParser.parse(root);
        } else if (root.isObject() && root.has("requests") && root.has("order")) {
            throw new IOException(sourceName + " is a Postman v1 collection. In Postman, export it again as "
                    + "\"Collection v2.1\" and import that file.");
        } else {
            throw new IOException(sourceName + " is not a recognised Postman (v2.0/v2.1) or Insomnia (v4/v5) export.");
        }
        if (collection.getRequests().isEmpty()) {
            collection.getWarnings().add("The collection does not contain any HTTP requests.");
        }
        return collection;
    }

    /** Merges a Postman environment / globals export into the collection variables (environment wins). */
    public static void applyEnvironment(ApiCollection collection, File envFile) throws IOException {
        String content = new String(Files.readAllBytes(envFile.toPath()), StandardCharsets.UTF_8);
        JsonNode env = read(content, envFile.getName());
        if (!env.has("values")) {
            throw new IOException(envFile.getName() + " is not a Postman environment export (no \"values\" list).");
        }
        PostmanParser.readEnvironment(env, collection.getVariables());
    }

    private static JsonNode read(String content, String sourceName) throws IOException {
        String trimmed = content.startsWith("﻿") ? content.substring(1) : content;
        String t = trimmed.trim();
        if (t.startsWith("{") || t.startsWith("[")) {
            try {
                return MAPPER.readTree(t);
            } catch (JsonProcessingException e) {
                throw new IOException(sourceName + " is not valid JSON: " + e.getOriginalMessage(), e);
            }
        }
        try {
            LoaderOptions options = new LoaderOptions();
            options.setCodePointLimit(Integer.MAX_VALUE);
            Object yaml = new Yaml(new SafeConstructor(options)).load(trimmed);
            if (yaml == null) {
                throw new IOException(sourceName + " is empty.");
            }
            return MAPPER.valueToTree(yaml);
        } catch (RuntimeException e) {
            throw new IOException(sourceName + " is neither valid JSON nor YAML: " + e.getMessage(), e);
        }
    }
}
