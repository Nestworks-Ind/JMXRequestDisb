package io.github.collection2jmx.parser;

import com.fasterxml.jackson.databind.JsonNode;
import io.github.collection2jmx.model.ApiCollection;
import io.github.collection2jmx.model.ApiRequest;
import io.github.collection2jmx.model.BodyType;
import io.github.collection2jmx.model.FormField;
import io.github.collection2jmx.model.KeyValue;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/** Parses Postman collections in the v2.0 / v2.1 format. */
final class PostmanParser {

    private PostmanParser() {
    }

    static boolean accepts(JsonNode root) {
        if (!root.isObject()) {
            return false;
        }
        String schema = root.path("info").path("schema").asText("");
        return schema.contains("schema.getpostman.com") || root.has("info") && root.has("item");
    }

    static ApiCollection parse(JsonNode root) {
        JsonNode info = root.path("info");
        String schema = info.path("schema").asText("");
        String version = schema.contains("v2.0") ? "v2.0" : "v2.1";
        ApiCollection collection = new ApiCollection(info.path("name").asText(""), "Postman " + version);

        for (JsonNode v : root.path("variable")) {
            if (!v.path("disabled").asBoolean(false)) {
                String key = v.has("key") ? v.path("key").asText() : v.path("id").asText();
                if (!key.isEmpty()) {
                    collection.getVariables().put(key, VariableSyntax.toJMeter(text(v.get("value"))));
                }
            }
        }
        walk(root.path("item"), new ArrayList<>(), root.get("auth"), collection);
        return collection;
    }

    /** Postman environment / globals export: {"values":[{"key":..,"value":..,"enabled":..}]} */
    static void readEnvironment(JsonNode env, Map<String, String> target) {
        for (JsonNode v : env.path("values")) {
            if (v.path("enabled").asBoolean(true) && !v.path("key").asText("").isEmpty()) {
                target.put(v.path("key").asText(), VariableSyntax.toJMeter(text(v.get("value"))));
            }
        }
    }

    private static void walk(JsonNode items, List<String> path, JsonNode inheritedAuth, ApiCollection collection) {
        for (JsonNode item : items) {
            JsonNode auth = item.has("auth") && !item.get("auth").isNull() ? item.get("auth") : inheritedAuth;
            if (item.has("item")) {
                List<String> childPath = new ArrayList<>(path);
                childPath.add(item.path("name").asText("Folder"));
                walk(item.path("item"), childPath, auth, collection);
            } else if (item.has("request")) {
                collection.getRequests().add(toRequest(item, path, inheritedAuth, collection));
            }
        }
    }

    private static ApiRequest toRequest(JsonNode item, List<String> path, JsonNode inheritedAuth, ApiCollection collection) {
        ApiRequest req = new ApiRequest();
        req.getFolderPath().addAll(path);
        req.setName(item.path("name").asText("Request"));

        JsonNode r = item.get("request");
        if (r.isTextual()) {
            req.setUrl(VariableSyntax.toJMeter(r.asText()));
            return req;
        }
        req.setMethod(r.path("method").asText("GET"));
        req.setUrl(VariableSyntax.toJMeter(url(r.get("url"))));
        req.setDescription(text(r.get("description")));

        for (JsonNode h : r.path("header")) {
            if (!h.path("disabled").asBoolean(false) && !h.path("key").asText("").isEmpty()) {
                req.getHeaders().add(new KeyValue(VariableSyntax.toJMeter(h.path("key").asText()),
                        VariableSyntax.toJMeter(text(h.get("value")))));
            }
        }

        readBody(r.get("body"), req, collection);

        JsonNode auth = r.has("auth") && !r.get("auth").isNull() ? r.get("auth") : inheritedAuth;
        applyAuth(auth, req, collection);
        return req;
    }

    private static void readBody(JsonNode body, ApiRequest req, ApiCollection collection) {
        if (body == null || body.isNull() || body.path("disabled").asBoolean(false)) {
            return;
        }
        String mode = body.path("mode").asText("");
        switch (mode) {
            case "raw": {
                String raw = text(body.get("raw"));
                if (raw.isEmpty()) {
                    return;
                }
                String language = body.path("options").path("raw").path("language").asText("");
                if (!GraphQLSupport.tryFromJsonBody(req, raw, false)) {
                    req.setBodyType(BodyType.RAW);
                    req.setRawBody(VariableSyntax.toJMeter(raw));
                    addContentTypeIfMissing(req, contentTypeFor(language, raw));
                } else {
                    convertGraphQLVariables(req);
                }
                break;
            }
            case "urlencoded":
                req.setBodyType(BodyType.URLENCODED);
                for (JsonNode p : body.path("urlencoded")) {
                    if (!p.path("disabled").asBoolean(false)) {
                        req.getUrlEncodedParams().add(new KeyValue(VariableSyntax.toJMeter(p.path("key").asText()),
                                VariableSyntax.toJMeter(text(p.get("value")))));
                    }
                }
                break;
            case "formdata":
                req.setBodyType(BodyType.MULTIPART);
                for (JsonNode p : body.path("formdata")) {
                    if (p.path("disabled").asBoolean(false)) {
                        continue;
                    }
                    boolean isFile = "file".equals(p.path("type").asText());
                    String value = isFile ? firstText(p.get("src")) : text(p.get("value"));
                    req.getFormFields().add(new FormField(VariableSyntax.toJMeter(p.path("key").asText()),
                            VariableSyntax.toJMeter(value), isFile, p.path("contentType").asText("")));
                }
                break;
            case "file":
                req.setBodyType(BodyType.FILE);
                req.setBodyFilePath(VariableSyntax.toJMeter(firstText(body.path("file").get("src"))));
                break;
            case "graphql": {
                JsonNode gql = body.path("graphql");
                GraphQLSupport.apply(req, VariableSyntax.toJMeter(text(gql.get("query"))),
                        VariableSyntax.toJMeter(text(gql.get("variables"))), "");
                break;
            }
            default:
                if (!mode.isEmpty()) {
                    collection.getWarnings().add("'" + req.getDisplayPath() + "': unsupported body mode '" + mode + "' ignored");
                }
        }
    }

    private static void convertGraphQLVariables(ApiRequest req) {
        req.setGraphqlQuery(VariableSyntax.toJMeter(req.getGraphqlQuery()));
        req.setGraphqlVariables(VariableSyntax.toJMeter(req.getGraphqlVariables()));
    }

    private static void applyAuth(JsonNode auth, ApiRequest req, ApiCollection collection) {
        if (auth == null || auth.isNull()) {
            return;
        }
        String type = auth.path("type").asText("");
        JsonNode params = auth.get(type);
        switch (type) {
            case "noauth":
            case "":
                break;
            case "bearer":
                AuthSupport.bearer(req, authParam(params, "token"), "Bearer");
                break;
            case "basic":
                AuthSupport.basic(req, authParam(params, "username"), authParam(params, "password"));
                break;
            case "apikey":
                AuthSupport.apiKey(req, authParam(params, "key"), authParam(params, "value"),
                        "query".equals(authParam(params, "in")));
                break;
            default:
                collection.getWarnings().add("'" + req.getDisplayPath() + "': auth type '" + type
                        + "' is not converted, add it manually (e.g. HTTP Authorization Manager)");
        }
    }

    /** v2.1 stores auth params as [{key, value}], v2.0 as an object. */
    private static String authParam(JsonNode params, String name) {
        if (params == null) {
            return "";
        }
        if (params.isArray()) {
            for (JsonNode p : params) {
                if (name.equals(p.path("key").asText())) {
                    return text(p.get("value"));
                }
            }
            return "";
        }
        return text(params.get(name));
    }

    static String url(JsonNode url) {
        if (url == null || url.isNull()) {
            return "";
        }
        if (url.isTextual()) {
            return url.asText();
        }
        String raw = url.path("raw").asText("");
        String base;
        if (!raw.isEmpty()) {
            int q = raw.indexOf('?');
            base = q >= 0 ? raw.substring(0, q) : raw;
            int hash = base.indexOf('#');
            if (hash >= 0) {
                base = base.substring(0, hash);
            }
        } else {
            base = buildBase(url);
        }
        base = substitutePathVariables(base, url.path("variable"));

        String query;
        if (url.has("query")) {
            StringBuilder sb = new StringBuilder();
            for (JsonNode q : url.path("query")) {
                if (q.path("disabled").asBoolean(false)) {
                    continue;
                }
                if (sb.length() > 0) {
                    sb.append('&');
                }
                sb.append(q.path("key").asText(""));
                if (q.has("value") && !q.get("value").isNull()) {
                    sb.append('=').append(text(q.get("value")));
                }
            }
            query = sb.toString();
        } else {
            int q = raw.indexOf('?');
            query = q >= 0 ? raw.substring(q + 1) : "";
        }
        return query.isEmpty() ? base : base + "?" + query;
    }

    private static String buildBase(JsonNode url) {
        StringBuilder sb = new StringBuilder();
        String protocol = url.path("protocol").asText("");
        if (!protocol.isEmpty()) {
            sb.append(protocol).append("://");
        }
        sb.append(joinOrText(url.get("host"), "."));
        String port = url.path("port").asText("");
        if (!port.isEmpty()) {
            sb.append(':').append(port);
        }
        String path = joinOrText(url.get("path"), "/");
        if (!path.isEmpty()) {
            sb.append(path.startsWith("/") ? "" : "/").append(path);
        }
        return sb.toString();
    }

    private static String substitutePathVariables(String base, JsonNode variables) {
        String result = base;
        for (JsonNode v : variables) {
            String key = v.path("key").asText("");
            if (key.isEmpty() || !v.has("value") || v.get("value").isNull()) {
                continue;
            }
            result = result.replaceAll("(?<=/):" + java.util.regex.Pattern.quote(key) + "(?=/|$)",
                    java.util.regex.Matcher.quoteReplacement(text(v.get("value"))));
        }
        return result;
    }

    private static String joinOrText(JsonNode node, String sep) {
        if (node == null || node.isNull()) {
            return "";
        }
        if (node.isArray()) {
            List<String> parts = new ArrayList<>();
            Iterator<JsonNode> it = node.elements();
            while (it.hasNext()) {
                JsonNode p = it.next();
                parts.add(p.isObject() ? p.path("value").asText("") : p.asText());
            }
            return String.join(sep, parts);
        }
        return node.asText();
    }

    private static String contentTypeFor(String language, String raw) {
        switch (language) {
            case "json":
                return "application/json";
            case "xml":
                return "application/xml";
            case "html":
                return "text/html";
            case "javascript":
                return "application/javascript";
            case "text":
                return "text/plain";
            default:
                String t = raw.trim();
                if (t.startsWith("{") || t.startsWith("[")) {
                    return "application/json";
                }
                return t.startsWith("<") ? "application/xml" : "text/plain";
        }
    }

    private static void addContentTypeIfMissing(ApiRequest req, String contentType) {
        if (!req.hasHeader("Content-Type")) {
            req.getHeaders().add(new KeyValue("Content-Type", contentType));
        }
    }

    /** Description and value fields may be strings, objects ({content: ...}) or numbers. */
    static String text(JsonNode node) {
        if (node == null || node.isNull() || node.isMissingNode()) {
            return "";
        }
        if (node.isTextual() || node.isNumber() || node.isBoolean()) {
            return node.asText();
        }
        if (node.isObject() && node.has("content")) {
            return node.path("content").asText("");
        }
        return node.toString();
    }

    private static String firstText(JsonNode node) {
        if (node != null && node.isArray()) {
            return node.size() > 0 ? node.get(0).asText("") : "";
        }
        return text(node);
    }
}
