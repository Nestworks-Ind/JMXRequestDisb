package io.github.collection2jmx.parser;

import io.github.collection2jmx.model.ApiCollection;
import io.github.collection2jmx.model.ApiRequest;
import io.github.collection2jmx.model.BodyType;
import io.github.collection2jmx.model.KeyValue;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class CollectionParserTest {

    private static ApiCollection sample(String name) throws IOException {
        return CollectionParser.parse(new File("samples", name));
    }

    private static ApiRequest find(ApiCollection c, String name) {
        return c.getRequests().stream().filter(r -> r.getName().equals(name)).findFirst()
                .orElseThrow(() -> new AssertionError("no request " + name));
    }

    private static String header(ApiRequest r, String name) {
        return r.getHeaders().stream().filter(h -> h.getKey().equalsIgnoreCase(name)).map(KeyValue::getValue)
                .findFirst().orElse(null);
    }

    @Test
    void postmanCollectionIsFullyProcessedIncludingNestedFolders() throws IOException {
        ApiCollection c = sample("sample-api.postman_collection.json");
        assertEquals("Postman v2.1", c.getFormat());
        assertEquals("Sample Store API", c.getName());
        assertEquals(10, c.getRequests().size());
        assertEquals("Users / Admin / Delete user", find(c, "Delete user").getDisplayPath());
        assertEquals("https://api.example.com/v1", c.getVariables().get("baseUrl"));
    }

    @Test
    void postmanUrlsHeadersAndAuth() throws IOException {
        ApiCollection c = sample("sample-api.postman_collection.json");
        ApiRequest list = find(c, "List users");
        assertEquals("${baseUrl}/users?page=1&limit=20", list.getUrl(), "disabled query params are dropped");
        assertEquals("Bearer ${authToken}", header(list, "Authorization"), "collection auth is inherited");

        assertEquals("${baseUrl}/users/${userId}", find(c, "Get user").getUrl(), "path variables are substituted");
        assertEquals("Basic YWRtaW46c2VjcmV0", header(find(c, "Delete user"), "Authorization"), "folder auth wins");
        assertEquals(null, header(find(c, "Login (form)"), "Authorization"), "noauth disables inherited auth");
        assertEquals("${__UUID()}", header(find(c, "Create user"), "X-Request-Id"));
    }

    @Test
    void postmanBodies() throws IOException {
        ApiCollection c = sample("sample-api.postman_collection.json");
        ApiRequest create = find(c, "Create user");
        assertEquals(BodyType.RAW, create.getBodyType());
        assertEquals("application/json", header(create, "Content-Type"));

        ApiRequest login = find(c, "Login (form)");
        assertEquals(BodyType.URLENCODED, login.getBodyType());
        assertEquals("username=jane,password=p@ss word",
                login.getUrlEncodedParams().stream().map(KeyValue::toString).collect(Collectors.joining(",")));

        ApiRequest upload = find(c, "Upload avatar");
        assertEquals(BodyType.MULTIPART, upload.getBodyType());
        assertEquals(2, upload.getFormFields().size());
        assertTrue(upload.getFormFields().get(1).isFile());
        assertEquals("avatar.png", upload.getFormFields().get(1).getValue());
    }

    @Test
    void postmanGraphQLModeAndRawGraphQLEnvelope() throws IOException {
        ApiCollection c = sample("sample-api.postman_collection.json");
        ApiRequest products = find(c, "Products query");
        assertEquals(BodyType.GRAPHQL, products.getBodyType());
        assertEquals("GetProducts", products.getGraphqlOperationName());
        assertTrue(products.getGraphqlQuery().startsWith("query GetProducts($first: Int!)"));
        assertTrue(products.getGraphqlVariables().contains("\"first\" : 10"));

        ApiRequest cart = find(c, "Add to cart (raw JSON GraphQL)");
        assertEquals(BodyType.GRAPHQL, cart.getBodyType(), "JSON {query, variables} sent to /graphql is GraphQL");
        assertEquals("AddToCart", cart.getGraphqlOperationName());
        assertTrue(cart.getGraphqlVariables().contains("${userId}"));
    }

    @Test
    void insomniaV4() throws IOException {
        ApiCollection c = sample("sample-api.insomnia-v4.json");
        assertEquals("Insomnia v4", c.getFormat());
        assertEquals("Sample Store API (Insomnia)", c.getName());
        assertEquals("List users,Create user,Login (form),Products query",
                c.getRequests().stream().map(ApiRequest::getName).collect(Collectors.joining(",")),
                "siblings follow metaSortKey order");
        assertEquals("changeme", c.getVariables().get("auth.token"), "nested environment values are flattened");

        ApiRequest list = find(c, "List users");
        assertEquals("${baseUrl}/users?page=1", list.getUrl());
        assertEquals("Bearer ${auth.token}", header(list, "Authorization"), "folder auth is inherited");
        assertEquals("Basic amFuZTpzZWNyZXQ=", header(find(c, "Login (form)"), "Authorization"));
        assertTrue(find(c, "Create user").getRawBody().contains("${__UUID()}"));

        ApiRequest gql = find(c, "Products query");
        assertEquals(BodyType.GRAPHQL, gql.getBodyType());
        assertEquals("GetProducts", gql.getGraphqlOperationName());
    }

    @Test
    void insomniaV5Yaml() throws IOException {
        ApiCollection c = sample("sample-api.insomnia-v5.yaml");
        assertEquals("Insomnia v5.0", c.getFormat());
        assertEquals(4, c.getRequests().size());
        ApiRequest create = find(c, "Create user");
        assertEquals("Users / Create user", create.getDisplayPath());
        assertEquals("jmeter", header(create, "X-Client"), "folder headers are inherited");
        assertEquals("Bearer ${token}", header(create, "Authorization"));
        assertEquals(BodyType.GRAPHQL, find(c, "Products query").getBodyType());
        assertEquals("https://status.example.com/health", find(c, "Health check").getUrl());
    }

    @Test
    void unknownFormatIsRejected() {
        IOException e = assertThrows(IOException.class, () -> CollectionParser.parse("{\"foo\":1}", "x.json"));
        assertTrue(e.getMessage().contains("not a recognised"));
    }

    @Test
    void variableSyntax() {
        assertEquals("${a}/${b.c}/${__UUID()}/${__time(/1000,)}",
                VariableSyntax.toJMeter("{{a}}/{{ _.b.c }}/{{$guid}}/{{$timestamp}}"));
        assertEquals("id=${__UUID()}", VariableSyntax.toJMeter("id={% uuid 'v4' %}"));
    }
}
