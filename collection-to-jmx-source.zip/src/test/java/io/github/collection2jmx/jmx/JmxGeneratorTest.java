package io.github.collection2jmx.jmx;

import io.github.collection2jmx.model.ApiCollection;
import io.github.collection2jmx.parser.CollectionParser;
import org.junit.jupiter.api.Test;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class JmxGeneratorTest {

    private static final XPath XP = XPathFactory.newInstance().newXPath();

    private static Document generate(String sample) throws Exception {
        ApiCollection c = CollectionParser.parse(new File("samples", sample));
        String xml = new JmxGenerator(null).generate(c);
        return DocumentBuilderFactory.newInstance().newDocumentBuilder()
                .parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
    }

    private static NodeList nodes(Document d, String xpath) throws Exception {
        return (NodeList) XP.evaluate(xpath, d, XPathConstants.NODESET);
    }

    private static String str(Object ctx, String xpath) throws Exception {
        return XP.evaluate(xpath, ctx);
    }

    /** The Thread Group's child hashTree */
    private static final String TG_TREE = "/jmeterTestPlan/hashTree/hashTree/ThreadGroup/following-sibling::hashTree[1]";

    @Test
    void keepsRecordingTemplateAndReplacesRecordingController() throws Exception {
        Document d = generate("sample-api.postman_collection.json");
        assertEquals("Sample Store API", str(d, "/jmeterTestPlan/hashTree/TestPlan/@testname"));
        assertEquals(1, nodes(d, "//ConfigTestElement[@testname='HTTP Request Defaults']").getLength());
        assertEquals(1, nodes(d, "//CookieManager").getLength());
        assertEquals(1, nodes(d, "//ProxyControl").getLength());
        assertEquals(0, nodes(d, "//RecordingController").getLength());
        assertFalse(str(d, "/").contains("[="), "template parameters are filled");
        assertEquals("status.example.com",
                str(d, "//ConfigTestElement/stringProp[@name='HTTPSampler.domain']"));
        assertNotNull(XP.evaluate("//Arguments[@testname='Collection Variables']", d, XPathConstants.NODE));
    }

    @Test
    void everyRequestSitsInItsOwnSimpleControllerUnderTheThreadGroup() throws Exception {
        Document d = generate("sample-api.postman_collection.json");
        NodeList controllers = nodes(d, TG_TREE + "/GenericController");
        assertEquals(10, controllers.getLength());
        assertEquals("LogicControllerGui", ((Element) controllers.item(0)).getAttribute("guiclass"));
        assertEquals("Users / List users", ((Element) controllers.item(0)).getAttribute("testname"));
        for (int i = 0; i < controllers.getLength(); i++) {
            Node tree = controllers.item(i).getNextSibling();
            while (tree.getNodeType() != Node.ELEMENT_NODE) {
                tree = tree.getNextSibling();
            }
            assertEquals(1, ((NodeList) XP.evaluate("HTTPSamplerProxy", tree, XPathConstants.NODESET)).getLength(),
                    "one sampler per controller");
        }
    }

    @Test
    void restAndGraphQLSamplers() throws Exception {
        Document d = generate("sample-api.postman_collection.json");
        Element list = (Element) XP.evaluate("//HTTPSamplerProxy[@testname='List users']", d, XPathConstants.NODE);
        assertEquals("HttpTestSampleGui", list.getAttribute("guiclass"));
        assertEquals("${baseUrl}/users?page=1&limit=20", str(list, "stringProp[@name='HTTPSampler.path']"));
        assertEquals("GET", str(list, "stringProp[@name='HTTPSampler.method']"));

        Element gql = (Element) XP.evaluate("//HTTPSamplerProxy[@testname='Products query']", d, XPathConstants.NODE);
        assertEquals("GraphQLHTTPSamplerGui", gql.getAttribute("guiclass"));
        assertEquals("true", str(gql, "boolProp[@name='HTTPSampler.postBodyRaw']"));
        assertEquals("GetProducts", str(gql, "stringProp[@name='GraphQLHTTPSampler.operationName']"));
        assertTrue(str(gql, ".//stringProp[@name='Argument.value']")
                .startsWith("{\"operationName\":\"GetProducts\",\"variables\":{\"first\":10},\"query\":\"query GetProducts"));
        assertEquals("application/json", str(gql,
                "following-sibling::hashTree[1]/HeaderManager//elementProp[stringProp[@name='Header.name']='Content-Type']"
                        + "/stringProp[@name='Header.value']"));

        Element health = (Element) XP.evaluate("//HTTPSamplerProxy[@testname='Health check (absolute URL)']", d,
                XPathConstants.NODE);
        assertEquals("", str(health, "stringProp[@name='HTTPSampler.domain']"), "uses HTTP Request Defaults host");
        assertEquals("/health", str(health, "stringProp[@name='HTTPSampler.path']"));

        Element upload = (Element) XP.evaluate("//HTTPSamplerProxy[@testname='Upload avatar']", d, XPathConstants.NODE);
        assertEquals("true", str(upload, "boolProp[@name='HTTPSampler.DO_MULTIPART_POST']"));
        assertEquals("avatar", str(upload, ".//elementProp[@elementType='HTTPFileArg']/stringProp[@name='File.paramname']"));
        assertNull(XP.evaluate("following-sibling::hashTree[1]//stringProp[@name='Header.name'][.='Content-Type']",
                upload, XPathConstants.NODE), "multipart Content-Type is left to JMeter");
    }

    @Test
    void insomniaPlansAreGeneratedToo() throws Exception {
        assertEquals(4, nodes(generate("sample-api.insomnia-v4.json"), TG_TREE + "/GenericController").getLength());
        Document v5 = generate("sample-api.insomnia-v5.yaml");
        assertEquals(4, nodes(v5, TG_TREE + "/GenericController").getLength());
        assertEquals(1, nodes(v5, "//HTTPSamplerProxy[@guiclass='GraphQLHTTPSamplerGui']").getLength());
    }

    @Test
    void urlParts() {
        UrlParts p = UrlParts.parse("https://api.example.com:8443/v1/users?x=1", Collections.emptyMap());
        assertEquals("https", p.protocol);
        assertEquals("api.example.com", p.domain);
        assertEquals("8443", p.port);
        assertEquals("/v1/users?x=1", p.path);

        p = UrlParts.parse("http://${host}:${port}/a", Collections.emptyMap());
        assertEquals("${host}", p.domain);
        assertEquals("${port}", p.port);

        p = UrlParts.parse("${baseUrl}/users", Collections.singletonMap("baseUrl", "https://x.io"));
        assertEquals("${baseUrl}/users", p.path);
        assertEquals("", p.domain);

        p = UrlParts.parse("${host}/users", Collections.singletonMap("host", "x.io"));
        assertEquals("${host}", p.domain);
        assertEquals("/users", p.path);
    }
}
