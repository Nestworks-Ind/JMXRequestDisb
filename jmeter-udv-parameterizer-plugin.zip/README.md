# JMeter UDV Parameterizer

A JMeter GUI plugin that turns User Defined Variables into CSV-driven test data.

It adds **Tools > Parameterize User Defined Variables to CSV...**. When you run it:

1. It reads every **User Defined Variables** config element in the open test plan (and the
   variables table on the Test Plan itself) and lists each variable's name, value and where it is defined.
2. You tick the variables you want to parameterize (for example 3 out of 10).
3. You type a CSV file name (`.csv` is added if you leave it out).
4. It writes the CSV file **in the same folder as the saved .jmx**: a header row with the variable
   names, then one row with their current values.
5. It adds a **CSV Data Set Config** right after the User Defined Variables element (same scope), or
   updates an existing CSV Data Set Config if you pick one, with:
   - Filename: the CSV name (relative, so it resolves next to the .jmx)
   - Variable Names: the selected names, comma separated
   - Ignore first line: True (skips the header row)
   - Allow quoted data: True only when a value contains a comma or quote
   - Encoding UTF-8, Recycle on EOF True, Stop thread False, Sharing mode All threads
6. By default it removes the selected variables from User Defined Variables, so the CSV is the single
   source of those values. Untick the option to keep them.

Save the test plan afterwards (Ctrl+S) to keep the tree changes. Add more rows to the CSV for more test data.

## Install

1. Copy `jmeter-udv-parameterizer-1.0.0.jar` into `<JMETER_HOME>/lib/ext/`.
2. Restart JMeter.
3. Open and **save** your .jmx (the plugin needs to know its folder), then use the Tools menu item.

Works with JMeter 5.x (built against 5.6.3, Java 8 bytecode).

## Build from source

Requires JDK 8+ and Maven 3.6+:

```
mvn clean package
```

The jar is written to `target/jmeter-udv-parameterizer-1.0.0.jar`. To build against another JMeter
version, run `mvn clean package -Djmeter.version=5.5`.
