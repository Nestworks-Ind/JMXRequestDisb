@echo off
setlocal EnableDelayedExpansion
rem Rebuilds epp-automation.jar from the code in the src folder. No Maven or internet needed, only a JDK.
cd /d "%~dp0"

rem 1. Find javac: a jdk* folder here, then JDK_HOME / JAVA_HOME, then PATH.
set "JAVAC="
set "JARTOOL="
for /d %%d in (jdk*) do (
  if exist "%%d\bin\javac.exe" (
    set "JAVAC=%CD%\%%d\bin\javac.exe"
    set "JARTOOL=%CD%\%%d\bin\jar.exe"
  )
)
if not defined JAVAC if defined JDK_HOME if exist "%JDK_HOME%\bin\javac.exe" (
  set "JAVAC=%JDK_HOME%\bin\javac.exe"
  set "JARTOOL=%JDK_HOME%\bin\jar.exe"
)
if not defined JAVAC if defined JAVA_HOME if exist "%JAVA_HOME%\bin\javac.exe" (
  set "JAVAC=%JAVA_HOME%\bin\javac.exe"
  set "JARTOOL=%JAVA_HOME%\bin\jar.exe"
)
if not defined JAVAC (
  where javac >nul 2>nul
  if not errorlevel 1 (
    set "JAVAC=javac"
    set "JARTOOL=jar"
  )
)
if not defined JAVAC (
  echo.
  echo  javac was not found, so the code cannot be compiled.
  echo  Unzip a JDK, for example the Microsoft Build of OpenJDK 17 zip, into this folder
  echo  so that it makes a folder starting with "jdk", then run build.bat again.
  echo.
  pause
  exit /b 1
)
echo Using "%JAVAC%"

rem 2. Compile for Java 8, so the jar still runs on machines that only have Java 8.
"%JAVAC%" --release 8 -version >nul 2>nul && (set "REL=--release 8") || (set "REL=-source 8 -target 8")
if exist build rmdir /s /q build
mkdir build
for /r src\main\java %%f in (*.java) do (
  set "p=%%f"
  echo "!p:\=/!">> build\sources.txt
)
"%JAVAC%" %REL% -nowarn -encoding UTF-8 -cp epp-automation.jar -d build\classes @build\sources.txt
if errorlevel 1 (
  echo.
  echo  The code has errors, shown above. epp-automation.jar was NOT changed.
  echo  Copy the errors into Copilot Chat and ask it to fix them.
  echo.
  pause
  exit /b 1
)

rem 3. Back up the jar, then put the new classes and the page into it.
if not exist backup mkdir backup
copy /y epp-automation.jar backup\epp-automation-before-last-build.jar >nul
"%JARTOOL%" uf epp-automation.jar -C build\classes com -C src\main\resources .
if errorlevel 1 (
  echo.
  echo  Could not update epp-automation.jar. Close the EPP Automation black window first, then run build.bat again.
  echo.
  pause
  exit /b 1
)
echo.
echo  Build finished. Start the app with run.bat.
echo  If something is worse, copy backup\epp-automation-before-last-build.jar back over epp-automation.jar.
echo.
pause
