package com.epp.automation;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Everything the user entered on the page for one run. */
public class RunRequest {
    public String applicationName;
    public String userName;
    public String password;
    public boolean showBrowser;
    public Flows flows = new Flows();
    public List<Scenario> scenarios = new ArrayList<>();

    public static class Flows {
        public boolean uploadJmx;
        public boolean uploadCsv;
        public boolean createSimulation;
        public boolean createBatch;
    }

    public static class Scenario {
        public String name;
        public TestSettings smoke = new TestSettings();
        public TestSettings load = new TestSettings();
        /** Filled by the server from the uploaded files, not by the page. */
        public transient List<Path> jmxFiles = new ArrayList<>();
        public transient List<Path> csvFiles = new ArrayList<>();
    }

    public static class TestSettings {
        public String users;
        public String rampup;
        public String duration;
        public String loadGenerators;
        public String cpuCores;
        public String heapMemory;
    }
}
