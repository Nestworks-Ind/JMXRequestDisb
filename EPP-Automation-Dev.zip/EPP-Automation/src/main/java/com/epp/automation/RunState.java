package com.epp.automation;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/** Progress of one run, polled by the page. Log lines are written for people, not developers. */
public class RunState {
    public enum Status { QUEUED, RUNNING, PASSED, FAILED }

    public static class Line {
        public final String time;
        public final String level;
        public final String text;

        Line(String level, String text) {
            this.time = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));
            this.level = level;
            this.text = text;
        }
    }

    public static class Shot {
        public final String step;
        public final String file;

        Shot(String step, String file) {
            this.step = step;
            this.file = file;
        }
    }

    public final String id;
    public volatile Status status = Status.QUEUED;
    public final List<Line> log = new CopyOnWriteArrayList<>();
    public final List<Shot> screenshots = new CopyOnWriteArrayList<>();

    public RunState(String id) {
        this.id = id;
    }

    public void info(String text) { add("info", text); }
    public void ok(String text) { add("ok", text); }
    public void warn(String text) { add("warn", text); }
    public void error(String text) { add("error", text); }

    public void shot(String step, String file) {
        screenshots.add(new Shot(step, file));
    }

    private void add(String level, String text) {
        log.add(new Line(level, text));
        System.out.println("[" + id + "] " + text);
    }
}
