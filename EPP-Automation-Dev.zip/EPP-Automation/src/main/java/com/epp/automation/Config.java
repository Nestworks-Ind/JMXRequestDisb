package com.epp.automation;

import java.io.InputStream;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

/** Settings from the bundled defaults, overridden by an epp-automation.properties file in the working folder. */
public final class Config {
    private static final String FILE = "epp-automation.properties";
    private final Properties props = new Properties();

    public Config() {
        try (InputStream in = Config.class.getResourceAsStream("/" + FILE)) {
            if (in != null) props.load(in);
        } catch (Exception e) {
            throw new IllegalStateException("Could not read the default settings", e);
        }
        Path local = Paths.get(FILE);
        if (Files.exists(local)) {
            try (Reader r = Files.newBufferedReader(local, StandardCharsets.UTF_8)) {
                props.load(r);
            } catch (Exception e) {
                throw new IllegalStateException("Could not read " + local.toAbsolutePath(), e);
            }
        }
    }

    public String get(String key) {
        return props.getProperty(key, "").trim();
    }

    public int getInt(String key) {
        return Integer.parseInt(get(key));
    }

    public String eppUrl() { return get("epp.url").replaceAll("/+$", ""); }
    public String githubUrl() { return get("github.url").replaceAll("/+$", ""); }
    public String branch() { return get("github.branch"); }
    public String jmxFolder() { return get("github.jmxFolder"); }
    public String csvFolder() { return get("github.csvFolder"); }
    public int stepTimeout() { return getInt("timeout.step.ms"); }
    public int longTimeout() { return getInt("timeout.long.ms"); }
}
