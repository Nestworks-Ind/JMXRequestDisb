package com.epp.automation;

import java.io.InputStream;
import java.io.SequenceInputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.FileVisitOption;
import java.nio.file.FileVisitResult;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.zip.GZIPInputStream;

/**
 * Node.js for Playwright, shipped as node.exe.gz.001, .002, ... so that no single file is over GitHub's
 * 25 MB upload limit. The parts are joined once into node\node.exe next to the jar.
 * The parts are found wherever they were unzipped near the jar (the jar folder, the two folders above it,
 * or Downloads, inside EPP* and node* folders), because Windows "Extract All" adds an extra folder level.
 */
final class BundledNode {
    private static final int DEPTH = 5;

    private BundledNode() {}

    /** The folder that holds epp-automation.jar (or the current folder when that is unknown). */
    static Path appFolder() {
        try {
            Path jar = Paths.get(BundledNode.class.getProtectionDomain().getCodeSource().getLocation().toURI());
            return (Files.isDirectory(jar) ? jar : jar.getParent()).toAbsolutePath();
        } catch (Exception e) {
            return Paths.get("").toAbsolutePath();
        }
    }

    /** Folders searched for the parts, for the error message. */
    static List<Path> searched() {
        List<Path> dirs = new ArrayList<>();
        Path app = appFolder();
        dirs.add(app);
        for (Path up = app.getParent(); up != null && dirs.size() < 3; up = up.getParent()) dirs.add(up);
        Path downloads = Paths.get(System.getProperty("user.home"), "Downloads").toAbsolutePath();
        if (!dirs.contains(downloads)) dirs.add(downloads);
        Path cwd = Paths.get("").toAbsolutePath();
        if (!dirs.contains(cwd)) dirs.add(cwd);
        return dirs;
    }

    /** Returns node.exe, joining the parts first if needed, or null if there are no parts. */
    static synchronized Path prepare(RunState run) {
        Path nodeDir = appFolder().resolve("node");
        Path exe = nodeDir.resolve("node.exe");
        if (Files.isRegularFile(exe)) return exe;

        // Part number -> file. The first copy found of each part wins.
        Map<String, Path> parts = new TreeMap<>();
        for (Path root : searched()) {
            for (Path p : find(root)) parts.putIfAbsent(p.getFileName().toString(), p);
        }
        if (parts.isEmpty()) return null;

        List<String> names = new ArrayList<>(parts.keySet());
        for (int i = 0; i < names.size(); i++) {
            String expected = String.format("node.exe.gz.%03d", i + 1);
            if (!names.get(i).equals(expected)) {
                throw new EppFlows.FlowException("Found " + String.join(", ", names) + " but " + expected
                        + " is missing. Unzip both EPP-Node-part1.zip and EPP-Node-part2.zip into "
                        + appFolder().getParent() + ".");
            }
        }
        run.info("Preparing the bundled Node.js for Playwright from " + parts.size() + " parts. This happens only once.");
        Path tmp = nodeDir.resolve("node.exe.tmp");
        try {
            Files.createDirectories(nodeDir);
            List<InputStream> streams = new ArrayList<>();
            for (Path p : parts.values()) streams.add(Files.newInputStream(p));
            try (InputStream in = new GZIPInputStream(new SequenceInputStream(Collections.enumeration(streams)))) {
                Files.copy(in, tmp, StandardCopyOption.REPLACE_EXISTING);
            }
            tmp.toFile().setExecutable(true);
            Files.move(tmp, exe, StandardCopyOption.REPLACE_EXISTING);
            return exe;
        } catch (Exception e) {
            throw new EppFlows.FlowException("Could not unpack Node.js from " + parts.values()
                    + ". Check that both node.exe.gz parts are fully copied (" + e.getMessage() + ").");
        }
    }

    /** Walks a few levels down, skipping folders that cannot be read (such as system folders under C:\\). */
    private static List<Path> find(Path root) {
        List<Path> found = new ArrayList<>();
        if (!Files.isDirectory(root)) return found;
        try {
            Files.walkFileTree(root, EnumSet.noneOf(FileVisitOption.class), DEPTH, new SimpleFileVisitor<Path>() {
                @Override
                public FileVisitResult preVisitDirectory(Path d, BasicFileAttributes attrs) {
                    // Only look inside the folders our zips create, so a search from C:\ or Downloads stays quick.
                    if (d.equals(root) || d.getFileName().toString().matches("(?i)(epp|node).*")) return FileVisitResult.CONTINUE;
                    return FileVisitResult.SKIP_SUBTREE;
                }

                @Override
                public FileVisitResult visitFile(Path f, BasicFileAttributes attrs) {
                    if (attrs.isRegularFile() && f.getFileName().toString().matches("node\\.exe\\.gz\\.\\d{3}")) found.add(f);
                    return FileVisitResult.CONTINUE;
                }

                @Override
                public FileVisitResult visitFileFailed(Path f, java.io.IOException e) {
                    return FileVisitResult.CONTINUE;
                }
            });
        } catch (Exception ignored) {
            // Whatever was found before the problem is still used.
        }
        Collections.sort(found);
        return found;
    }
}
