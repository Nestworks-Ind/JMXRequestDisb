package com.epp.automation;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.javalin.Javalin;
import io.javalin.http.UploadedFile;
import io.javalin.http.staticfiles.Location;
import io.javalin.plugin.json.JavalinJackson;

import java.awt.Desktop;
import java.io.InputStream;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Function;

/** Starts the local web page and runs one automation at a time. */
public final class App {
    private static final ObjectMapper JSON = new ObjectMapper()
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    private final Config config = new Config();
    private final Map<String, RunState> runs = new ConcurrentHashMap<>();
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Path runsDir = Paths.get("runs");

    public static void main(String[] args) throws Exception {
        new App().start();
    }

    private void start() throws Exception {
        Files.createDirectories(runsDir);
        int port = config.getInt("server.port");

        Javalin app = Javalin.create(cfg -> {
            cfg.addStaticFiles("/public", Location.CLASSPATH);
            cfg.maxRequestSize = 1024L * 1024 * 1024;
            cfg.jsonMapper(new JavalinJackson(JSON));
            cfg.showJavalinBanner = false;
        });

        app.post("/api/run", ctx -> {
            RunRequest req = JSON.readValue(ctx.formParam("payload"), RunRequest.class);
            String problem = validate(req, ctx::uploadedFiles);
            if (problem != null) {
                ctx.status(400).json(Collections.singletonMap("error", problem));
                return;
            }
            String id = String.valueOf(System.currentTimeMillis());
            Path dir = Files.createDirectories(runsDir.resolve(id));
            for (int i = 0; i < req.scenarios.size(); i++) {
                RunRequest.Scenario s = req.scenarios.get(i);
                s.jmxFiles = save(ctx.uploadedFiles("jmx_" + i), dir.resolve("jmx"));
                s.csvFiles = save(ctx.uploadedFiles("csv_" + i), dir.resolve("csv"));
            }
            RunState run = new RunState(id);
            runs.put(id, run);
            worker.submit(() -> new EppFlows(config, req, run, dir).run());
            ctx.json(Collections.singletonMap("runId", id));
        });

        app.get("/api/runs/{id}", ctx -> {
            RunState run = runs.get(ctx.pathParam("id"));
            if (run == null) ctx.status(404).json(Collections.singletonMap("error", "Unknown run"));
            else ctx.json(run);
        });

        app.get("/runs/{id}/{file}", ctx -> {
            Path file = runsDir.resolve(ctx.pathParam("id")).resolve(ctx.pathParam("file")).normalize();
            if (!file.startsWith(runsDir) || !Files.isRegularFile(file)) {
                ctx.status(404);
                return;
            }
            ctx.contentType("image/png").result(Files.newInputStream(file));
        });

        app.start("127.0.0.1", port);
        String url = "http://localhost:" + port;
        System.out.println("EPP Automation is running at " + url + " (press Ctrl+C to stop)");
        try {
            if (Desktop.isDesktopSupported()) Desktop.getDesktop().browse(new URI(url));
        } catch (Exception ignored) {
            // Opening the page is a convenience; the URL is printed above.
        }
    }

    private static String validate(RunRequest req, Function<String, List<UploadedFile>> files) {
        RunRequest.Flows f = req.flows;
        if (!f.uploadJmx && !f.uploadCsv && !f.createSimulation) return "Select at least one step to run.";
        if (blank(req.applicationName)) return "Application Name is required.";
        if (blank(req.userName) || blank(req.password)) return "UserName and Password are required.";
        if (req.scenarios.isEmpty()) return "Add at least one scenario row.";
        for (int i = 0; i < req.scenarios.size(); i++) {
            RunRequest.Scenario s = req.scenarios.get(i);
            String row = "Scenario row " + (i + 1) + ": ";
            boolean hasJmx = !files.apply("jmx_" + i).isEmpty();
            boolean hasCsv = !files.apply("csv_" + i).isEmpty();
            if ((f.uploadJmx || f.createSimulation) && !hasJmx) return row + "choose at least one JMX script.";
            if (f.uploadCsv && !f.uploadJmx && !f.createSimulation && !hasCsv) return row + "choose at least one CSV file.";
            if (f.createSimulation) {
                for (String[] v : new String[][] {
                        {"SmokeUsers", s.smoke.users}, {"SmokeRampup", s.smoke.rampup}, {"SmokeDuration", s.smoke.duration},
                        {"SmokeLoadGenerator", s.smoke.loadGenerators}, {"SmokeCPUCores", s.smoke.cpuCores},
                        {"SmokeHeapMemory", s.smoke.heapMemory}, {"LoadUsers", s.load.users}, {"LoadRampup", s.load.rampup},
                        {"LoadDuration", s.load.duration}, {"LoadGenerator", s.load.loadGenerators},
                        {"LoadCPUCores", s.load.cpuCores}, {"LoadHeapMemory", s.load.heapMemory}}) {
                    if (blank(v[1])) return row + v[0] + " is required to create scenarios.";
                }
            }
        }
        return null;
    }

    /** Saves uploads under their original file names, which GitHub and EPP use as-is. */
    private static List<Path> save(List<UploadedFile> uploads, Path dir) throws Exception {
        List<Path> saved = new ArrayList<>();
        if (uploads.isEmpty()) return saved;
        Files.createDirectories(dir);
        for (UploadedFile u : uploads) {
            Path target = dir.resolve(Paths.get(u.getFilename()).getFileName().toString());
            try (InputStream in = u.getContent()) {
                Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
            }
            saved.add(target);
        }
        return saved;
    }

    private static boolean blank(String s) {
        return s == null || s.trim().isEmpty();
    }
}
