package com.epp.automation;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.Response;
import com.microsoft.playwright.options.AriaRole;
import com.microsoft.playwright.options.WaitForSelectorState;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.BooleanSupplier;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The EPP, GitHub and simulation flows. One browser session is shared by every selected flow,
 * so the user signs in once per run and signs out at the end.
 */
public class EppFlows {
    /** A failure with a message meant for the person running the tool. */
    static class FlowException extends RuntimeException {
        FlowException(String message) { super(message); }
    }


    private final Config config;
    private final RunRequest req;
    private final RunState run;
    private final Path dir;
    /** A repository page such as https://github.com/org/repo, but not a sign-in or SSO page. */
    private final Pattern repoUrl;

    private Page epp;
    private Page current;
    private String projectUrl;
    private String simulationsUrl;
    private int shotNo;
    private boolean toldAboutRows;

    public EppFlows(Config config, RunRequest req, RunState run, Path dir) {
        this.config = config;
        this.req = req;
        this.run = run;
        this.dir = dir;
        this.repoUrl = Pattern.compile("^(" + Pattern.quote(config.githubUrl())
                + "/(?!enterprises/|orgs/|login|sessions)[^/?#]+/[^/?#]+)");
    }

    public void run() {
        run.status = RunState.Status.RUNNING;
        try {
            // Playwright needs Node.js. It is shipped next to the jar in parts, which keeps every file under 25 MB.
            System.setProperty("playwright.nodejs.path", findNode());
        } catch (FlowException e) {
            fail(e.getMessage());
            return;
        }
        try (Playwright pw = Playwright.create(new Playwright.CreateOptions()
                .setEnv(Collections.singletonMap("PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD", "1")))) {
            Browser browser = launch(pw);
            // A new context is a clean, private session, like an incognito window.
            BrowserContext context = browser.newContext(new Browser.NewContextOptions().setViewportSize(1600, 900));
            context.setDefaultTimeout(config.stepTimeout());
            epp = context.newPage();
            current = epp;
            boolean signedIn = false;
            try {
                signIn();
                signedIn = true;
                selectApplication();

                if (req.flows.uploadJmx || req.flows.uploadCsv) {
                    String repo = openGitHubRepository(context);
                    if (req.flows.uploadJmx) uploadToGitHub(repo, config.jmxFolder(), allFiles(true), "JMX script");
                    if (req.flows.uploadCsv) uploadToGitHub(repo, config.csvFolder(), allFiles(false), "test data file");
                    closeGitHub();
                }
                if (req.flows.createSimulation) createSimulations();
                if (req.flows.createBatch) run.warn("Create batch is on hold, so it was skipped.");
                run.status = RunState.Status.PASSED;
            } catch (FlowException e) {
                fail(e.getMessage());
            } catch (Exception e) {
                e.printStackTrace(System.out);
                fail("Something unexpected went wrong: " + describe(e));
            } finally {
                if (signedIn) signOut();
                browser.close();
            }
        } catch (FlowException e) {
            fail(e.getMessage());
        } catch (Exception e) {
            e.printStackTrace(System.out);
            fail("Something unexpected went wrong: " + describe(e));
        }
        if (run.status == RunState.Status.PASSED) run.ok("All selected steps finished successfully.");
    }

    // ---------------------------------------------------------------- browser and sign-in

    private String findNode() {
        List<Path> candidates = new ArrayList<>();
        if (!config.get("node.path").isEmpty()) candidates.add(Paths.get(config.get("node.path")));
        Path bundled = BundledNode.prepare(run);
        if (bundled != null) candidates.add(bundled);
        String path = System.getenv("PATH");
        if (path != null) {
            for (String d : path.split(java.io.File.pathSeparator)) {
                if (d.trim().isEmpty()) continue;
                candidates.add(Paths.get(d.trim(), "node.exe"));
                candidates.add(Paths.get(d.trim(), "node"));
            }
        }
        candidates.add(Paths.get("C:\\Program Files\\nodejs\\node.exe"));
        for (Path p : candidates) {
            if (java.nio.file.Files.isRegularFile(p)) return p.toString();
        }
        throw new FlowException("Node.js was not found. Unzip EPP-Node-part1.zip and EPP-Node-part2.zip into "
                + BundledNode.appFolder().getParent() + " (the folder that holds the EPP-Automation folder), so that "
                + BundledNode.appFolder().resolve("node") + " has node.exe.gz.001 and node.exe.gz.002. Searched: "
                + BundledNode.searched() + ".");
    }

    private Browser launch(Playwright pw) {
        BrowserType.LaunchOptions options = new BrowserType.LaunchOptions()
                .setHeadless(!req.showBrowser)
                .setSlowMo(req.showBrowser ? 100 : 0);
        String exe = config.get("browser.executablePath");
        String channel = config.get("browser.channel");
        if (!exe.isEmpty()) options.setExecutablePath(Paths.get(exe));
        else if (!channel.isEmpty()) options.setChannel(channel);
        run.info(req.showBrowser
                ? "Opening a private browser window so you can watch the steps."
                : "Starting a hidden private browser. Tick \"Show browser\" if you want to watch.");
        try {
            return pw.chromium().launch(options);
        } catch (Exception e) {
            throw new FlowException("Could not start the browser (" + (exe.isEmpty() ? channel : exe)
                    + "). Check that it is installed, or change browser.channel in epp-automation.properties.");
        }
    }

    private void signIn() {
        run.info("Opening the EPP portal at " + config.eppUrl() + ".");
        epp.navigate(config.eppUrl());
        Locator msid = epp.getByPlaceholder("MSID");
        Locator home = epp.getByText("Next Steps").first();
        Locator first = firstVisible(config.longTimeout(), msid, home);
        if (first == msid) {
            run.info("Signing in as " + req.userName + ".");
            msid.fill(req.userName);
            epp.getByPlaceholder("Password").fill(req.password);
            epp.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName(ci("^sign in$"))).click();
            waitUntil(config.longTimeout(), () -> home.isVisible() || isMicrosoftSignIn(epp),
                    "Sign-in did not finish. Check the UserName and Password.");
            if (isMicrosoftSignIn(epp)) waitForMicrosoftSignIn(epp, () -> home.isVisible());
        } else {
            run.info("Already signed in to EPP.");
        }
        snap("Signed in to EPP");
        run.ok("Signed in to EPP.");
    }

    private boolean isMicrosoftSignIn(Page page) {
        return page.url().contains("login.microsoftonline.com") || page.url().contains("login.live.com");
    }

    /** Microsoft may ask for an extra step (for example an authenticator approval) that only a person can do. */
    private void waitForMicrosoftSignIn(Page page, BooleanSupplier done) {
        if (!req.showBrowser) {
            throw new FlowException("Microsoft is asking for an extra sign-in step. Tick \"Show browser\" and run again "
                    + "so you can complete it in the browser window.");
        }
        run.warn("Microsoft is asking you to sign in. Please complete it in the browser window; I'll wait up to "
                + config.longTimeout() / 60000 + " minutes.");
        waitUntil(config.longTimeout(), done, "Microsoft sign-in was not completed in time.");
    }

    private void signOut() {
        try {
            current = epp;
            epp.bringToFront();
            run.info("Signing out of EPP.");
            Locator avatar = epp.locator("xpath=//*[normalize-space()='Community']"
                    + "/following::*[self::button or contains(@class,'Avatar')][1]").first();
            avatar.click();
            epp.getByText(ci("^\\s*(log ?out|sign ?out)\\s*$")).first().click();
            run.ok("Signed out.");
        } catch (Exception e) {
            System.out.println("Sign-out failed: " + describe(e));
            run.warn("Could not sign out automatically. The private browser session is closed anyway, so nothing stays signed in.");
        }
    }

    // ---------------------------------------------------------------- application

    /**
     * Finds the application picker: the text at the left of the black bar that holds "Lab Schedule".
     * Marks it with data-epp-app and returns its text, or null if the bar is not there.
     */
    private static final String FIND_APP_PICKER = "() => {"
            + " document.querySelectorAll('[data-epp-app]').forEach(e => e.removeAttribute('data-epp-app'));"
            + " const all = [...document.querySelectorAll('body *')];"
            + " const lab = all.find(e => e.children.length === 0 && e.textContent.trim() === 'Lab Schedule');"
            + " if (!lab) return null;"
            + " const r = lab.getBoundingClientRect(); const y = r.top + r.height / 2;"
            + " const home = all.find(e => { const b = e.getBoundingClientRect();"
            + "   return e.children.length === 0 && e.textContent.trim() === 'Home' && b.top <= y && b.bottom >= y; });"
            + " const limit = home ? home.getBoundingClientRect().left : r.left;"
            + " const left = all.filter(e => { const b = e.getBoundingClientRect();"
            + "   return e.children.length === 0 && e.textContent.trim().length > 0 && b.width > 0"
            + "     && b.top <= y && b.bottom >= y && b.right <= limit; })"
            + "   .sort((p, q) => p.getBoundingClientRect().left - q.getBoundingClientRect().left);"
            + " if (!left.length) return null;"
            + " const pick = left[0].closest('button, [role=button], [aria-haspopup], [role=combobox]') || left[0];"
            + " pick.setAttribute('data-epp-app', '1');"
            + " return left[0].textContent.trim(); }";

    /** Scrolls an open dropdown list down by one screen. Returns false when it is already at the bottom. */
    private static final String SCROLL_LIST = "() => {"
            + " const item = [...document.querySelectorAll('[role=option], [role=menuitem], li')]"
            + "   .find(e => e.getBoundingClientRect().height > 0);"
            + " let box = item && item.parentElement;"
            + " while (box && box.scrollHeight <= box.clientHeight + 2) box = box.parentElement;"
            + " if (!box || box === document.body || box === document.documentElement) return false;"
            + " const before = box.scrollTop; box.scrollTop += box.clientHeight * 0.8; return box.scrollTop > before; }";

    private static final String LIST_ITEMS = "() => [...document.querySelectorAll('[role=option], [role=menuitem], li')]"
            + ".filter(e => e.getBoundingClientRect().height > 0).map(e => e.textContent.trim()).filter(t => t)"
            + ".slice(0, 40)";

    private String currentApp() {
        Object text = epp.evaluate(FIND_APP_PICKER);
        return text == null ? null : text.toString();
    }

    private void selectApplication() {
        String app = req.applicationName.trim();
        waitUntil(config.longTimeout(), () -> currentApp() != null,
                "The EPP menu bar (with Home and Lab Schedule) did not appear after sign-in.");
        String now = currentApp();
        if (now.equalsIgnoreCase(app)) {
            run.ok("Application \"" + app + "\" is already selected.");
        } else {
            run.info("Selecting the application \"" + app + "\" (EPP currently shows \"" + now + "\").");
            epp.locator("[data-epp-app]").first().click();
            Pattern exact = Pattern.compile("^\\s*" + literal(app) + "\\s*$", Pattern.CASE_INSENSITIVE);
            Locator items = epp.locator("[role=option], [role=menuitem], li").filter(new Locator.FilterOptions().setHasText(exact));
            Locator option = null;
            for (int i = 0; i < 20 && option == null; i++) {
                option = firstVisible(i == 0 ? config.stepTimeout() : 700, items);
                if (option == null && !Boolean.TRUE.equals(epp.evaluate(SCROLL_LIST))) break;
            }
            if (option == null) {
                Object seen = epp.evaluate(LIST_ITEMS);
                snap("Application list");
                throw new FlowException("The application \"" + app + "\" was not found in the EPP application list. "
                        + "The list showed: " + seen + ". Check the spelling.");
            }
            option.first().scrollIntoViewIfNeeded();
            option.first().click();
            waitUntil(config.stepTimeout(), () -> app.equalsIgnoreCase(currentApp()),
                    "EPP did not switch to \"" + app + "\".");
            run.ok("Selected the application \"" + app + "\".");
        }
        epp.waitForURL(Pattern.compile("/projects/[^/]+"));
        Matcher m = Pattern.compile("^(.*/projects/[^/?#]+)").matcher(epp.url());
        projectUrl = m.find() ? m.group(1) : epp.url();
        snap("Application selected");
    }

    // ---------------------------------------------------------------- GitHub

    private String openGitHubRepository(BrowserContext context) {
        run.info("Opening the application's GitHub repository from EPP.");
        epp.navigate(projectUrl);
        Locator link = epp.getByText("Access your GitHub Repository").first();
        Page gh;
        try {
            gh = context.waitForPage(new BrowserContext.WaitForPageOptions().setTimeout(10000), link::click);
        } catch (Exception e) {
            gh = epp; // the link opened in the same tab
        }
        current = gh;
        gh.waitForLoadState();

        Page page = gh;
        BooleanSupplier atRepo = () -> repoUrl.matcher(page.url()).find();
        waitUntil(config.longTimeout(), () -> atRepo.getAsBoolean() || page.getByRole(AriaRole.BUTTON,
                new Page.GetByRoleOptions().setName("Continue")).isVisible() || isMicrosoftSignIn(page),
                "GitHub did not open.");
        if (!atRepo.getAsBoolean() && page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Continue")).isVisible()) {
            run.info("GitHub asks for single sign-on. Continuing with the company account.");
            page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Continue")).click();
        }
        waitUntil(config.longTimeout(), () -> atRepo.getAsBoolean() || isMicrosoftSignIn(page), "GitHub sign-on did not finish.");
        if (!atRepo.getAsBoolean()) waitForMicrosoftSignIn(page, atRepo);

        Matcher m = repoUrl.matcher(page.url());
        m.find();
        String repo = m.group(1);
        snap("GitHub repository");
        run.ok("Opened the repository " + repo.substring(repo.lastIndexOf('/') + 1) + ".");
        return repo;
    }

    private void uploadToGitHub(String repo, String folder, List<Path> files, String kind) {
        if (files.isEmpty()) {
            run.warn("No " + kind + "s were chosen, so nothing was uploaded to " + folder + ".");
            return;
        }
        String branch = config.branch();
        run.info("Uploading " + files.size() + " " + kind + (files.size() == 1 ? "" : "s") + " to " + folder + ".");
        Response r = current.navigate(repo + "/upload/" + branch + "/" + folder);
        if (r != null && r.status() == 404) {
            throw new FlowException("GitHub could not open " + folder + " on branch " + branch
                    + ". The folder may not exist, or this account cannot write to the repository.");
        }
        current.locator("input[type=file]").first().setInputFiles(files.toArray(new Path[0]));
        for (Path f : files) {
            current.getByText(name(f), new Page.GetByTextOptions().setExact(true)).first()
                    .waitFor(new Locator.WaitForOptions().setTimeout(config.longTimeout()));
        }
        Locator commit = current.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName(ci("^commit changes$")));
        commit.scrollIntoViewIfNeeded();
        waitUntil(config.longTimeout(), commit::isEnabled, "GitHub did not finish receiving the files.");
        snap("Files ready to commit in " + folder);
        commit.click();
        waitUntil(config.longTimeout(), () -> !current.url().contains("/upload/"), "GitHub did not confirm the commit.");
        run.ok("Committed the " + kind + "s to " + folder + " on " + branch + ".");

        run.info("Checking that every " + kind + " is now in " + folder + ".");
        List<String> missing = new ArrayList<>();
        for (Path f : files) {
            String url = repo + "/blob/" + branch + "/" + folder + "/" + encode(name(f));
            Response check = current.navigate(url);
            if (check != null && check.status() == 200) run.ok("Found " + name(f) + " in " + folder + ".");
            else missing.add(name(f));
        }
        current.navigate(repo + "/tree/" + branch + "/" + folder);
        snap("Checked " + folder);
        if (!missing.isEmpty()) {
            throw new FlowException("These files are missing from " + folder + " after the upload: " + String.join(", ", missing));
        }
    }

    private void closeGitHub() {
        if (current != epp) current.close();
        current = epp;
        epp.bringToFront();
        epp.navigate(projectUrl);
    }

    // ---------------------------------------------------------------- simulations and scenarios

    private void createSimulations() {
        openSimulations();
        for (RunRequest.Scenario s : req.scenarios) {
            for (Path jmx : s.jmxFiles) {
                String plan = name(jmx);
                String sim = plan.replaceFirst("(?i)\\.jmx$", "");
                createSimulation(sim, plan);
                createScenario(sim, plan, "SmokeTest_" + sim, s.smoke, "Smoke");
                createScenario(sim, plan, "LoadTest_" + sim, s.load, "Load");
            }
        }
    }

    private void openSimulations() {
        run.info("Opening Test Execution > Simulations.");
        try {
            epp.getByText("Test Execution").first().click();
            epp.getByText("Simulations", new Page.GetByTextOptions().setExact(true)).first().click();
            epp.waitForURL(Pattern.compile("/simulations"));
        } catch (Exception e) {
            epp.navigate(projectUrl + "/simulations");
        }
        simulationsUrl = epp.url().replaceAll("[?#].*$", "");
        waitForTable();
    }

    private void createSimulation(String sim, String plan) {
        epp.navigate(simulationsUrl);
        waitForTable();
        if (findSimulationRow(plan) != null) {
            run.ok("Simulation " + sim + " already exists, so it was not created again.");
            return;
        }
        run.info("Creating the simulation " + sim + " for the test plan " + plan + ".");
        epp.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName(ci("^add simulation$"))).click();
        Locator dialog = epp.getByRole(AriaRole.DIALOG).last();
        dialog.getByLabel(ci("simulation name")).fill(sim);
        dialog.getByLabel(ci("jmeter test plan")).fill(plan);
        snap("Simulation " + sim + " filled in");
        submitDialog(dialog, "simulation " + sim);
        waitForTable();
        if (findSimulationRow(plan) == null) {
            throw new FlowException("The simulation " + sim + " was not found in the list after creating it.");
        }
        snap("Simulation " + sim + " created");
        run.ok("Created the simulation " + sim + ".");
    }

    private void createScenario(String sim, String plan, String scenario, RunRequest.TestSettings t, String kind) {
        epp.navigate(simulationsUrl);
        waitForTable();
        Locator row = findSimulationRow(plan);
        if (row == null) throw new FlowException("Could not find the simulation " + sim + " to add scenarios to.");
        Locator scenarios = row.getByRole(AriaRole.BUTTON, new Locator.GetByRoleOptions().setName(ci("scenario")));
        if (scenarios.count() == 0) scenarios = row.getByText(ci("scenarios?"));
        scenarios.first().click();
        epp.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName(ci("^add scenario$")))
                .waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE));
        waitForTable();
        if (findCell(scenario) != null) {
            run.ok(kind + " scenario " + scenario + " already exists, so it was not created again.");
            return;
        }

        run.info("Creating the " + kind.toLowerCase() + " scenario " + scenario + " with " + t.users + " users, "
                + t.rampup + "s ramp-up and " + t.duration + "s duration.");
        epp.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName(ci("^add scenario$"))).click();
        Locator dialog = epp.getByRole(AriaRole.DIALOG).last();
        dialog.getByLabel(Pattern.compile("^\\s*Name")).first().fill(scenario);
        dialog.getByLabel(ci("users")).first().fill(t.users);
        addSetting(dialog, 0, "TG1.RampUpPeriod", t.rampup);
        addSetting(dialog, 1, "TG1.Duration", t.duration);
        dialog.getByLabel(ci("number of load generators")).fill(t.loadGenerators);
        dialog.getByLabel(ci("number of cpu cores")).fill(t.cpuCores);
        dialog.getByLabel(ci("allocated heap memory")).fill(t.heapMemory);
        snap(kind + " scenario filled in");
        submitDialog(dialog, kind.toLowerCase() + " scenario " + scenario);

        boolean found = false;
        long end = System.currentTimeMillis() + config.stepTimeout();
        while (!found && System.currentTimeMillis() < end) {
            found = findCell(scenario) != null || epp.getByText(scenario).count() > 0;
            if (!found) epp.waitForTimeout(500);
        }
        snap(kind + " scenario created");
        if (found) run.ok("Created the " + kind.toLowerCase() + " scenario " + scenario + ".");
        else run.warn("Created the " + kind.toLowerCase() + " scenario, but could not see " + scenario + " in the list. Please check it in EPP.");
    }

    /** Clicks ADD SETTING, picks the property name from its list and types the value next to it. */
    private void addSetting(Locator dialog, int index, String property, String value) {
        dialog.getByRole(AriaRole.BUTTON, new Locator.GetByRoleOptions().setName(ci("add setting"))).click();
        Locator name = dialog.locator("input[role=combobox]").nth(index);
        name.click();
        name.fill(property);
        epp.getByRole(AriaRole.OPTION, new Page.GetByRoleOptions().setName(ci("^" + literal(property) + "$"))).first().click();
        name.locator("xpath=following::input[1]").fill(value);
    }

    private void submitDialog(Locator dialog, String what) {
        dialog.getByRole(AriaRole.BUTTON, new Locator.GetByRoleOptions().setName(ci("^create$"))).click();
        try {
            dialog.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.HIDDEN).setTimeout(config.stepTimeout()));
        } catch (Exception e) {
            snap("Could not create " + what);
            String errors = String.join("; ", dialog.locator(".Mui-error, [role=alert]").allInnerTexts()).trim();
            throw new FlowException("EPP did not accept the " + what + "."
                    + (errors.isEmpty() ? " See the last screenshot." : " The form says: " + errors.replaceAll("\\s+", " ")));
        }
    }

    /** Finds the simulation row by its test plan, switching to 100 rows per page if it is not on the first page. */
    private Locator findSimulationRow(String plan) {
        Locator cell = findCell(plan);
        if (cell == null && showAllRows()) cell = findCell(plan);
        return cell == null ? null : cell.locator("xpath=ancestor::*[self::tr or @role='row'][1]");
    }

    private Locator findCell(String text) {
        for (AriaRole role : new AriaRole[] {AriaRole.CELL, AriaRole.GRIDCELL}) {
            Locator cell = epp.getByRole(role, new Page.GetByRoleOptions().setName(text).setExact(true));
            if (cell.count() > 0) return cell.first();
        }
        Locator td = epp.locator("td").filter(new Locator.FilterOptions().setHasText(
                Pattern.compile("^\\s*" + literal(text) + "\\s*$")));
        return td.count() > 0 ? td.first() : null;
    }

    private boolean showAllRows() {
        Locator label = epp.getByText("Rows per page").first();
        if (!label.isVisible()) return false;
        Locator picker = label.locator("xpath=..")
                .locator("select, [role=combobox], [aria-haspopup=listbox], [role=button]").first();
        if (picker.innerText().contains("100")) return false;
        if (!toldAboutRows) run.info("Some records are not on the first page, so showing 100 rows per page.");
        toldAboutRows = true;
        if ("select".equalsIgnoreCase((String) picker.evaluate("e => e.tagName"))) {
            picker.selectOption("100");
        } else {
            picker.click();
            epp.getByRole(AriaRole.OPTION, new Page.GetByRoleOptions().setName("100").setExact(true)).click();
        }
        epp.waitForTimeout(1000);
        return true;
    }

    private void waitForTable() {
        try {
            epp.locator("tbody tr, [role=row]").first().waitFor();
            epp.waitForLoadState();
        } catch (Exception e) {
            // An empty table is fine; the callers check for the rows they need.
        }
    }

    // ---------------------------------------------------------------- helpers

    private List<Path> allFiles(boolean jmx) {
        List<Path> files = new ArrayList<>();
        for (RunRequest.Scenario s : req.scenarios) files.addAll(jmx ? s.jmxFiles : s.csvFiles);
        return files;
    }

    /** Waits until one of the locators is visible and returns it, or returns null on timeout. */
    private Locator firstVisible(int timeoutMs, Locator... candidates) {
        long end = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < end) {
            for (Locator c : candidates) {
                if (c.count() > 0 && c.first().isVisible()) return c;
            }
            current.waitForTimeout(300);
        }
        return null;
    }

    private void waitUntil(int timeoutMs, BooleanSupplier condition, String failure) {
        long end = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < end) {
            try {
                if (condition.getAsBoolean()) return;
            } catch (Exception ignored) {
                // The page may be navigating; try again.
            }
            current.waitForTimeout(500);
        }
        snap("Timed out");
        throw new FlowException(failure);
    }

    private void snap(String step) {
        try {
            String file = String.format("%02d.png", ++shotNo);
            current.screenshot(new Page.ScreenshotOptions().setPath(dir.resolve(file)));
            run.shot(step, file);
        } catch (Exception ignored) {
            // A missing screenshot should never stop a run.
        }
    }

    private void fail(String message) {
        snap("Where it stopped");
        run.error(message);
        savePageForTroubleshooting();
        run.status = RunState.Status.FAILED;
    }

    /** Saves the page's HTML where the run stopped, so the selectors can be checked (for example with Copilot). */
    private void savePageForTroubleshooting() {
        if (current == null) return;
        try {
            Path file = dir.resolve("page-at-failure.html");
            java.nio.file.Files.write(file, current.content().getBytes(StandardCharsets.UTF_8));
            run.info("Saved the page where it stopped as " + Paths.get("").toAbsolutePath().relativize(file.toAbsolutePath())
                    + " (" + current.url() + ") for troubleshooting.");
        } catch (Exception ignored) {
            // Troubleshooting help should never hide the real error.
        }
    }

    private static Pattern ci(String regex) {
        return Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
    }

    /** Escapes regex characters. Pattern.quote (\Q...\E) does not work in the browser's regex engine. */
    private static String literal(String s) {
        return s.replaceAll("[\\\\^$.|?*+()\\[\\]{}]", "\\\\$0");
    }

    private static String name(Path p) {
        return p.getFileName().toString();
    }

    private static String encode(String s) {
        return encodeUtf8(s).replace("+", "%20");
    }

    /** Playwright errors start with "Error {"; the useful part is the message='...' line. */
    private static String describe(Exception e) {
        String msg = e.getMessage() == null ? e.toString() : e.getMessage();
        Matcher m = Pattern.compile("message='([^\\n]*)").matcher(msg);
        return firstLine(m.find() ? m.group(1) : msg);
    }

    private static String encodeUtf8(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (java.io.UnsupportedEncodingException e) {
            throw new IllegalStateException(e);
        }
    }

    private static String firstLine(String s) {
        if (s == null) return "";
        String line = s.trim().split("\\R", 2)[0];
        return line.length() > 300 ? line.substring(0, 300) + "..." : line;
    }
}
