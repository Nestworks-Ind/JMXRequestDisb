# EPP Automation: notes for GitHub Copilot

This folder is a small Java app that automates performance-test setup in the EPP portal
(https://performance.optum.com) and GitHub, using **Playwright for Java** to drive Microsoft Edge.
The user fills a form on a local web page (http://localhost:8080) and presses Run.

## Hard rules

- **Java 8 only.** The client machine runs Java 8. Do not use `var`, `List.of`, `Map.of`, `Path.of`,
  `String.isBlank`, `strip`, `repeat`, text blocks, records, switch expressions or any API newer than Java 8.
  Use `Paths.get`, `Collections.singletonList`, `trim().isEmpty()` and so on.
- There is **no Maven** here. Do not suggest `mvn` commands. Build with `build.bat`, which compiles
  `src/main/java` against `epp-automation.jar` and updates that jar. Run with `run.bat`.
- Keep log messages in plain English for non-technical users (`run.info`, `run.ok`, `run.warn`, and
  `FlowException` messages). Never log the password.
- EPP and GitHub are **production**. Never add steps that delete files, simulations or scenarios.
- Regexes passed to Playwright run in the browser (JavaScript). Do not use `Pattern.quote`; use the
  `literal()` helper in EppFlows.java.

## Where things are

- `src/main/java/com/epp/automation/EppFlows.java`: every browser step. Main methods:
  `signIn`, `selectApplication` (application picker in the black menu bar, left of "Home"),
  `openGitHubRepository`, `uploadToGitHub`, `createSimulations`, `createScenario`, `signOut`.
- `App.java`: local web server (Javalin 4) and the run queue.
- `src/main/resources/public/index.html`: the form page.
- `epp-automation.properties`: URLs, Git folders, browser (`msedge` or `chrome`) and timeouts.

## How to troubleshoot a failing step

1. On the page, tick **Show browser** and run only the failing step to watch it.
2. Each run saves screenshots in `runs\<run id>\` (01.png, 02.png, ...).
3. When a run fails, the page HTML at that moment is saved as `runs\<run id>\page-at-failure.html`.
   Open that file and find the element the step should have clicked. Then change the locator in
   EppFlows.java to match it. Prefer `getByRole`, `getByText`, `getByLabel` and `getByPlaceholder`
   over CSS classes, because MUI class names change between releases.
4. Run `build.bat`, then `run.bat`, and try again.
