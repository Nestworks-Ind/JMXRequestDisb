# Fixing EPP Automation with VS Code and GitHub Copilot

You don't need Maven or internet access to change the code. `build.bat` compiles the code in `src`
and puts it into `epp-automation.jar`. Copilot reads `.github/copilot-instructions.md`, so it already
knows the project rules (Java 8, no Maven, production systems).

## One-time setup

1. **Install VS Code.** This is *Visual Studio Code* (blue icon), not *Visual Studio* (purple icon).
   Get it from your company software centre, or the "User Installer" from https://code.visualstudio.com,
   which needs no admin rights.
2. **Add Copilot to VS Code.** Open VS Code, press `Ctrl+Shift+X`, search **GitHub Copilot Chat** and press
   Install. Sign in with the same GitHub account you use for Copilot in Visual Studio (bottom-right corner).
3. **Check you can compile Java.** Open Command Prompt and type `javac -version`.
   - If it shows a version, you're done.
   - If it says "not recognized", download the **Microsoft Build of OpenJDK 17, Windows x64, ZIP** from
     https://learn.microsoft.com/java/openjdk/download and unzip it **into the EPP-Automation folder**.
     You should get a folder such as `EPP-Automation\jdk-17.0.13+11`. `build.bat` finds it automatically.
     (This is only for building. The app still runs on Java 8.)
4. **Unzip EPP-Automation-Dev.zip** over your existing EPP-Automation folder and say Yes to replacing
   files. Keep your `node` folder.
5. **Open the folder.** In VS Code choose **File > Open Folder**, pick `EPP-Automation`, and click
   "Yes, I trust the authors".

## Fixing a step (repeat as needed)

1. **Run it.** In VS Code choose **Terminal > Run Task > Run EPP Automation** (or double-click `run.bat`).
   On the page, tick **Show browser** and only the step that fails, then press Run.
2. **When it stops**, the log says why. It also saves the page HTML as
   `runs\<run id>\page-at-failure.html`, next to the screenshots.
3. **Ask Copilot.** Press `Ctrl+Alt+I` to open Copilot Chat and choose **Agent** (or **Edit**) mode at the
   bottom. Drag `src\main\java\com\epp\automation\EppFlows.java` and that `page-at-failure.html` into the
   chat box, then paste a prompt like the one below.
4. **Check and keep.** Copilot shows the changes in green and red. Click **Keep** if they look right.
5. **Build.** Close the black EPP Automation window, then press `Ctrl+Shift+B` in VS Code (or double-click
   `build.bat`). If it shows errors, paste them into Copilot Chat and ask it to fix them.
6. **Run again** (step 1). If it got worse, copy `backup\epp-automation-before-last-build.jar` over
   `epp-automation.jar`.

## Prompt to copy into Copilot Chat

```
The EPP Automation run stopped at the step "<name of the step, e.g. Selecting the application>".
The log said: "<paste the red error line>".
Attached are EppFlows.java and page-at-failure.html (the page when it stopped).
In page-at-failure.html, find the element the step should click or read, and change the locator in the
matching method of EppFlows.java so it works on this page. Keep Java 8 and the rules in
.github/copilot-instructions.md. Explain in two lines what you changed.
```

For the application dropdown, also say what you do by hand, for example:
"By hand I click the application name at the left of the black bar, a list opens, I scroll down and
click 'ServiceNow OF Performance Testing'."
