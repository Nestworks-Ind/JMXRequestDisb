// electron/main.js
// NestCraft — Desktop wrapper
// Spawns the Python Flask backend, shows a native desktop window.

const { app, BrowserWindow, shell, ipcMain, Menu, dialog } = require('electron');
const { spawn } = require('child_process');
const path  = require('path');
const fs    = require('fs');
const http  = require('http');

const APP_NAME    = 'NestCraft';
const APP_VERSION = '1.0.0';

let mainWindow    = null;
let pythonProcess = null;
let serverPort    = null;
let isQuitting    = false;

// ── Locate the bundled Python server executable ───────────────────────────────
function getPythonExe() {
  if (app.isPackaged) {
    const ext = process.platform === 'win32' ? '.exe' : '';
    return path.join(process.resourcesPath, 'python_app', `NestCraft${ext}`);
  }
  return null;
}

// ── Start the Flask backend ───────────────────────────────────────────────────
function startPythonServer() {
  return new Promise((resolve, reject) => {
    const exePath = getPythonExe();
    const timeout = setTimeout(() => reject(new Error('Python server timed out')), 60000);

    const onData = (data) => {
      const text = data.toString();
      const m = text.match(/JAC_PORT=(\d+)/);
      if (m && !serverPort) {
        serverPort = parseInt(m[1]);
        clearTimeout(timeout);
        resolve(serverPort);
      }
    };

    if (exePath && fs.existsSync(exePath)) {
      // Keys are bundled in config.py — no .env file needed
      // Optionally load .env from user home if it exists (for overrides)
      const envFile = path.join(app.getPath('home'), '.nestcraft', '.env');
      const envVars = { ...process.env };

      if (fs.existsSync(envFile)) {
        const lines = fs.readFileSync(envFile, 'utf8').split('\n');
        for (const line of lines) {
          const trimmed = line.trim();
          if (trimmed && !trimmed.startsWith('#')) {
            const idx = trimmed.indexOf('=');
            if (idx > 0) {
              const key = trimmed.slice(0, idx).trim();
              const val = trimmed.slice(idx + 1).trim();
              envVars[key] = val;
            }
          }
        }
      }
      // No else — config.py has all keys bundled, app runs without .env

      // Production: run bundled executable
      pythonProcess = spawn(exePath, [], {
        stdio: ['ignore', 'pipe', 'pipe'],
        env: envVars,
      });
    } else {
      // Dev mode: run with python
      const script = path.join(__dirname, '..', 'python_app', 'app.py');
      const py = process.platform === 'win32' ? 'python' : 'python3';
      pythonProcess = spawn(py, [script], { stdio: ['ignore', 'pipe', 'pipe'] });
    }

    pythonProcess.stdout.on('data', onData);
    pythonProcess.stderr.on('data', d => console.log('[py]', d.toString().trim()));
    pythonProcess.on('error', err => { clearTimeout(timeout); reject(err); });
    pythonProcess.on('exit', code => {
      if (!isQuitting) {
        dialog.showErrorBox('Backend Stopped',
          `NestCraft engine stopped (code ${code}).\nPlease restart the app.`);
      }
    });
  });
}

// ── Poll until Flask responds ─────────────────────────────────────────────────
function waitForServer(port, attempts = 0) {
  return new Promise((resolve) => {
    const try_ = () => {
      const req = http.get(`http://127.0.0.1:${port}/login`, (res) => {
        if (res.statusCode < 500) resolve();
        else setTimeout(try_, 400);
      });
      req.on('error', () => {
        if (attempts++ < 80) setTimeout(try_, 400);
        else resolve();
      });
      req.end();
    };
    try_();
  });
}

// ── Create native window ──────────────────────────────────────────────────────
function createWindow(port) {
  mainWindow = new BrowserWindow({
    width:     1440,
    height:    900,
    minWidth:  1100,
    minHeight: 680,
    title:     APP_NAME,
    icon:      path.join(__dirname, 'assets', 'icon.png'),
    backgroundColor: '#f7f5f0',
    webPreferences: {
      preload:          path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration:  false,
    },
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
    show: false,
  });

  // Show splash while backend warms up
  mainWindow.loadFile(path.join(__dirname, 'splash.html'));
  mainWindow.show();

  // Load login page once Flask is ready
  waitForServer(port).then(() => {
    mainWindow.loadURL(`http://127.0.0.1:${port}/login`);
  });

  mainWindow.on('closed', () => { mainWindow = null; });

  // ── Auto-save JMX directly to Downloads — no OS Save-As dialog ───────────
  // Strategy: intercept will-download, set item.savePath to the user's
  // Downloads folder + clean filename from Flask's Content-Disposition header.
  // No dialog appears. The frontend shows its own in-UI toast notification.
  // This avoids both the OS popup and the IP-address-in-filename problem.
  mainWindow.webContents.session.on('will-download', (event, item) => {
    const filename   = item.getFilename();   // clean name from Flask header
    const savePath   = path.join(app.getPath('downloads'), filename);
    item.savePath    = savePath;             // auto-save — no OS dialog

    item.once('done', (e, state) => {
      if (state === 'completed') {
        console.log('[download] saved to Downloads:', filename);
        // Notify the renderer so it can show the in-UI toast
        if (mainWindow && !mainWindow.isDestroyed()) {
          mainWindow.webContents.send('download-complete', { filename, savePath });
        }
      } else {
        console.error('[download] failed:', state, filename);
        if (mainWindow && !mainWindow.isDestroyed()) {
          mainWindow.webContents.send('download-failed', { filename });
        }
      }
    });
  });

  // Open external links in default browser
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  setMenu();
}

// ── App menu ──────────────────────────────────────────────────────────────────
function setMenu() {
  const isMac = process.platform === 'darwin';
  const template = [
    ...(isMac ? [{
      label: app.name,
      submenu: [
        { label: `About ${APP_NAME}`, click: showAbout },
        { type: 'separator' },
        { role: 'services' },
        { type: 'separator' },
        { role: 'hide' }, { role: 'hideOthers' }, { role: 'unhide' },
        { type: 'separator' },
        { role: 'quit' }
      ]
    }] : []),
    {
      label: 'File',
      submenu: [
        {
          label: 'New Analysis',
          accelerator: 'CmdOrCtrl+R',
          click: () => mainWindow?.loadURL(`http://127.0.0.1:${serverPort}/reset`)
        },
        { type: 'separator' },
        isMac ? { role: 'close' } : { role: 'quit', label: 'Exit' }
      ]
    },
    {
      label: 'Edit',
      submenu: [
        { role: 'undo' }, { role: 'redo' },
        { type: 'separator' },
        { role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { role: 'selectAll' }
      ]
    },
    {
      label: 'View',
      submenu: [
        { label: 'Reload', accelerator: 'F5', click: () => mainWindow?.reload() },
        { type: 'separator' },
        { role: 'resetZoom' }, { role: 'zoomIn' }, { role: 'zoomOut' },
        { type: 'separator' },
        { role: 'togglefullscreen' }
      ]
    },
    {
      label: 'Help',
      submenu: [
        ...(!isMac ? [
          { label: `About ${APP_NAME}`, click: showAbout },
          { type: 'separator' }
        ] : []),
        { label: 'NestWorks Website', click: () => shell.openExternal('https://nest-works.in') },
        { label: 'Email Support',     click: () => shell.openExternal('mailto:connect@nest-works.in') },
        { type: 'separator' },
        { label: 'User Manual',       click: () => mainWindow?.loadURL(`http://127.0.0.1:${serverPort}/app#help`) }
      ]
    }
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

function showAbout() {
  dialog.showMessageBox(mainWindow, {
    type:    'info',
    title:   `About ${APP_NAME}`,
    message: APP_NAME,
    detail:  `Version: ${APP_VERSION}\nPublisher: NestWorks\nWebsite: nest-works.in\n\nAutomatic JMeter correlation tool — detect dynamic values, generate RegexExtractors, add assertions and think time in one click.\n\nFor support: connect@nest-works.in`,
    buttons: ['OK'],
    icon:    path.join(__dirname, 'assets', 'icon.png'),
  });
}

// ── App lifecycle ─────────────────────────────────────────────────────────────
app.whenReady().then(async () => {
  try {
    const port = await startPythonServer();
    createWindow(port);
  } catch (err) {
    dialog.showErrorBox('Startup Error',
      `Could not start NestCraft.\n\n${err.message}\n\nPlease contact connect@nest-works.in for support.`);
    app.quit();
  }
});

app.on('window-all-closed', () => {
  isQuitting = true;
  if (pythonProcess) { try { pythonProcess.kill(); } catch(e){} }
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (!mainWindow && serverPort) createWindow(serverPort);
});

app.on('before-quit', () => {
  isQuitting = true;
  if (pythonProcess) { try { pythonProcess.kill(); } catch(e){} }
});

// ── IPC ───────────────────────────────────────────────────────────────────────
ipcMain.handle('open-external',  (_, url) => shell.openExternal(url));
ipcMain.handle('get-app-version', ()      => APP_VERSION);
