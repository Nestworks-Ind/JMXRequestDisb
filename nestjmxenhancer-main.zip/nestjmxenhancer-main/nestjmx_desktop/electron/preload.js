// electron/preload.js
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('electronAPI', {
  openExternal:    (url)      => ipcRenderer.invoke('open-external', url),
  getAppVersion:   ()         => ipcRenderer.invoke('get-app-version'),
  // Download event listeners — main process pushes these after auto-save
  onDownloadComplete: (cb)    => ipcRenderer.on('download-complete', (_e, data) => cb(data)),
  onDownloadFailed:   (cb)    => ipcRenderer.on('download-failed',   (_e, data) => cb(data)),
});
