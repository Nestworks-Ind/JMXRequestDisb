import re

def clean_invalid_xml_chars(input_path, output_path):
    """
    Reads the original JTL file, removes invalid XML characters,
    and writes a sanitized version to output_path.
    """
    # Matches characters not allowed in XML 1.0
    xml_illegal_chars_pattern = re.compile(
        r'[^\x09\x0A\x0D\x20-\xD7FF\xE000-\xFFFD]', re.UNICODE
    )

    try:
        with open(input_path, 'r', encoding='utf-8', errors='ignore') as fin:
            content = fin.read()
            cleaned = xml_illegal_chars_pattern.sub('', content)

        with open(output_path, 'w', encoding='utf-8') as fout:
            fout.write(cleaned)

        print(f"[✅] Cleaned JTL written to: {output_path}")
        return output_path

    except Exception as e:
        print(f"[❌] Error during cleaning JTL: {e}")
        return None
