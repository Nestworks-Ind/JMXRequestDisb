# core/regex_generator.py  — comprehensive fix
import re
import html
import urllib.parse

# Build marker — bump when the engine changes so we can confirm which copy is
# actually loaded by the running app (see diagnose_value.py).
__engine_build__ = "2026-06-19-robust-neighbour"


def normalize(text):
    if not text:
        return ""
    try:
        decoded = html.unescape(urllib.parse.unquote_plus(text))
    except Exception:
        decoded = text
    return decoded.strip()


def clean_text(text):
    return re.sub(r'\s+', ' ', normalize(text))


# Characters that re.escape() prefixes with a backslash but which carry no special
# meaning for JMeter's regex engine (ORO / Java). We keep them harmless, but the
# important one is whitespace: a boundary lifted from one response may render with
# different whitespace (single space vs newline + indentation vs CRLF vs tabs) in
# the live response JMeter matches against. Pinning the exact whitespace is the
# single most common cause of a pattern that validates here but yields
# "Match count: 0" in JMeter. _ws_flex() relaxes every run of literal/escaped
# whitespace OUTSIDE the capture group(s) to \s+ so the pattern matches regardless.
def _ws_flex(pattern: str) -> str:
    if not pattern:
        return pattern
    # Split out the capture group(s) so we never touch the captured value itself.
    parts = re.split(r'(\([^()]*\))', pattern)
    out = []
    for seg in parts:
        if seg.startswith('(') and seg.endswith(')'):
            out.append(seg)                      # capture group — leave intact
            continue
        # Collapse runs of (optionally backslash-escaped) literal whitespace → \s+
        seg = re.sub(r'(?:\\?[ \t\r\n\f\v])+', r'\\s+', seg)
        out.append(seg)
    return ''.join(out)


# A boundary may pin a NEIGHBOURING value that is itself dynamic (e.g. a repeated
# query param &sp=l350&sp=<target>, where l350 changes per session). When that
# neighbour is identical across the two recordings the engine can't tell it is
# dynamic and bakes it into the boundary, which then fails on different data.
# _generalize_ids() replaces id-looking literal tokens in the NON-capture
# segments with a delimiter-bounded wildcard, so the boundary tolerates the
# neighbour changing. The caller only adopts the result if it still matches
# uniquely in BOTH recordings, so structural/static tokens are never weakened
# into something ambiguous.
_ID_TOKEN = re.compile(r'(?<![\\\[A-Za-z0-9_])([A-Za-z]?[0-9][A-Za-z0-9]{2,})(?![A-Za-z0-9_])')

def _generalize_ids(pattern: str):
    if not pattern:
        return pattern, False
    parts = re.split(r'(\([^()]*\))', pattern)
    out = []
    changed = False
    for seg in parts:
        if (seg.startswith('(') and seg.endswith(')')) or '[' in seg:
            out.append(seg)                      # capture group / char-class — leave intact
            continue
        new = _ID_TOKEN.sub(lambda m: r"[A-Za-z0-9_.\-]+", seg)
        if new != seg:
            changed = True
        out.append(new)
    return ''.join(out), changed


# ── Encoding detection & pattern adaptation ───────────────────────────────────
# Maps decoded chars → their HTML entity equivalents seen in raw JTL responses
_HTML_ENCODE_MAP = {
    '"': '&quot;',
    "'": '&#39;',
    '<': '&lt;',
    '>': '&gt;',
    '&': '&amp;',
}
# Reverse: entity → decoded char (for checking raw text)
_HTML_DECODE_MAP = {v: k for k, v in _HTML_ENCODE_MAP.items()}


def _is_html_encoded(text: str) -> bool:
    """Returns True if the text contains HTML entities like &quot; &lt; &gt; &amp;"""
    return bool(re.search(r'&(?:quot|lt|gt|amp|apos);', text, re.I))


def _encode_boundary(boundary: str) -> str:
    """
    Re-encodes a decoded boundary string back to its HTML-entity form
    so the regex works against the raw (encoded) response that JMeter receives.
    e.g.  ID="   →   ID=&quot;
    """
    result = boundary
    # Must encode & first to avoid double-encoding
    result = result.replace('&', '&amp;')
    result = result.replace('"', '&quot;')
    result = result.replace("'", '&#39;')
    result = result.replace('<', '&lt;')
    result = result.replace('>', '&gt;')
    return result


def _make_encoded_pattern(decoded_pattern: str) -> str:
    """
    Given a regex pattern built against decoded text, produce an equivalent
    pattern that works against HTML-encoded raw response text.

    Strategy: encode the fixed literal parts (boundaries) while leaving
    the capture group (.+?) untouched.

    Works on patterns of the form:
        <left_literal>(.+?)<right_literal>
    where left/right are re.escape()-produced strings.
    """
    # Match the structure:  <escaped_left>(.+?)<escaped_right>
    # The capture group is always (.+?) in our generators
    m = re.match(r'^(.*?)(\(\..*?\))(.*)$', decoded_pattern, re.DOTALL)
    if not m:
        return decoded_pattern  # can't parse structure — return as-is

    left_escaped  = m.group(1)   # re.escape'd left boundary
    capture       = m.group(2)   # (.+?) or similar
    right_escaped = m.group(3)   # re.escape'd right boundary

    # Unescape the boundaries back to plain text so we can re-encode them
    try:
        left_plain  = re.sub(r'\\(.)', r'\1', left_escaped)
        right_plain = re.sub(r'\\(.)', r'\1', right_escaped)
    except Exception:
        return decoded_pattern

    # Re-encode the plain boundaries for HTML entity context
    left_encoded  = _encode_boundary(left_plain)
    right_encoded = _encode_boundary(right_plain)

    # If nothing changed, the response wasn't encoded — return original
    if left_encoded == left_plain and right_encoded == right_plain:
        return decoded_pattern

    return re.escape(left_encoded) + capture + re.escape(right_encoded)

# ── Strategy 1: XML/HTML tag boundary  <tag>VALUE</tag> ──────────────────────
def _try_xml_tag_boundary(value, response_text):
    """
    Handles <sessionToken>VALUE</sessionToken> and similar.
    Also handles tags with attributes: <span id="nonce">VALUE</span>,
    <div class="token">VALUE</div>, <input data-val="x">VALUE</input>.
    Priority: plain tag (no attributes) → tag with any attributes.
    """
    escaped = re.escape(value)

    # ── Sub-strategy A: plain tag — <tagname>VALUE</tagname> (original) ──────
    m = re.search(r'<([A-Za-z][A-Za-z0-9_:\-]*)>(\s*)' + escaped, response_text)
    if m:
        tag = re.escape(m.group(1))
        pattern = rf'<{tag}>(.+?)</{tag}>'
        try:
            matches = re.findall(pattern, response_text)
            if len(matches) >= 1 and value in matches:
                return pattern
        except re.error:
            pass

    # ── Sub-strategy B: tag with attributes — <tagname ...>VALUE</tagname> ───
    # Matches: <span id="nonce">VALUE, <div class="tok">VALUE, <input data-x="y">VALUE
    m2 = re.search(
        r'<([A-Za-z][A-Za-z0-9_:\-]*)\s[^>]*>(\s*)' + escaped,
        response_text
    )
    if m2:
        tag_name = m2.group(1)
        tag_esc  = re.escape(tag_name)
        # Pattern uses [^>]* to match any attributes — JMeter ORO compatible
        pattern = rf'<{tag_esc}[^>]*>(.+?)</{tag_esc}>'
        try:
            matches = re.findall(pattern, response_text)
            # Strip leading/trailing whitespace from each match for comparison
            stripped = [s.strip() for s in matches]
            if value in stripped:
                return pattern
        except re.error:
            pass

    return None


# ── Strategy 2: JavaScript variable  var x = 'VALUE' or x: 'VALUE' ──────────
def _try_js_boundary(value, response_text):
    """Handles var token='VALUE'; or token: 'VALUE', etc."""
    escaped = re.escape(value)
    # Try patterns like: varname = 'VALUE' or varname: 'VALUE'
    for q in ['"', "'"]:
        eq = re.escape(q)
        m = re.search(r'([A-Za-z_$][A-Za-z0-9_$]*)\s*[=:]\s*' + eq + escaped, response_text)
        if m:
            varname = re.escape(m.group(1))
            pattern = rf'{varname}\s*[=:]\s*{eq}(.+?){eq}'
            try:
                matches = re.findall(pattern, response_text)
                if len(matches) == 1 and matches[0] == value:
                    return pattern
            except re.error:
                pass
    return None


# ── Central validator ─────────────────────────────────────────────────────────
def _validate_pattern(pattern, value, text1, text2=None, template="$1$"):
    """
    Returns (is_valid, mc1, mc2, match_number, template).
    For single-group patterns: template is always "$1$".
    For multi-group patterns: template may be "$2$", "$3$" etc.
    is_valid=True when:
      - RD1 produces exactly 1 match == value  (mc1==1, unique), OR
      - RD1 produces multiple matches and value is in them (positional fallback)
    AND RD2 produces at least 1 match (any value — different recording).
    """
    try:
        m1 = re.findall(pattern, text1)
        m2 = re.findall(pattern, text2) if text2 else m1
    except re.error:
        return False, 0, 0, None, template

    # For multi-group patterns re.findall returns list of tuples
    # Extract the target group based on template e.g. "$2$" → index 1
    def _extract_group(matches, tmpl):
        if not matches:
            return []
        grp_idx = 0
        m = re.match(r'\$(\d+)\$', tmpl)
        if m:
            grp_idx = int(m.group(1)) - 1
        if isinstance(matches[0], tuple):
            return [t[grp_idx] if grp_idx < len(t) else "" for t in matches]
        return matches

    vals1 = _extract_group(m1, template)
    vals2 = _extract_group(m2, template)
    mc1, mc2 = len(vals1), len(vals2)

    # Validity is judged on RD1 ONLY. The extractor is injected into the RD1 JMX
    # and runs against RD1's responses at test time; RD2 is merely a second
    # recording used to detect that a value is dynamic. Requiring the SAME pattern
    # to also match RD2 (mc2>=1) wrongly rejected good RD1 patterns whenever the
    # two recordings rendered the value in slightly different surrounding markup
    # (a very common cause of spurious "No Regex"). mc2 is still returned for
    # information / confidence display, but never gates acceptance.
    if mc1 == 1 and vals1 and vals1[0] == value:
        return True, 1, mc2, 1, template                    # unique in RD1
    if mc1 > 1 and value in vals1:
        mn = vals1.index(value) + 1
        return True, mc1, mc2, mn, template                 # positional in RD1
    return False, mc1, mc2, None, template


# ── Right-trailer strategy ────────────────────────────────────────────────────
def _try_right_trailer(value, pre, post, decoded1, decoded2=None):
    """
    Builds LEFT_KEY=DELIM([^DELIM]+)DELIM,NEXT_KEY=DELIM_NEXT_VAL_DELIM
    by appending the next key:value token to the right boundary.
    Returns (pattern, match_number, template) or (None, None, None).
    """
    if not post:
        return None, None, None

    closing_q = post[0] if post[0] in ('"', "'") else None
    cap = rf'[^{re.escape(closing_q)}]+' if closing_q else r'[^,\s]+'

    # Find key:value tokens immediately to the right of the closing delimiter
    kv_pat = re.compile(
        r'["\']?([A-Za-z_$][A-Za-z0-9_$\-]*)["\']?\s*[:=]\s*["\']([^"\']+)["\']'
    )
    for kv in kv_pat.finditer(post[1:]):
        right_trail = post[:1] + post[1: 1 + kv.end()]

        # Build meaningful left boundary including field name
        left_b = _key_left_boundary(pre)
        if not left_b:
            continue

        pat = re.escape(left_b) + f'({cap})' + re.escape(right_trail)
        valid, mc1, mc2, mn, tmpl = _validate_pattern(pat, value, decoded1, decoded2)
        if valid and mc1 == 1:
            return pat, None, "$1$"
        # Keep trying more right context

    return None, None, None


def _strip_lead_delim(b):
    """Drop a single leading structural delimiter so a key boundary matches EVERY
    occurrence (stable match numbering for the positional case), e.g.
        ',"planHeaderId":"' -> '"planHeaderId":"'   ;   '&id=' -> 'id='
    The first occurrence in a body is often preceded by '{' or '[' rather than ','
    so anchoring on the delimiter would skip it and shift all match numbers."""
    return re.sub(r'^[\s,;{}\[\]()&]+', '', b)


def _key_left_boundary(pre):
    """
    Extract the key name + delimiter immediately left of the value.
    e.g.  pre = ...EmployerID="EMP-3917",ID="   →  returns  ,ID="
          pre = ...{"claimId":"               →  returns  "claimId":"
    Prefers including the field name over a bare quote.
    """
    m = re.search(
        r'(?:^|[,;\s{(\[])(["\']?[A-Za-z_$][A-Za-z0-9_$\-]*["\']?\s*[:=]\s*["\']?)$',
        pre
    )
    if m:
        return pre[m.start():]
    # Fallback: nearest delimiter
    for i in range(len(pre) - 1, -1, -1):
        if pre[i] in ('"', "'", '=', ',', '{', '[', '('):
            return pre[i:]
    return None


# ── Multi-capture group strategy ──────────────────────────────────────────────
def _try_multi_capture(value, pre, post, decoded1, decoded2=None):
    """
    When extending the left boundary would make it unique in RD1 but it breaks
    in RD2 because the left neighbour is also a dynamic value, replace that
    dynamic neighbour with a capture group.

    Example:
      RD1:  EmployerID="EMP-3917",ID="MBR-10002"
      RD2:  EmployerID="EMP-5541",ID="MBR-20099"

      Extended left fails:  EmployerID="EMP-3917",ID="(.+?)"
        → EMP-3917 not in RD2 → 0 matches

      Multi-capture succeeds:  EmployerID="(.+?)",ID="(.+?)"
        → group 1 = EMP-XXXX (dynamic anchor, any value)
        → group 2 = MBR-XXXXX (our target)
        → template $2$

    Algorithm:
      Walk left finding field=DELIM boundaries.
      For each left neighbour field whose value differs between RD1 and RD2,
      replace its static value with (.+?) to make it a dynamic anchor group.
      Test the resulting multi-group pattern on both recordings.
    """
    if not post:
        return None, None, None

    closing_q = post[0] if post[0] in ('"', "'") else None
    if not closing_q:
        return None, None, None

    cap = rf'[^{re.escape(closing_q)}]+'
    right_b = re.escape(post[:1])   # just the closing delimiter for now

    # Find all field=DELIM...value...DELIM segments walking left from the value
    # Pattern: KEY=DELIM VALUE DELIM SEPARATOR KEY=DELIM TARGET DELIM
    neighbour_pat = re.compile(
        r'([A-Za-z_$][A-Za-z0-9_$\-]*)' +          # field name
        rf'([=:]\s*[{re.escape(closing_q)}])' +       # =DELIM or :DELIM
        rf'([^{re.escape(closing_q)}]*)' +             # neighbour value
        rf'([{re.escape(closing_q)}])'                 # closing DELIM
    )

    # Find all neighbour field=value pairs to the left on this line
    neighbours = list(neighbour_pat.finditer(pre))

    # Try each neighbour as a dynamic anchor — nearest first
    for nb in reversed(neighbours):
        nb_field     = nb.group(1)                # e.g. "EmployerID"
        nb_sep       = nb.group(2)                # e.g. '="'
        nb_val_rd1   = nb.group(3)                # e.g. "EMP-3917"
        nb_close     = nb.group(4)                # e.g. '"'

        # Context between end of neighbour and start of our value
        separator    = pre[nb.end():]             # e.g.  ,ID="

        # Build multi-capture pattern:
        # FIELD_NAME=DELIM(.+?)DELIM SEPARATOR TARGET_LEFT_KEY=DELIM(.+?)DELIM
        target_left_key = _key_left_boundary(pre)
        if not target_left_key:
            continue

        pattern = (
            re.escape(nb_field) +
            re.escape(nb_sep) +
            f'({cap})' +                          # group 1 = dynamic neighbour
            re.escape(nb_close) +
            re.escape(separator) +
            f'({cap})' +                          # group 2 = our target
            right_b
        )

        # Validate: group 2 should equal value in RD1 AND in RD2
        valid, mc1, mc2, mn, _ = _validate_pattern(
            pattern, value, decoded1, decoded2, template="$2$"
        )
        if valid and mc1 == 1:
            return pattern, None, "$2$"

        # If unique in RD1 but positional, still better than bare match_number
        if valid:
            return pattern, mn, "$2$"

    # Try with more neighbours (3-group, 4-group) if 2-group failed
    if len(neighbours) >= 2:
        for i in range(len(neighbours) - 1, 0, -1):
            nb1 = neighbours[i - 1]; nb2 = neighbours[i]
            sep12    = pre[nb1.end():nb2.start()]
            sep2_end = pre[nb2.end():]
            target_left_key = _key_left_boundary(pre)
            if not target_left_key:
                continue
            pattern = (
                re.escape(nb1.group(1)) + re.escape(nb1.group(2)) +
                f'({cap})' + re.escape(nb1.group(4)) +
                re.escape(sep12) +
                re.escape(nb2.group(1)) + re.escape(nb2.group(2)) +
                f'({cap})' + re.escape(nb2.group(4)) +
                re.escape(sep2_end) +
                f'({cap})' + right_b
            )
            valid, mc1, mc2, mn, _ = _validate_pattern(
                pattern, value, decoded1, decoded2, template="$3$"
            )
            if valid and mc1 == 1:
                return pattern, None, "$3$"

    return None, None, None


# ── Full semantic boundary resolution ─────────────────────────────────────────
def _encoded_widen(value: str, raw_response: str, raw_response2: str = None):
    """
    Encoded analogue of the decoded 'left-widen' strategy. For a value that is
    closed by &quot; or & in an HTML-encoded response, expand the LITERAL left
    boundary at natural cut points (&quot; &gt; > ; whitespace) until the pattern
    becomes UNIQUE. This turns a fragile positional 'value=&quot;([^&]*)&quot;'
    match into a field-anchored one such as
        selectedScheduleId&quot; value=&quot;([^&]*)&quot;
    by pulling in the preceding id/name attribute. Tries every occurrence of the
    value, so it works even when an earlier (unquoted) occurrence appears first.
    """
    if not raw_response or not value:
        return None, None, "$1$"
    esc = re.escape(value)
    # Order occurrences by quality: quoted (&quot;VALUE&quot;) first — a human
    # prefers a quoted field — then &-closed (URL/query) values as a fallback.
    def _q(vm):
        after = raw_response[vm.end():]
        if after.startswith('&quot;'): return 0
        if after.startswith('&'):      return 1
        return 2
    for vm in sorted(re.finditer(esc, raw_response), key=_q):
        vstart = vm.start()
        after  = raw_response[vstart + len(value):]
        if   after.startswith('&quot;'): right = '&quot;'
        elif after.startswith('&'):      right = '&'
        else:                            continue
        cap  = r'([^&]*)'
        pre  = raw_response[:vstart]
        cuts = [m.end() for m in re.finditer(r'&quot;|&gt;|>|;|\s', pre)]
        for cp in reversed(cuts[-16:]):       # nearest 16 boundaries, widening out
            anchor = pre[cp:]
            if len(anchor) < 3:
                continue
            pat = re.escape(anchor) + cap + re.escape(right)
            try:
                valid, mc1, mc2, mn, tmpl = _validate_pattern(pat, value, raw_response, raw_response2)
                if valid and mc1 == 1:
                    return pat, None, "$1$"
            except re.error:
                pass
    return None, None, "$1$"


def _try_encoded_boundary(value: str, raw_response: str, raw_response2: str = None):
    """
    Strategy 0 (highest priority when response is HTML-encoded):
    Builds JMeter ORO-compatible regex against HTML-encoded responses.

    JMeter uses Jakarta ORO regex engine which does NOT support:
      - Negative lookbehind  (?<!...)
      - Lookahead            (?=...)  (?!...)
      - Non-capturing groups (?:...)

    All patterns use only: character classes [], literals, groups (), quantifiers.

    Handles:
      JSON encoded:    &quot;key&quot;:&quot;VALUE&quot;
      XML attribute:   KEY=&quot;VALUE&quot;  (e.g. ,ID=&quot;MBR-10008&quot;)
      XML element:     <Tag>&quot;VALUE&quot;</Tag>
      Bare quoted:     &quot;VALUE&quot;
    """
    if not raw_response or not value:
        return None, None, "$1$"

    esc_val = re.escape(value)

    # ── Variant A: &quot;KEY&quot;:&quot;VALUE&quot; (JSON encoded) ──────────────
    # ORO-safe: literal boundaries, no lookbehind needed
    for m in re.finditer(
        r'&quot;([A-Za-z_][A-Za-z0-9_]*)&quot;\s*:\s*&quot;' + esc_val + r'&quot;',
        raw_response
    ):
        key = re.escape(m.group(1))
        pat = rf'&quot;{key}&quot;:&quot;([^&]*)&quot;'
        try:
            valid, mc1, mc2, mn, tmpl = _validate_pattern(pat, value, raw_response, raw_response2)
            if valid and mc1 == 1:
                return pat, None, "$1$"
            if valid:
                return pat, mn if mn and mn > 1 else None, "$1$"
        except re.error:
            pass

    # ── Variant B: KEY=&quot;VALUE&quot; (XML/HTML attribute style) ────────────
    # ORO-safe: find the actual separator char before the key and include it
    # in the pattern literally. This avoids lookbehind entirely.
    # e.g. for ,ID=&quot;MBR-10008&quot; -> pattern is ,ID=&quot;([^&]*)&quot;
    # The separator char before the key distinguishes ID from EmployerID.
    kv_pat = re.compile(
        r'([^A-Za-z0-9_])([A-Za-z_][A-Za-z0-9_\-]*)=&quot;' + esc_val + r'&quot;'
    )
    candidates = []
    for m in kv_pat.finditer(raw_response):
        sep_char = re.escape(m.group(1))   # actual char before key e.g. ','
        key_raw  = m.group(2)
        key_esc  = re.escape(key_raw)
        # ORO-compatible: use literal separator + key
        pat = sep_char + key_esc + r'=&quot;([^&]*)&quot;'
        try:
            valid, mc1, mc2, mn, tmpl = _validate_pattern(pat, value, raw_response, raw_response2)
            if valid and mc1 == 1:
                return pat, None, "$1$"
            if valid:
                candidates.append((mc1, mn, pat))
        except re.error:
            pass

    # If key appears at start of string (no separator char) — use key alone
    m_start = re.match(
        r'([A-Za-z_][A-Za-z0-9_\-]*)=&quot;' + esc_val + r'&quot;',
        raw_response
    )
    if m_start:
        key_esc = re.escape(m_start.group(1))
        pat = key_esc + r'=&quot;([^&]*)&quot;'
        try:
            valid, mc1, mc2, mn, tmpl = _validate_pattern(pat, value, raw_response, raw_response2)
            if valid and mc1 == 1:
                return pat, None, "$1$"
            if valid:
                candidates.append((mc1, mn, pat))
        except re.error:
            pass

    # Before settling for a fragile positional match, widen the left boundary with
    # the preceding literal context (id/name attribute) to get a UNIQUE pattern.
    wpat, wmn, wtmpl = _encoded_widen(value, raw_response, raw_response2)
    if wpat:
        return wpat, wmn, wtmpl

    if candidates:
        candidates.sort(key=lambda x: x[0])
        _, mn, pat = candidates[0]
        return pat, mn if mn and mn > 1 else None, "$1$"

    # ── Variant C: value=&quot;VALUE&quot; (XML TokenSet / generic attr) ──────────
    # ORO-safe: find separator before 'value' key
    m_val = re.search(r'([^A-Za-z0-9_])value=&quot;' + esc_val + r'&quot;', raw_response)
    if m_val:
        sep_char = re.escape(m_val.group(1))
        pat = sep_char + r'value=&quot;([^&]*)&quot;'
        try:
            valid, mc1, mc2, mn, tmpl = _validate_pattern(pat, value, raw_response, raw_response2)
            if valid and mc1 == 1:
                return pat, None, "$1$"
            if valid:
                return pat, mn, "$1$"
        except re.error:
            pass

    # ── Variant D: &quot;VALUE&quot; bare (cookie / token values) ──────────────
    if f'&quot;{value}&quot;' in raw_response:
        pat = r'&quot;([^&]*)&quot;'
        try:
            valid, mc1, mc2, mn, tmpl = _validate_pattern(pat, value, raw_response, raw_response2)
            if valid and mc1 == 1:
                return pat, None, "$1$"
            if valid:
                return pat, mn, "$1$"
        except re.error:
            pass

    # ── Variant E: double-encoded &amp;quot; (.NET / some Java EE) ─────────────
    dbl_enc = raw_response.replace('&amp;quot;', '&quot;')
    if dbl_enc != raw_response and value in dbl_enc:
        return _try_encoded_boundary(value, dbl_enc, raw_response2)

    return None, None, "$1$"


_MAX_OCC = 24   # cap occurrences tried per value (see note in the loop below)

def _resolve_boundaries(value, decoded1, decoded2=None, raw1=None, raw2=None):
    """
    Tries all strategies in priority order. Returns (pattern, match_number, template).

    Priority:
      0. Encoded boundary (HTML-encoded responses — &quot; etc.)   → unique, $1$
      1. XML tag boundary                     → unique, $1$
      2. Simple left+right boundary           → unique, $1$
      3. Right-trailer (next key:val)         → unique, $1$
      4. Left-widen until unique              → unique, $1$
      5. Multi-capture group                  → unique, $2$ / $3$
      6. JS variable boundary                 → unique, $1$
      7. Positional match_number fallback     → multi-match, $1$, match_no N

    raw1/raw2: original un-decoded responses for Strategy 0
    """
    # ── Strategy 0: Encoded boundary (any platform: Java, Python, .NET) ──────
    if raw1 and _is_html_encoded(raw1):
        pat0, mn0, tmpl0 = _try_encoded_boundary(value, raw1, raw2)
        if pat0:
            return pat0, mn0, tmpl0

    # ── Strategy 1: XML tag ───────────────────────────────────────────────────
    # Accumulators for the "prefer both-recordings match" policy:
    #   best_rd1 — pattern unique in RD1 but NOT present in RD2 (RD2#=0); usable
    #              only as a last resort because the boundary is record-specific.
    #   best_pos — positional (mc1>1) fallback.
    # A pattern that is unique in RD1 AND also matches RD2 is returned immediately;
    # everything else is stashed so we keep searching for that both-match first.
    best_pos = (None, None, "$1$")
    best_rd1 = None

    def _consider(pat, tmpl="$1$"):
        nonlocal best_pos, best_rd1
        # Judge the WHITESPACE-FLEXIBLE form: a boundary that is "unique" only
        # because of an incidental run of whitespace (e.g. = followed by a newline
        # + indentation that happens only here) is fragile and fails in JMeter,
        # whose live response may render that gap differently. Flexing first forces
        # the search to keep widening until it finds a TOKEN-based unique boundary
        # (the field's own name), which is both unique and whitespace-tolerant.
        fpat = _ws_flex(pat)
        try:
            valid, mc1, mc2, mn, t = _validate_pattern(fpat, value, decoded1, decoded2, template=tmpl)
        except re.error:
            try:
                valid, mc1, mc2, mn, t = _validate_pattern(pat, value, decoded1, decoded2, template=tmpl)
                fpat = pat
            except re.error:
                return None
        if not valid:
            return None
        if mc1 == 1 and mc2 >= 1:
            return (fpat, None, tmpl)             # ✅ matches BOTH recordings — best
        if mc1 == 1:
            if best_rd1 is None:
                best_rd1 = (fpat, None, tmpl)     # unique in RD1 only (RD2#=0)
        elif mc1 > 1:
            if best_pos[0] is None:
                best_pos = (fpat, mn, tmpl)       # positional fallback
        return None

    pat = _try_xml_tag_boundary(value, decoded1)
    if pat:
        r = _consider(pat)
        if r: return r

    # Enumerate EVERY occurrence of the value across the WHOLE decoded response and
    # try them in quality order: quoted occurrences (value="X" / 'X') first, then
    # delimited (key=X&, X<, X, …), then anything else.
    occ = []
    s = 0
    while True:
        i = decoded1.find(value, s)
        if i == -1:
            break
        occ.append(i); s = i + 1

    def _occ_quality(i):
        a = decoded1[i + len(value)] if i + len(value) < len(decoded1) else ''
        b = decoded1[i - 1] if i > 0 else ''
        if a in ('"', "'") and b in ('"', "'", '=', '>'): return 0   # ="X"  >X"
        if a in ('"', "'"):                               return 1   # …X"
        if a in ('&', ',', ';', '<', '}', ']', '>'):      return 2   # key=X&  X<  X,
        return 3
    occ.sort(key=_occ_quality)

    # Bound the occurrence walk. When a value repeats many times (e.g. a grid id
    # echoed in every row) the tail occurrences re-derive the SAME non-unique
    # boundary the head ones already produced, so walking all of them is pure
    # waste — and on a ~1 MB body it cost up to ~165 s for a single value. Dedup
    # by local context (so identical surroundings are tried once) and cap to the
    # top-quality candidates; a genuine unique boundary lives among the quoted
    # occurrences at the front of the sorted list. Tunable via _MAX_OCC.
    _seen_ctx = set()
    _occ_capped = []
    for _i in occ:
        _ctx = (decoded1[max(0, _i - 24): _i], decoded1[_i + len(value): _i + len(value) + 24])
        if _ctx in _seen_ctx:
            continue
        _seen_ctx.add(_ctx)
        _occ_capped.append(_i)
        if len(_occ_capped) >= _MAX_OCC:
            break
    occ = _occ_capped

    for idx in occ:
        pre  = decoded1[max(0, idx - 400): idx]
        post = decoded1[idx + len(value): idx + len(value) + 200]

        # Find closing delimiter ('&' included for query/URL style key=val& values)
        closing_q = None
        right_char = ''
        for ch in post[:12]:
            if ch in ('"', "'", '}', ']', ',', '>', ';', '<', '&'):
                right_char = ch
                closing_q  = ch if ch in ('"', "'") else None
                break
        if not right_char:
            continue

        cap       = rf'[^{re.escape(closing_q)}]+' if closing_q else r'[^&,;"\'\s<>]+'
        esc_right = re.escape(right_char)

        # ── Strategy 2: Simple left boundary ─────────────────────────────────
        left_b = _key_left_boundary(pre)
        if left_b:
            r = _consider(re.escape(left_b) + f'({cap})' + esc_right)
            if r: return r

        # ── Strategy 3: Left-widen (walk back to the field's own name) ────────
        for i in range(len(pre) - 1, max(len(pre) - 350, -1), -1):
            if pre[i] in ('"', "'", '=', '>', ',', '{', '[', '&'):
                anchor = pre[i:]
                if len(anchor) < 2:
                    continue
                r = _consider(re.escape(anchor) + f'({cap})' + esc_right)
                if r: return r

        # ── Strategy 4: Right-trailer (append the following key:val) ──────────
        pat3, mn3, tmpl3 = _try_right_trailer(value, pre, post, decoded1, decoded2)
        if pat3:
            r = _consider(pat3, tmpl3)
            if r: return r

        # ── Strategy 5: Multi-capture group ───────────────────────────────────
        pat5, mn5, tmpl5 = _try_multi_capture(value, pre, post, decoded1, decoded2)
        if pat5:
            r = _consider(pat5, tmpl5)
            if r: return r

        # ── Strategy 6: JS variable ───────────────────────────────────────────
        js_pat = _try_js_boundary(value, decoded1)
        if js_pat:
            r = _consider(js_pat)
            if r: return r

    # ── Fallbacks: a both-match was not found. Prefer a unique-in-RD1 boundary
    #    (shown with RD2#=0 so the user can see it isn't cross-validated) over a
    #    positional match. ───────────────────────────────────────────────────
    if best_rd1:
        return best_rd1
    if best_pos[0]:
        return best_pos

    return None, None, "$1$"


# ── Main entry points ─────────────────────────────────────────────────────────
def extract_regex_with_dynamic_boundaries(value, response_text, response_text2=None):
    """
    Returns (pattern, match_number, template).
    template: "$1$" for single-group, "$2$"/"$3$" for multi-capture.
    match_number: None/1 = unique; >1 = positional fallback.
    """
    decoded1 = normalize(response_text)
    decoded2 = normalize(response_text2) if response_text2 else None
    return _resolve_boundaries(value, decoded1, decoded2, raw1=response_text, raw2=response_text2)


def expand_left_until_unique(value, response1, response2):
    """
    Kept for backward compatibility. Delegates to _resolve_boundaries.
    Returns (pattern, match_number, template).
    """
    decoded1 = normalize(response1)
    decoded2 = normalize(response2) if response2 else None
    return _resolve_boundaries(value, decoded1, decoded2, raw1=response1, raw2=response2)



def regex_for_form_field(field_name: str) -> str:
    """For application/x-www-form-urlencoded: key=VALUE&..."""
    return rf"(?<=\b{re.escape(field_name)}=)[^&]*"


# ── Header-sourced value regex generation ─────────────────────────────────────
def regex_for_header(header_text: str, value: str) -> dict:
    """
    Generates a JMeter-compatible regex to extract a dynamic value from
    response headers. Returns a dict:
      {
        "pattern":     <regex string>,
        "header_name": <e.g. 'Set-Cookie' or None if unknown>,
        "use_headers": True        # signals extractor_writer to set useHeaders=true
      }

    Handles these header formats:
      1. Simple header:       X-Auth-Token: VALUE
      2. Set-Cookie field:    Set-Cookie: name=VALUE; Path=/
      3. Cookie with quotes:  Set-Cookie: name="VALUE"; Path=/
      4. Location/URL param:  Location: /path?token=VALUE&other=x
      5. Fallback:            generic boundary pattern
    """
    if not header_text or not value:
        return {"pattern": None, "header_name": None, "use_headers": True}

    escaped_val = re.escape(value)
    lines = header_text.splitlines()

    for line in lines:
        if value not in line:
            continue

        header_name = None
        colon_idx = line.find(":")
        if colon_idx > 0:
            header_name = line[:colon_idx].strip()

        # ── Strategy 1: Simple header  →  Header-Name: VALUE ─────────────────
        m = re.match(
            r'^([A-Za-z0-9_\-]+)\s*:\s*(?:Bearer\s+|Basic\s+|Token\s+)?' + escaped_val + r'\s*$',
            line.strip()
        )
        if m:
            hn = re.escape(m.group(1))
            pattern = rf'{hn}:\s*(?:Bearer\s+|Basic\s+|Token\s+)?(.+?)[\r\n]'
            return {"pattern": pattern, "header_name": m.group(1), "use_headers": True}

        # ── Strategy 2: Set-Cookie with = (unquoted) ─────────────────────────
        m = re.search(r'([A-Za-z0-9_\-]+)=' + escaped_val + r'(?=[;\s,]|$)', line)
        if m:
            cookie_field = re.escape(m.group(1))
            pattern = rf'{cookie_field}=([^;\s,\r\n]+)'
            return {"pattern": pattern, "header_name": header_name, "use_headers": True}

        # ── Strategy 3: Set-Cookie with = (quoted) ───────────────────────────
        m = re.search(r'([A-Za-z0-9_\-]+)="' + escaped_val + r'"', line)
        if m:
            cookie_field = re.escape(m.group(1))
            pattern = rf'{cookie_field}="([^"]+)"'
            return {"pattern": pattern, "header_name": header_name, "use_headers": True}

        # ── Strategy 4: URL query param in Location/Redirect header ──────────
        m = re.search(r'([A-Za-z0-9_\-]+)=' + escaped_val + r'(?=[&\s]|$)', line)
        if m:
            param = re.escape(m.group(1))
            pattern = rf'{param}=([^&\s\r\n]+)'
            return {"pattern": pattern, "header_name": header_name, "use_headers": True}

        # ── Strategy 5: Fallback — generic boundary ───────────────────────────
        idx = line.find(value)
        if idx >= 0:
            pre  = line[max(0, idx - 30):idx]
            post = line[idx + len(value):idx + len(value) + 10]
            left_delim = ""
            for ch in reversed(pre):
                if ch in (':', '=', '"', "'", ' ', '\t'):
                    left_delim = re.escape(ch)
                    break
            right_delim = ""
            for ch in post:
                if ch in (';', ',', '"', "'", ' ', '\r', '\n'):
                    right_delim = re.escape(ch)
                    break
            if left_delim or right_delim:
                pattern = rf'{left_delim}(.+?){right_delim}' if right_delim else rf'{left_delim}(.+?)[\r\n]'
                return {"pattern": pattern, "header_name": header_name, "use_headers": True}

    return {"pattern": None, "header_name": None, "use_headers": True}


# ── Encoding-aware regex generation (main entry point) ────────────────────────
def generate_regex_for_response(value: str, raw_response: str, raw_response2: str = None):
    """
    Unified entry point. Returns (pattern, match_number, template).

    template: "$1$"  → single-group, JMeter extracts group 1
              "$2$"  → multi-capture, JMeter extracts group 2 (dynamic neighbour in group 1)
              "$3$"  → three-group pattern

    match_number: None/1 = unique extraction; >1 = positional fallback (fragile).

    Encoding awareness: if the raw response is HTML-encoded, the returned
    pattern's boundaries are re-encoded to match what JMeter sees on the wire.
    """
    if not value or not raw_response:
        return None, None, "$1$"

    encoded_response = _is_html_encoded(raw_response)
    decoded1 = normalize(raw_response)
    decoded2 = normalize(raw_response2) if raw_response2 else None

    # ── Run full strategy pipeline — passes raw responses for Strategy 0 ─────
    pat, mn, tmpl = _resolve_boundaries(value, decoded1, decoded2, raw1=raw_response, raw2=raw_response2)
    if not pat:
        return None, None, "$1$"

    # ── Plain response — decoded pattern works directly ───────────────────────
    if not encoded_response:
        # Make whitespace in the boundary tolerant, then confirm the relaxed
        # pattern still matches UNIQUELY against the RAW response (what JMeter
        # actually sees). \s+ matches a single space, a newline, tabs, CRLF, or
        # indentation alike, so it works against both our normalized copy and the
        # live body. Only adopt it if it stays unique in RD1.
        chosen, chosen_mn = pat, mn
        flex = _ws_flex(pat)
        if flex != pat:
            try:
                v_norm, mc1n, mc2n, mnn, _ = _validate_pattern(flex, value, decoded1, decoded2, template=tmpl)
                v_raw,  mc1r, mc2r, _,   _ = _validate_pattern(flex, value, raw_response,
                                                               raw_response2 or raw_response, template=tmpl)
                if v_norm and mc1n == 1 and mc1r == 1:
                    chosen, chosen_mn = flex, (mnn if mnn else mn)
            except re.error:
                pass

        # Robustness pass: generalize id-like NEIGHBOUR values in the boundary so
        # the pattern survives them changing on different data — but only adopt it
        # when it stays unique in BOTH recordings AND against the raw body, so we
        # never degrade a good unique-in-both correlation into an ambiguous one.
        gpat, changed = _generalize_ids(chosen)
        if changed:
            try:
                vg_n, gmc1, gmc2, gmn, _ = _validate_pattern(gpat, value, decoded1, decoded2, template=tmpl)
                vg_r, gmc1r, gmc2r, _, _ = _validate_pattern(gpat, value, raw_response,
                                                             raw_response2 or raw_response, template=tmpl)
                both_ok = (decoded2 is None) or (gmc2 == 1)
                if vg_n and gmc1 == 1 and both_ok and gmc1r == 1:
                    return gpat, (gmn if gmn else chosen_mn), tmpl
            except re.error:
                pass
        return chosen, chosen_mn, tmpl

    # ── Encoded response — re-encode all boundary literals ───────────────────
    # For multi-group patterns we need to encode boundaries between ALL groups
    encoded_pat = _make_encoded_pattern_multigroup(pat)
    encoded_pat = _ws_flex(encoded_pat)

    # Validate encoded pattern against raw response
    valid, mc1, mc2, mn_enc, _ = _validate_pattern(
        encoded_pat, value, raw_response, raw_response2, template=tmpl
    )
    if valid:
        return encoded_pat, mn_enc if mn_enc else mn, tmpl

    # Fallback: decoded pattern (JMeter may decode before matching)
    return _ws_flex(pat), mn, tmpl


def _make_encoded_pattern_multigroup(decoded_pattern: str) -> str:
    """
    Extends _make_encoded_pattern to handle multi-group patterns by encoding
    ALL literal segments between capture groups.
    e.g. EmployerID="(.+?)",ID="(.+?)"
      →  EmployerID=&quot;(.+?)&quot;,ID=&quot;(.+?)&quot;
    """
    # Split pattern on capture groups — encode literals, leave groups intact
    parts = re.split(r'(\([^)]+\))', decoded_pattern)
    encoded_parts = []
    for part in parts:
        if part.startswith('(') and part.endswith(')'):
            encoded_parts.append(part)   # capture group — leave untouched
        else:
            # Unescape, encode, re-escape
            try:
                plain = re.sub(r'\\(.)', r'\1', part)
                encoded = _encode_boundary(plain)
                encoded_parts.append(re.escape(encoded) if encoded != plain else part)
            except Exception:
                encoded_parts.append(part)
    return ''.join(encoded_parts)

