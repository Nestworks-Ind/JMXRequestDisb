import xml.etree.ElementTree as ET
import re
import html
import urllib.parse

# ----- helpers -----
def clean_xml_file(input_path):
    with open(input_path, 'r', encoding='utf-8', errors='ignore') as f:
        raw_xml = f.read()

    cleaned = ''.join(c for c in raw_xml if (
        c == '\t' or c == '\n' or c == '\r' or
        '\u0020' <= c <= '\uD7FF' or
        '\uE000' <= c <= '\uFFFD'
    ))
    cleaned = re.sub(r'&(?!amp;|lt;|gt;|quot;|apos;)', '&amp;', cleaned)
    return cleaned

def extract_numeric_id(label):
    try:
        return int(label.strip().split()[0])
    except Exception:
        return None

def normalize(text):
    if not text:
        return ""
    try:
        return html.unescape(urllib.parse.unquote_plus(text)).strip()
    except:
        return text.strip()

# --- NEW: generate tolerant variants for look-alikes + encodings ---
def _value_variants(val: str):
    if not val:
        return []

    v = str(val)
    variants = set()

    # raw + case variants
    variants.add(v)
    variants.add(v.lower())
    variants.add(v.upper())

    # If it looks like leading I/l/1 followed by digits, generate swaps
    m = re.match(r'^([Il1])(\d+)$', v)
    if m:
        rest = m.group(2)
        for ch in ('I', 'l', '1'):
            variants.add(ch + rest)
            variants.add((ch + rest).lower())
            variants.add((ch + rest).upper())

    # URL/HTML encodings
    enc_plus = urllib.parse.quote_plus(v)
    enc_pct  = urllib.parse.quote(v, safe="")
    variants.add(enc_plus)
    variants.add(enc_pct)
    variants.add(f'&quot;{v}&quot;')   # common in JTL
    variants.add(f'"{v}"')
    variants.add(f"'{v}'")

    # Also produce encodings for the leading-char swaps (if applicable)
    more = set()
    for s in list(variants):
        more.add(urllib.parse.quote_plus(s))
        more.add(urllib.parse.quote(s, safe=""))
    variants |= more

    return [x for x in variants if x]

def contains_dynamic_value(response, dynamic_value):
    norm_response = normalize(response)
    if not dynamic_value or not norm_response:
        return False

    # Try direct (fast path)
    if dynamic_value in norm_response:
        return True

    # Case-insensitive & variant search (handles I/l/1, encodings, quotes, etc.)
    norm_lower = norm_response.lower()
    for cand in _value_variants(dynamic_value):
        if cand.lower() in norm_lower:
            return True

    # As a last resort, try a permissive regex around URL param contexts like sp=<val>
    # Build a small class for the first char if pattern matches e.g. ^[Il1]\d+$
    m = re.match(r'^([Il1])(\d+)$', str(dynamic_value))
    if m:
        chclass = '[Il1]'
        rest = m.group(2)
        pat = rf'{chclass}{re.escape(rest)}'
        if re.search(pat, norm_response, flags=re.IGNORECASE):
            return True

    return False

# ----- main tracing -----
def trace_origin(jtl_path, request_name, dynamic_value, request_filters=None, enforce_filters=False):
    print(f"\n[DEBUG] Tracing value: {dynamic_value}")
    print(f"[DEBUG] Looking for usage in: {request_name}")

    try:
        cleaned_xml = clean_xml_file(jtl_path)
        root = ET.fromstring(cleaned_xml)
    except Exception as e:
        print(f"[DEBUG] XML Parse Error: {e}")
        return {"FoundInRequestID": None, "MatchedResponse": None, "Error": f"XML Parse Error: {e}"}

    target_id = None
    for sample in root.findall(".//httpSample"):
        label = sample.get("lb") or ""
        if str(request_name) in label:
            target_id = extract_numeric_id(label)
            print(f"[DEBUG] Found usage at ID: {target_id}")
            break

    if target_id is None:
        print("[DEBUG] Target request ID not found.")
        return {"FoundInRequestID": None, "MatchedResponse": None, "Error": "Target request ID not found"}

    for sample in reversed(root.findall(".//httpSample")):
        label = sample.get("lb") or ""
        current_id = extract_numeric_id(label)

        if current_id is None or current_id >= target_id:
            continue

        if enforce_filters and request_filters:
            if not any(partial in label for partial in request_filters):
                continue

        response_data    = sample.findtext("responseData",   default="")
        response_headers = sample.findtext("responseHeader", default="")

        # ── Check response BODY first ──────────────────────────────────────────
        if contains_dynamic_value(response_data, dynamic_value):
            print(f"[DEBUG] ✅ Match found in BODY at ID: {current_id}")
            print(f"[DEBUG] Origin response size: {len(response_data)}")
            return {
                "FoundInRequestID": label,
                "MatchedResponse":  normalize(response_data),
                "FoundInHeader":    False
            }

        # ── Check response HEADERS if not in body ─────────────────────────────
        if contains_dynamic_value(response_headers, dynamic_value):
            print(f"[DEBUG] ✅ Match found in HEADERS at ID: {current_id}")
            print(f"[DEBUG] Header text: {response_headers[:200]}")
            return {
                "FoundInRequestID": label,
                "MatchedResponse":  normalize(response_headers),
                "FoundInHeader":    True
            }

    print("[DEBUG] ❌ Value not found before or at target request.")
    return {"FoundInRequestID": None, "MatchedResponse": None, "FoundInHeader": False, "Error": "Value not found in responses"}
