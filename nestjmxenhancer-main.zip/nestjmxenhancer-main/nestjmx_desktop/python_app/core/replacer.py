# replacer.py — revised to update HTTP arguments for form posts
from lxml import etree as ET
import re
import logging

# Optional bulk presence (same engines used elsewhere). Used to skip, per sampler,
# the vast majority of selected values that don't occur in it — turning an
# O(samplers × values) scan into one automaton pass per sampler. If neither engine
# is present the replacer falls back to checking every value (original behaviour).
try:
    import ahocorasick_rs as _AHO_RS
except Exception:
    _AHO_RS = None
try:
    import ahocorasick as _AHO
except Exception:
    _AHO = None

def _boundary_replace(text, old, new):
    """Replace `old` with `new` only where `old` is a COMPLETE token — i.e. not
    flanked by another alphanumeric character. This stops a short value like '123'
    from corrupting a longer value such as '12345' (-> '${V}45') or being replaced
    inside an unrelated number like '91237'. Returns (new_text, count)."""
    if not old or old not in text:
        return text, 0
    pat = r'(?<![A-Za-z0-9])' + re.escape(old) + r'(?![A-Za-z0-9])'
    # lambda replacement so $ { } \ in the JMeter var name are inserted literally
    return re.subn(pat, lambda m: new, text)


def _replace_form_arg_in_sampler(sampler, field_name: str, new_value: str) -> bool:
    args = sampler.find(".//elementProp[@name='HTTPsampler.Arguments']")
    if args is None:
        return False
    changed = False
    for el in args.findall(".//elementProp[@elementType='HTTPArgument']"):
        n = el.find(".//stringProp[@name='Argument.name']")
        v = el.find(".//stringProp[@name='Argument.value']")
        if n is not None and v is not None and (n.text or "") == field_name:
            v.text = new_value
            changed = True
    return changed

def _replace_form_arg_by_value(sampler, old_value: str, new_value: str) -> int:
    """
    Fallback: if we don't know the field name, replace by matching the current value.
    Returns number of replacements.
    """
    args = sampler.find(".//elementProp[@name='HTTPsampler.Arguments']")
    if args is None:
        return 0
    count = 0
    for el in args.findall(".//elementProp[@elementType='HTTPArgument']"):
        v = el.find(".//stringProp[@name='Argument.value']")
        if v is not None and (v.text or "") == old_value:
            v.text = new_value
            count += 1
    return count

def replace_values_in_jmx(jmx_path, replacements):
    """
    replacements: list of dicts, each may contain:
      - request_label: sampler label where extractor is attached (origin)
      - regex_name:    JMeter variable name
      - original_value: the RD1 dynamic value to replace
      - form_field:     (optional) the form field name (for x-www-form-urlencoded)
    """
    try:
        parser = ET.XMLParser(remove_blank_text=True, recover=True, huge_tree=True)
        tree = ET.parse(jmx_path, parser)
        root = tree.getroot()

        # Replace LONGER values first so a short value can never be applied inside a
        # longer one before the longer one has been substituted.
        replacements = sorted(
            replacements,
            key=lambda r: len(r.get('original_value') or ''),
            reverse=True,
        )

        # ── Presence pre-filter ──────────────────────────────────────────────
        # Build one automaton over the distinct original values. For each sampler
        # we then find (in a single pass over its text) which values actually occur
        # there, and only attempt those replacements — instead of testing all N
        # selected values against every sampler. Falls back to "check all" when no
        # engine is available, so behaviour is identical, just slower.
        _distinct = []
        _seen = set()
        for r in replacements:
            ov = r.get('original_value')
            if ov and ov not in _seen:
                _seen.add(ov); _distinct.append(ov)
        _ac = None; _ac_kind = None
        if _distinct and _AHO_RS is not None:
            _ac = _AHO_RS.AhoCorasick(_distinct); _ac_kind = "rs"
        elif _distinct and _AHO is not None:
            _ac = _AHO.Automaton()
            for _i, _v in enumerate(_distinct):
                _ac.add_word(_v, _i)
            _ac.make_automaton(); _ac_kind = "py"

        def _present_in(text):
            """Set of original values occurring in `text`, or None (⇒ check all)."""
            if _ac is None or not text:
                return None if _ac is None else set()
            if _ac_kind == "rs":
                return set(_distinct[i] for (i, _s, _e) in _ac.find_matches_as_indexes(text, overlapping=True))
            return set(_distinct[i] for _e, i in _ac.iter(text))

        _SEP = "\x00"

        for sampler in root.xpath('.//HTTPSamplerProxy'):
            path_elem = sampler.find(".//stringProp[@name='HTTPSampler.path']")
            body_elem = sampler.find(".//stringProp[@name='Argument.value']")
            hash_tree = sampler.getnext()
            header_mgr = hash_tree.find(".//HeaderManager") if hash_tree is not None else None
            header_value_elems = (header_mgr.findall(".//stringProp[@name='Header.value']")
                                  if header_mgr is not None else [])
            arg_value_elems = sampler.findall(
                ".//elementProp[@elementType='HTTPArgument']/stringProp[@name='Argument.value']")

            # One presence pass over everything this sampler contains.
            _blob_parts = []
            if path_elem is not None and path_elem.text: _blob_parts.append(path_elem.text)
            if body_elem is not None and body_elem.text: _blob_parts.append(body_elem.text)
            for _e in header_value_elems:
                if _e.text: _blob_parts.append(_e.text)
            for _e in arg_value_elems:
                if _e.text: _blob_parts.append(_e.text)
            present = _present_in(_SEP.join(_blob_parts)) if _blob_parts else set()

            def _skip(ov):
                # present is None ⇒ no engine ⇒ never skip (check all).
                return present is not None and ov not in present

            # Replace in path
            if path_elem is not None and path_elem.text:
                for r in replacements:
                    ov = r['original_value']
                    if ov and not _skip(ov):
                        new_text, n = _boundary_replace(
                            path_elem.text, ov, '${' + r['regex_name'] + '}')
                        if n:
                            path_elem.text = new_text
                            logging.info(f"[INFO] Replaced in path ({n}x): {ov} -> ${{{r['regex_name']}}}")

            # Replace in form arguments (field-name path is unconditional; the
            # by-value fallback is presence-gated)
            for r in replacements:
                var = '${' + r['regex_name'] + '}'
                ff  = r.get('form_field')
                ov  = r.get('original_value') or ""
                replaced = False
                if ff:
                    replaced = _replace_form_arg_in_sampler(sampler, ff, var)
                    if replaced:
                        logging.info(f"[INFO] Replaced form field '{ff}' with {var}")
                if not replaced and ov and not _skip(ov):
                    cnt = _replace_form_arg_by_value(sampler, ov, var)
                    if cnt:
                        logging.info(f"[INFO] Replaced {cnt} form argument(s) matching '{ov}' with {var}")

            # Replace in raw body (kept for JSON/raw)
            if body_elem is not None and body_elem.text:
                for r in replacements:
                    ov = r.get('original_value')
                    if ov and not _skip(ov):
                        new_text, n = _boundary_replace(
                            body_elem.text, ov, '${' + r['regex_name'] + '}')
                        if n:
                            body_elem.text = new_text
                            logging.info(f"[INFO] Replaced in raw body ({n}x): {ov} -> ${{{r['regex_name']}}}")

            # Replace in headers
            for value_elem in header_value_elems:
                if value_elem.text:
                    for r in replacements:
                        ov = r.get('original_value')
                        if ov and not _skip(ov):
                            new_text, n = _boundary_replace(
                                value_elem.text, ov, '${' + r['regex_name'] + '}')
                            if n:
                                value_elem.text = new_text
                                logging.info(f"[INFO] Replaced in header ({n}x): {ov} -> ${{{r['regex_name']}}}")

        tree.write(jmx_path, encoding='utf-8', pretty_print=True, xml_declaration=True)
        logging.info("[SUMMARY] Completed replacements in JMX")
        return True

    except Exception as e:
        logging.error(f"[ERROR] replace_values_in_jmx: {e}")
        return False
