# transaction_matcher.py — enhanced with URL+body similarity matching

import re
from bs4 import BeautifulSoup
from urllib.parse import urlparse
from difflib import SequenceMatcher


# ── Normalize request name (old approach — strips numeric IDs from path) ──────
def normalize(name):
    if not name or "/" not in name:
        return ""
    name = name[name.index("/"):]
    return re.sub(r'(?<=/)\d+(?=/)', '', name).strip().lower()


# ── NEW: URL-based similarity matching for JMeter numeric-only names ──────────
def _url_similarity(url1: str, url2: str) -> float:
    """
    Computes structural similarity between two URLs.
    Strips numeric path segments and query-string values to focus on shape.
    Returns 0.0–1.0.
    """
    if not url1 or not url2:
        return 0.0

    def _normalize_url(u):
        u = (u or "").strip()
        # Remove query string
        u = u.split("?")[0]
        # Strip leading numeric prefix like "635 /path" → "/path"
        u = re.sub(r'^\d+\s+', '', u)
        # Remove digits-only path segments
        parts = u.split("/")
        parts = [re.sub(r'^\d+$', '*', p) for p in parts]
        return "/".join(parts).lower()

    n1, n2 = _normalize_url(url1), _normalize_url(url2)
    if not n1 or not n2:
        return 0.0
    return SequenceMatcher(None, n1, n2).ratio()


def _body_similarity(b1: str, b2: str) -> float:
    """Very fast approximate body similarity — compares token sets."""
    if not b1 and not b2:
        return 1.0
    if not b1 or not b2:
        return 0.0
    # Strip dynamic values (digits/UUIDs) and compare key names only
    key_re = re.compile(r'"([A-Za-z_][A-Za-z0-9_]*)"')
    keys1 = set(key_re.findall(b1))
    keys2 = set(key_re.findall(b2))
    if not keys1 and not keys2:
        # Plain text: use sequence matcher on truncated versions
        return SequenceMatcher(None, b1[:400], b2[:400]).ratio()
    if not keys1 or not keys2:
        return 0.0
    intersection = keys1 & keys2
    union = keys1 | keys2
    return len(intersection) / len(union)


def _extract_full_request_info(soup):
    """
    Returns list of dicts with full URL, body, method, and position per sampler.
    Used for similarity-based fallback matching.
    """
    results = []
    for idx, sampler in enumerate(soup.find_all("HTTPSamplerProxy")):
        name = sampler.get("testname", "")
        domain_el = sampler.find("stringProp", {"name": "HTTPSampler.domain"})
        path_el   = sampler.find("stringProp", {"name": "HTTPSampler.path"})
        method_el = sampler.find("stringProp", {"name": "HTTPSampler.method"})
        body_el   = sampler.find("stringProp", {"name": "Argument.value"})

        # Transaction parent
        txn_name = None
        current = sampler
        while current:
            parent_txn = current.find_previous("TransactionController")
            if parent_txn:
                txn_name = parent_txn.get("testname")
                break
            current = current.find_parent()

        results.append({
            "idx":    idx,
            "name":   name,
            "domain": (domain_el.text or "").strip() if domain_el else "",
            "path":   (path_el.text   or "").strip() if path_el   else "",
            "method": (method_el.text or "GET").strip().upper() if method_el else "GET",
            "body":   (body_el.text   or "").strip() if body_el   else "",
            "txn":    txn_name,
        })
    return results


# ── Request name: pure numeric check ─────────────────────────────────────────
def _is_numeric_only(name: str) -> bool:
    """Returns True if request label is like '635' or '635 /path' with no useful text."""
    stripped = re.sub(r'^\d+\s*', '', (name or "").strip())
    # Only a path with no meaningful text segment qualifies as "numeric-dominant"
    return bool(re.match(r'^(/\d+)*$', stripped))


def _should_use_similarity(reqs1, reqs2):
    """
    If majority of request names are numeric-only in either JMX, use similarity matching.
    """
    def frac_numeric(reqs):
        if not reqs: return 0.0
        return sum(1 for r in reqs if _is_numeric_only(r)) / len(reqs)
    return frac_numeric(reqs1) > 0.5 or frac_numeric(reqs2) > 0.5


# ── Main matching logic ───────────────────────────────────────────────────────
SIMILARITY_THRESHOLD = 0.50   # As requested: at least 50% match

def extract_requests_by_transaction(soup):
    txns = {}
    for sampler in soup.find_all("HTTPSamplerProxy"):
        txn_name = None
        current = sampler
        while current:
            parent_txn = current.find_previous("TransactionController")
            if parent_txn:
                txn_name = parent_txn.get("testname")
                break
            current = current.find_parent()

        req_name = sampler.get("testname")
        if txn_name and req_name:
            txns.setdefault(txn_name, []).append(req_name)
    return txns


def get_matching_transactions_and_requests(path1, path2):
    with open(path1, "r", encoding="utf-8") as f1, open(path2, "r", encoding="utf-8") as f2:
        soup1 = BeautifulSoup(f1.read(), "xml")
        soup2 = BeautifulSoup(f2.read(), "xml")

    txns1 = extract_requests_by_transaction(soup1)
    txns2 = extract_requests_by_transaction(soup2)

    # Flatten all request names to decide strategy
    all_reqs1 = [r for reqs in txns1.values() for r in reqs]
    all_reqs2 = [r for reqs in txns2.values() for r in reqs]
    use_similarity = _should_use_similarity(all_reqs1, all_reqs2)

    matched_txns = []
    matched_reqs = []

    if not use_similarity:
        # ── Classic name-normalize matching ───────────────────────────────────
        for t1, reqs1 in txns1.items():
            for t2, reqs2 in txns2.items():
                if t1.strip().lower() != t2.strip().lower():
                    continue
                matched_txns.append((t1, t2))
                for r1 in reqs1:
                    for r2 in reqs2:
                        if normalize(r1) == normalize(r2):
                            matched_reqs.append((t1, r1, r2))
    else:
        # ── URL + body similarity matching ────────────────────────────────────
        info1 = _extract_full_request_info(soup1)
        info2 = _extract_full_request_info(soup2)

        for t1, reqs1 in txns1.items():
            for t2, reqs2 in txns2.items():
                if t1.strip().lower() != t2.strip().lower():
                    continue
                matched_txns.append((t1, t2))

                # Build sub-lists of full info for this transaction
                sub1 = [r for r in info1 if r["txn"] == t1]
                sub2 = [r for r in info2 if r["txn"] == t2]

                used2 = set()
                for s1 in sub1:
                    best_score, best_s2 = -1.0, None
                    for i2, s2 in enumerate(sub2):
                        if i2 in used2:
                            continue
                        if s1["method"] != s2["method"]:
                            continue
                        url_sim  = _url_similarity(s1["path"], s2["path"])
                        if url_sim < SIMILARITY_THRESHOLD:
                            continue
                        body_sim = _body_similarity(s1["body"], s2["body"])
                        # Weighted score: URL 70%, body 30%
                        score = 0.70 * url_sim + 0.30 * body_sim
                        if score > best_score:
                            best_score, best_s2 = score, (i2, s2)
                    if best_s2 and best_score >= SIMILARITY_THRESHOLD:
                        i2, s2 = best_s2
                        used2.add(i2)
                        matched_reqs.append((t1, s1["name"], s2["name"]))

    return matched_txns, matched_reqs
