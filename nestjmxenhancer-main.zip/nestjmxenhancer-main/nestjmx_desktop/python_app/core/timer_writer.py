# timer_writer.py
"""
1. Adds P_Thinktime UDV at Test Plan level.
2. Inserts FlowControlAction BETWEEN TransactionControllers (not after the last one).
   Works correctly whether TransactionControllers are direct children of the
   TestPlan hashTree OR nested inside a ThreadGroup hashTree.
"""
import logging, os
from lxml import etree as LET

log = logging.getLogger(__name__)
DEFAULT_THINKTIME_MS = "3000"

def _parse_jmx(path):
    try:
        parser = LET.XMLParser(remove_blank_text=False, recover=True, encoding="utf-8")
        return LET.parse(path, parser)
    except Exception as e:
        log.error(f"[TIMER] parse failed: {e}"); return None

def _build_udv_element(default_ms):
    udv = LET.Element("Arguments", {
        "guiclass": "ArgumentsPanel", "testclass": "Arguments",
        "testname": "User Defined Variables - Think Time", "enabled": "true",
    })
    col = LET.SubElement(udv, "collectionProp", name="Arguments.arguments")
    arg = LET.SubElement(col, "elementProp", name="P_Thinktime", elementType="Argument")
    LET.SubElement(arg, "stringProp", name="Argument.name").text     = "P_Thinktime"
    LET.SubElement(arg, "stringProp", name="Argument.value").text    = default_ms
    LET.SubElement(arg, "stringProp", name="Argument.metadata").text = "="
    return udv

def _build_flow_control_action():
    fca = LET.Element("TestAction", {
        "guiclass": "TestActionGui", "testclass": "TestAction",
        "testname": "Think Time", "enabled": "true",
    })
    LET.SubElement(fca, "intProp",    name="ActionProcessor.action").text   = "1"
    LET.SubElement(fca, "intProp",    name="ActionProcessor.target").text   = "0"
    LET.SubElement(fca, "stringProp", name="ActionProcessor.duration").text = "${P_Thinktime}"
    return fca

def _insert_timers_in_container(container_ht):
    """
    Given a hashTree element that contains TransactionController siblings,
    insert a FlowControlAction BETWEEN each pair.
    Returns count of timers inserted.
    """
    inserted = 0
    # Build a snapshot list of (index, element) so we can find TransactionControllers
    # We'll process right-to-left to avoid index drift
    children = list(container_ht)

    # Find indices of ALL TransactionController elements
    txn_indices = [i for i, c in enumerate(children) if c.tag == "TransactionController"]

    if len(txn_indices) < 2:
        return 0  # Nothing to insert between

    # For each gap between txn[k] and txn[k+1]:
    # The hashTree of txn[k] is at txn_indices[k]+1
    # We insert the timer AFTER that hashTree, i.e. at txn_indices[k+1] (before next txn)
    # Process in reverse so indices stay stable
    for k in range(len(txn_indices) - 2, -1, -1):   # from second-to-last gap down to first
        txn_k_ht_idx  = txn_indices[k] + 1           # hashTree of txn[k]
        insert_at_idx = txn_k_ht_idx + 1             # position right after that hashTree

        # Check if a timer already exists here
        if insert_at_idx < len(children) and children[insert_at_idx].tag == "TestAction":
            log.info("[TIMER] Timer already present — skip")
            continue

        fca    = _build_flow_control_action()
        fca_ht = LET.Element("hashTree")
        # Insert fca first, then fca_ht right after — both at insert_at_idx
        # Result: [...ht_of_prev_txn, fca, fca_ht, next_txn, ht_of_next_txn...]
        container_ht.insert(insert_at_idx, fca_ht)
        container_ht.insert(insert_at_idx, fca)
        inserted += 1
        log.info(f"[TIMER] Inserted think time between txn[{k}] and txn[{k+1}]")

    return inserted

def add_timers_to_jmx(input_path, output_path, default_thinktime_ms=DEFAULT_THINKTIME_MS):
    tree = _parse_jmx(input_path)
    if tree is None: return "❌ Failed to parse JMX"
    root = tree.getroot()

    # Step 1: Add UDV at Test Plan level
    udv_added = False
    test_plan = root.find(".//TestPlan")
    if test_plan is not None:
        tp_ht = test_plan.getnext()
        if tp_ht is not None and tp_ht.tag == "hashTree":
            if not tp_ht.xpath(".//Arguments[@testname='User Defined Variables - Think Time']"):
                udv_el = _build_udv_element(default_thinktime_ms)
                udv_ht = LET.Element("hashTree")
                tp_ht.insert(0, udv_ht)
                tp_ht.insert(0, udv_el)
                udv_added = True
                log.info("[TIMER] Added P_Thinktime UDV")

    # Step 2: Insert a Think Time BEFORE each TransactionController except the first
    # one. This works regardless of how the TCs are nested (directly under the
    # ThreadGroup hashTree, inside recording/simple controllers, etc.) — the old
    # logic only fired when 2+ TCs were direct siblings of ONE hashTree, which is
    # why it inserted 0 on recordings where each TC sits in its own container.
    timers_added = 0
    tcs = root.xpath(".//TransactionController")
    first_seen = False
    for txn in tcs:
        if not first_seen:
            first_seen = True
            continue                         # no think time before the very first txn
        parent = txn.getparent()
        if parent is None or parent.tag != "hashTree":
            continue
        try:
            idx = list(parent).index(txn)
        except ValueError:
            continue
        # Skip if a Think Time TestAction was already inserted right before this TC
        # (idempotent on re-run): layout is [..., TestAction, hashTree, txn, ...]
        if idx >= 2 and parent[idx-2].tag == "TestAction" and \
           parent[idx-2].get("testname") == "Think Time":
            continue
        fca    = _build_flow_control_action()
        fca_ht = LET.Element("hashTree")
        parent.insert(idx, fca_ht)           # insert hashTree first…
        parent.insert(idx, fca)              # …then TestAction before it → [fca, fca_ht, txn]
        timers_added += 1

    out_dir = os.path.dirname(output_path)
    if out_dir: os.makedirs(out_dir, exist_ok=True)
    tree.write(output_path, encoding="utf-8", xml_declaration=True, pretty_print=True)

    udv_msg = "UDV added" if udv_added else "UDV already existed"
    return (
        f"✅ Timers: {timers_added} think time pause(s) inserted between transactions; "
        f"{udv_msg}. Default = {default_thinktime_ms}ms (${{P_Thinktime}})"
    )
