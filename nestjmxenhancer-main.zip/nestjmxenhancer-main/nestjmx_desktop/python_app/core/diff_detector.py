# diff_detector.py — enhanced with similarity-aware request matching
import re
import json
from collections import OrderedDict
from urllib.parse import parse_qsl, unquote_plus, urlparse, parse_qs
from bs4 import BeautifulSoup
from difflib import SequenceMatcher


def normalize(name: str) -> str:
    if not name or "/" not in name:
        return ""
    name = name[name.index("/"):]
    return re.sub(r'(?<=/)\d+(?=/)', '', name).strip().lower()


def _url_similarity(p1: str, p2: str) -> float:
    def _norm(u):
        u = re.sub(r'^\d+\s+', '', (u or "").strip()).split("?")[0]
        parts = u.split("/")
        parts = [re.sub(r'^\d+$', '*', p) for p in parts]
        return "/".join(parts).lower()
    n1, n2 = _norm(p1), _norm(p2)
    if not n1 or not n2: return 0.0
    return SequenceMatcher(None, n1, n2).ratio()


def _content_type_from(headers: dict) -> str:
    if not headers: return ""
    for k, v in headers.items():
        if k.lower() == "content-type":
            return (v or "").lower()
    return ""


def _parse_form_arguments(sampler) -> OrderedDict:
    args_node = sampler.find("elementProp", {"name": "HTTPsampler.Arguments"})
    if not args_node: return OrderedDict()
    out = OrderedDict()
    for el in args_node.find_all("elementProp", {"elementType": "HTTPArgument"}):
        name = el.find("stringProp", {"name": "Argument.name"})
        val  = el.find("stringProp", {"name": "Argument.value"})
        if name is not None:
            out[(name.text or "")] = (val.text if val is not None else "")
    return out


def _body_text(sampler) -> str:
    sp = sampler.find("stringProp", {"name": "Argument.value"})
    return sp.text if sp is not None else ""



def _parse_urlencoded_body(body: str) -> OrderedDict:
    """
    Fallback: when JMeter stores an application/x-www-form-urlencoded body
    as a single raw string (Argument.value) instead of individual HTTPArgument
    elements, split it manually so diff_detector can compare field-by-field
    instead of treating the whole body as one opaque value.

    Returns an OrderedDict of {field_name: value} pairs, or an empty dict if
    the body does not look like URL-encoded data (e.g. it is JSON or XML).
    """
    if not body or '=' not in body:
        return OrderedDict()
    # Reject JSON / XML bodies — they have their own parsers
    stripped = body.strip()
    if stripped.startswith(('{', '[', '<', '<?')):
        return OrderedDict()
    try:
        pairs = parse_qsl(body, keep_blank_values=True)
        if not pairs:
            return OrderedDict()
        return OrderedDict(pairs)
    except Exception:
        return OrderedDict()


def extract_all_request_data(soup):
    request_data = []
    for sampler in soup.find_all("HTTPSamplerProxy"):
        req_name = sampler.get("testname")
        path     = sampler.find("stringProp", {"name": "HTTPSampler.path"})
        headers  = {}
        ht = sampler.find_next_sibling("hashTree")
        if ht:
            hm = ht.find("HeaderManager")
            if hm:
                for ep in hm.find_all("elementProp"):
                    n = ep.find("stringProp", {"name": "Header.name"})
                    v = ep.find("stringProp", {"name": "Header.value"})
                    if n and v: headers[n.text] = v.text

        txn_name = None
        current  = sampler
        while current:
            parent_txn = current.find_previous("TransactionController")
            if parent_txn:
                txn_name = parent_txn.get("testname")
                break
            current = current.find_parent()

        form_args = _parse_form_arguments(sampler)
        body      = _body_text(sampler)
        ct        = _content_type_from(headers)

        # ── FIX IMP-01: URL-encoded body stored as raw string fallback ────────
        # When JMeter records a form POST as a single Argument.value string
        # instead of individual HTTPArgument elements, parse it here so that
        # diff_detector can compare field-by-field instead of as one blob.
        if not form_args and body and (
            "x-www-form-urlencoded" in ct or
            ("=" in body and "&" in body and not body.strip().startswith(("<", "{")))
        ):
            form_args = _parse_urlencoded_body(body)

        # ── FIX IMP-05: Auto-detect XML/SOAP content type from body ──────────
        # SOAP recordings sometimes arrive with text/xml, application/octet-stream,
        # or no Content-Type header at all. Promote the content_type so the XML
        # differ is invoked even without an explicit soap/xml header.
        if body and not ("xml" in ct or "soap" in ct):
            b = body.strip()
            if b.startswith("<?xml") or b.startswith("<soap:") or (
                b.startswith("<") and re.search(r'</[A-Za-z]', b)
            ):
                ct = "text/xml"

        if txn_name:
            request_data.append({
                "transaction":        txn_name,
                "request":            req_name,
                "normalized_request": normalize(req_name),
                "path":               path.text if path else "",
                "body":               body or "",
                "headers":            headers,
                "content_type":       ct,
                "form_args":          form_args,
            })
    return request_data


# ── lxml fast path ────────────────────────────────────────────────────────
# Mirrors extract_all_request_data() exactly but uses lxml (C-level) instead of
# BeautifulSoup. Used only when the JMX parses cleanly under strict lxml (every
# JMeter export does); any parse error falls back to the bs4 path in
# get_all_dynamic_differences, so behaviour is identical or unchanged.
def _xml_charref_ok(cp):
    # XML 1.0 legal code points
    return cp in (0x9, 0xA, 0xD) or 0x20 <= cp <= 0xD7FF or 0xE000 <= cp <= 0xFFFD or 0x10000 <= cp <= 0x10FFFF

_BAD_CHARREF_RX = __import__("re").compile(rb'&#(x?[0-9A-Fa-f]+);')
# literal XML-illegal control bytes (everything < 0x20 except tab/LF/CR), plus DEL
_ILLEGAL_BYTES = bytes([c for c in range(0x20) if c not in (0x9, 0xA, 0xD)]) + bytes([0x7F])

def _read_clean_xml_bytes(path):
    """Read a JMX and neutralise the XML-illegal content that makes lxml recover=True
    silently strip &quot; entities from request bodies (the 'invalid xmlChar value 0'
    errors). Removes both literal control bytes AND numeric char-refs like &#0; so the
    body decodes back to valid JSON. This is the root-cause fix; the tolerant JSON
    fallback remains only as a safety net."""
    with open(path, "rb") as f:
        data = f.read()
    data = data.translate(None, _ILLEGAL_BYTES)
    if b'&#' in data:
        def _sub(m):
            tok = m.group(1)
            try:
                cp = int(tok[1:], 16) if tok[:1] in (b'x', b'X') else int(tok)
            except Exception:
                return m.group(0)
            return m.group(0) if _xml_charref_ok(cp) else b''
        data = _BAD_CHARREF_RX.sub(_sub, data)
    return data


def _lx_text(el):
    # mirror bs4 Tag.text: concatenation of all descendant text
    return "".join(el.itertext())

def _lx_desc(el, tag):
    # descendants matching tag, document order, excluding self (mirror bs4 find_all)
    for d in el.iter(tag):
        if d is not el:
            yield d

def _lx_find(el, tag, name=None, etype=None):
    # first descendant matching tag (+ optional name / elementType), excl. self
    for d in el.iter(tag):
        if d is el:
            continue
        if name is not None and d.get("name") != name:
            continue
        if etype is not None and d.get("elementType") != etype:
            continue
        return d
    return None

def _parse_form_arguments_lxml(sampler):
    args_node = _lx_find(sampler, "elementProp", name="HTTPsampler.Arguments")
    out = OrderedDict()
    if args_node is None:
        return out
    for el in _lx_desc(args_node, "elementProp"):
        if el.get("elementType") != "HTTPArgument":
            continue
        name = _lx_find(el, "stringProp", name="Argument.name")
        val  = _lx_find(el, "stringProp", name="Argument.value")
        if name is not None:
            out[(_lx_text(name) or "")] = (_lx_text(val) if val is not None else "")
    return out

def _extract_all_request_data_lxml(root):
    request_data = []
    cur_txn = None  # nearest preceding TransactionController in document order
    for sampler in root.iter("TransactionController", "HTTPSamplerProxy"):
        tag = sampler.tag
        if tag == "TransactionController":
            cur_txn = sampler.get("testname")
            continue

        req_name = sampler.get("testname")
        path = _lx_find(sampler, "stringProp", name="HTTPSampler.path")
        headers = {}
        ht = None
        for sib in sampler.itersiblings():
            if sib.tag == "hashTree":
                ht = sib; break
        if ht is not None:
            hm = _lx_find(ht, "HeaderManager")
            if hm is not None:
                for ep in _lx_desc(hm, "elementProp"):
                    n = _lx_find(ep, "stringProp", name="Header.name")
                    v = _lx_find(ep, "stringProp", name="Header.value")
                    if n is not None and v is not None:
                        headers[_lx_text(n)] = _lx_text(v)

        txn_name = cur_txn
        form_args = _parse_form_arguments_lxml(sampler)
        _bsp = _lx_find(sampler, "stringProp", name="Argument.value")
        body = _lx_text(_bsp) if _bsp is not None else ""
        ct = _content_type_from(headers)

        if not form_args and body and (
            "x-www-form-urlencoded" in ct or
            ("=" in body and "&" in body and not body.strip().startswith(("<", "{")))
        ):
            form_args = _parse_urlencoded_body(body)

        if body and not ("xml" in ct or "soap" in ct):
            b = body.strip()
            if b.startswith("<?xml") or b.startswith("<soap:") or (
                b.startswith("<") and re.search(r'</[A-Za-z]', b)
            ):
                ct = "text/xml"

        if txn_name:
            request_data.append({
                "transaction":        txn_name,
                "request":            req_name,
                "normalized_request": normalize(req_name),
                "path":               _lx_text(path) if path is not None else "",
                "body":               body or "",
                "headers":            headers,
                "content_type":       ct,
                "form_args":          form_args,
            })
    return request_data

# ════════════════════════════════════════════════════════════════════════════
# EXHAUSTIVE DIFF MODE  ("Notepad++ Compare" behaviour)
# ────────────────────────────────────────────────────────────────────────────
# Philosophy: if a value differs between two recordings of the SAME script it is
# dynamic by definition, so we surface EVERY difference and let the user decide.
# No length floors, no content-type gate, no "looks dynamic" heuristic, no array
# zip-truncation, no segment-count guard. The only structural step retained is
# 1:1 request pairing (a JMX has no line alignment, so a value diff needs a
# matched RD1/RD2 sampler) and the O(n) `seen` dedup (so we never reintroduce
# the N×M trace explosion). Set sim_threshold=0.0 to pair even weakly-similar
# requests; raise it to suppress cross-request noise.
# ════════════════════════════════════════════════════════════════════════════

def normalize_txn(name: str) -> str:
    return re.sub(r'\d+', '', name or '').strip().lower()


# ── PATH + QUERY ────────────────────────────────────────────────────────────
def extract_dynamic_segments_from_path(path1, path2):
    """Every differing path segment AND every differing query param. No filters,
    no equal-length requirement — segments are aligned with SequenceMatcher so
    differing counts still diff cleanly."""
    diffs = []
    p1_path, _, p1_qs = (path1 or "").partition("?")
    p2_path, _, p2_qs = (path2 or "").partition("?")
    segs1 = [s for s in p1_path.split("/") if s]
    segs2 = [s for s in p2_path.split("/") if s]
    for tag, i1, i2, j1, j2 in SequenceMatcher(None, segs1, segs2).get_opcodes():
        if tag == "equal":
            continue
        a, b = segs1[i1:i2], segs2[j1:j2]
        for k in range(max(len(a), len(b))):
            s1 = a[k] if k < len(a) else ""
            s2 = b[k] if k < len(b) else ""
            if s1 != s2:
                diffs.append((s1, s2))
    if p1_qs or p2_qs:
        qs1 = dict(parse_qsl(p1_qs, keep_blank_values=True))
        qs2 = dict(parse_qsl(p2_qs, keep_blank_values=True))
        for key in (qs1.keys() | qs2.keys()):
            v1, v2 = qs1.get(key, ""), qs2.get(key, "")
            if v1 != v2:
                diffs.append((v1, v2))
    return diffs


# ── JSON ────────────────────────────────────────────────────────────────────
def _flatten_json(obj, prefix=""):
    """Flatten any JSON to {dotted/indexed path -> scalar}. Handles nesting,
    arrays (indexed), and one-sided keys uniformly."""
    out = {}
    if isinstance(obj, dict):
        for k, v in obj.items():
            out.update(_flatten_json(v, f"{prefix}.{k}" if prefix else str(k)))
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            out.update(_flatten_json(v, f"{prefix}[{i}]"))
    else:
        out[prefix] = obj
    return out


def _json_kv_pairs_tolerant(body):
    """Corruption-tolerant key:value extraction. Handles BOTH well-formed JSON and
    the QUOTE-STRIPPED bodies that lxml recover=True produces on Pega files: when it
    hits the &#0; NUL char-refs it drops every &quot; entity, leaving
    {selected:true,groupPolicyCode:01-035450-00,planHeaderId:215065,...} with no
    quotes at all. Quotes are therefore optional on both key and value; the value
    runs until the next , } ] or quote, which cleanly isolates ids."""
    rx = re.compile(r'["\']?([A-Za-z0-9_]+)["\']?\s*:\s*'
                    r'(?:"([^"]*)"|\'([^\']*)\'|([A-Za-z0-9_@.\-/]+))')
    pairs = []
    for m in rx.finditer(body or ""):
        key = m.group(1)
        val = next((g for g in (m.group(2), m.group(3), m.group(4)) if g is not None), "")
        pairs.append((key, val.strip().strip('\x00')))
    return pairs


def extract_dynamic_values_from_json_bodies(body1, body2):
    # Fast path: well-formed JSON → exact structural flatten.
    try:
        f1 = _flatten_json(json.loads(body1))
        f2 = _flatten_json(json.loads(body2))
        diffs = []
        for p in (f1.keys() | f2.keys()):
            v1, v2 = f1.get(p, ""), f2.get(p, "")
            if v1 != v2:
                diffs.append((p, v1, v2))
        return diffs
    except Exception:
        pass
    # Tolerant path: body is malformed (NUL bytes / stripped quotes from recover=True).
    # Diff key/value pairs positionally within each key so every id still surfaces.
    p1 = _json_kv_pairs_tolerant(body1)
    p2 = _json_kv_pairs_tolerant(body2)
    if not p1 and not p2:
        return []
    from collections import defaultdict as _dd
    g1, g2 = _dd(list), _dd(list)
    for k, v in p1: g1[k].append(v)
    for k, v in p2: g2[k].append(v)
    diffs = []
    for k in (g1.keys() | g2.keys()):
        a, b = g1.get(k, []), g2.get(k, [])
        for i in range(max(len(a), len(b))):
            v1 = a[i] if i < len(a) else ""
            v2 = b[i] if i < len(b) else ""
            if v1 != v2:
                path = f"{k}[{i}]" if max(len(a), len(b)) > 1 else k
                diffs.append((path, v1, v2))
    return diffs


# ── XML / SOAP ────────────────────────────────────────────────────────────────
def _flatten_xml(el, path):
    """Flatten an lxml element to {path -> text/attr}. Repeated children are
    positionally indexed; attributes are captured. No length filter."""
    out = {}
    t = (el.text or "").strip()
    if t:
        out[path] = t
    for ak, av in (el.attrib or {}).items():
        out[f"{path}@{ak}"] = av
    idx = {}
    for c in el:
        ctag = re.sub(r'\{[^}]+\}', '', c.tag) if isinstance(c.tag, str) else "_"
        i = idx.get(ctag, 0); idx[ctag] = i + 1
        out.update(_flatten_xml(c, f"{path}/{ctag}[{i}]"))
    return out


def extract_dynamic_values_from_xml_bodies(body1, body2):
    try:
        from lxml import etree
        p = etree.XMLParser(recover=True, huge_tree=True)
        r1 = etree.fromstring(body1.encode() if isinstance(body1, str) else body1, p)
        p = etree.XMLParser(recover=True, huge_tree=True)
        r2 = etree.fromstring(body2.encode() if isinstance(body2, str) else body2, p)
        if r1 is None or r2 is None:
            return []
    except Exception:
        return []
    rt1 = re.sub(r'\{[^}]+\}', '', r1.tag) if isinstance(r1.tag, str) else "root"
    rt2 = re.sub(r'\{[^}]+\}', '', r2.tag) if isinstance(r2.tag, str) else "root"
    f1 = _flatten_xml(r1, rt1)
    f2 = _flatten_xml(r2, rt2)
    diffs = []
    for path in (f1.keys() | f2.keys()):
        v1, v2 = f1.get(path, ""), f2.get(path, "")
        if v1 != v2:
            diffs.append((path, v1, v2))
    return diffs


# ── FORM (urlencoded) ─────────────────────────────────────────────────────────
def extract_dynamic_values_from_form_args(args1: OrderedDict, args2: OrderedDict):
    out = []
    for k in (set(args1.keys()) | set(args2.keys())):
        v1, v2 = args1.get(k, ""), args2.get(k, "")
        if v1 != v2:
            out.append((k, v1, v2))
    return out


# ── MULTIPART ──────────────────────────────────────────────────────────────────
def extract_dynamic_values_from_multipart(body1: str, body2: str, ct1: str, ct2: str):
    def parse_multipart(body, ct):
        fields = {}
        boundary_m = re.search(r'boundary=([^\s;]+)', ct or "")
        if not boundary_m:
            return fields
        boundary = boundary_m.group(1).strip('"')
        for part in re.split(r'--' + re.escape(boundary), body or ""):
            name_m  = re.search(r'Content-Disposition:[^\n]*name="([^"]+)"', part, re.I)
            value_m = re.search(r'\r?\n\r?\n(.*?)(?:\r?\n)?$', part, re.S)
            if name_m and value_m:
                fields[name_m.group(1)] = value_m.group(1).strip()
        return fields
    f1 = parse_multipart(body1, ct1); f2 = parse_multipart(body2, ct2)
    out = []
    for k in (set(f1.keys()) | set(f2.keys())):
        v1, v2 = f1.get(k, ""), f2.get(k, "")
        if v1 != v2:
            out.append((k, v1, v2))
    return out


# ── RAW TOKEN FALLBACK ─────────────────────────────────────────────────────────
# For bodies that no structured parser handled (proprietary formats, malformed
# JSON/XML, plain text) but that DIFFER, surface every differing value-like token
# — the closest thing to a literal Notepad++ inline diff.
_TOKEN_RX = re.compile(r'[A-Za-z0-9][A-Za-z0-9._:/\-]*')

def extract_raw_token_diffs(body1, body2):
    t1 = _TOKEN_RX.findall(body1 or "")
    t2 = _TOKEN_RX.findall(body2 or "")
    if t1 == t2:
        return []
    out = []
    for tag, i1, i2, j1, j2 in SequenceMatcher(None, t1, t2).get_opcodes():
        if tag == "equal":
            continue
        a, b = t1[i1:i2], t2[j1:j2]
        for k in range(max(len(a), len(b))):
            x = a[k] if k < len(a) else ""
            y = b[k] if k < len(b) else ""
            if x != y:
                out.append((x, y))
    return out


# ════════════════════════════════════════════════════════════════════════════
def get_all_dynamic_differences(path1, path2, sim_threshold=0.50, raw_fallback=True,
                                raw_max_chars=4000, form_min_len=4, drop_flags=True,
                                debug_values=None, dedup_by_value=True):
    # form_min_len / drop_flags apply ONLY to form, multipart and raw-token diffs —
    # the high-volume, low-value Pega postback fields (pzuiKey, StateChangeID, flags)
    # that flood the tracer. JSON / path / XML / header diffs stay fully unfiltered,
    # so every real ID (all of which are >= 4 chars) is preserved. Set form_min_len=0
    # and drop_flags=False to restore literal no-exclusions behaviour.
    _FLAGS = {"true", "false", "on", "off", "yes", "no", "0", "1", ""}
    def _keep_fr(v):
        v = v if isinstance(v, str) else str(v)
        if len(v.strip()) < form_min_len:
            return False
        if drop_flags and v.strip().lower() in _FLAGS:
            return False
        return True
    import time as _time
    _t0 = _time.perf_counter()
    all_rd1 = all_rd2 = None
    _path = "lxml"
    try:
        from lxml import etree as _et
        _p1 = _et.XMLParser(recover=True, huge_tree=True)
        _r1 = _et.fromstring(_read_clean_xml_bytes(path1), _p1); _n1 = len(_p1.error_log)
        _p2 = _et.XMLParser(recover=True, huge_tree=True)
        _r2 = _et.fromstring(_read_clean_xml_bytes(path2), _p2); _n2 = len(_p2.error_log)
        all_rd1 = _extract_all_request_data_lxml(_r1)
        all_rd2 = _extract_all_request_data_lxml(_r2)
        _first = (str(_p1.error_log[0].message) if _n1 else
                  (str(_p2.error_log[0].message) if _n2 else ""))
        _path = (f"lxml(recovered {_n1}+{_n2} errs; e.g. {_first})" if (_n1 or _n2)
                 else "lxml(clean)")
        del _r1, _r2
    except Exception as _e:
        _path = f"bs4-fallback({type(_e).__name__}: {_e})"
        all_rd1 = all_rd2 = None
    if all_rd1 is None or all_rd2 is None:
        with open(path1, "r", encoding="utf-8") as f1, open(path2, "r", encoding="utf-8") as f2:
            soup1 = BeautifulSoup(f1.read(), "xml")
            soup2 = BeautifulSoup(f2.read(), "xml")
        all_rd1 = extract_all_request_data(soup1)
        all_rd2 = extract_all_request_data(soup2)
    _t1 = _time.perf_counter()

    all_diffs = []
    seen = set()

    # ── DEBUG PROBE: locate target values in the extracted requests ───────────
    # Fires automatically in this debug build (no app.py change needed). To turn
    # off, set DEBUG_PROBE_DEFAULT = []  or override via env NESTCRAFT_DEBUG_VALUES.
    import os as _os
    DEBUG_PROBE_DEFAULT = []   # set to a list of values to trace capture in the log
    if debug_values is not None:
        _src = debug_values
    elif _os.environ.get("NESTCRAFT_DEBUG_VALUES"):
        _src = _os.environ["NESTCRAFT_DEBUG_VALUES"].split(",")
    else:
        _src = DEBUG_PROBE_DEFAULT
    _DBG = [str(v).strip() for v in _src if str(v).strip()]
    _dbg_pair_prints = [0]          # cap noisy per-pair detail
    _dbg_matched_idx = set()
    if _DBG:
        def _where(reqs, val):
            hits = []
            for idx, r in enumerate(reqs):
                locs = []
                if val in (r.get("body") or ""):       locs.append("body")
                if val in (r.get("path") or ""):        locs.append("path")
                if any(val in str(x) for x in (r.get("form_args") or {}).values()):
                    locs.append("form")
                if any(val in str(x) for x in (r.get("headers") or {}).values()):
                    locs.append("hdr")
                if locs:
                    hits.append((idx, r.get("request", "?"), "+".join(locs)))
            return hits
        print("\n[NestCraft DEBUG] ===== probe value location scan =====", flush=True)
        _dbg_loc1 = {}
        for v in _DBG:
            h1 = _where(all_rd1, v); h2 = _where(all_rd2, v)
            _dbg_loc1[v] = h1
            print(f"  '{v}': RD1 in {len(h1)} req {[ (i,n[:40],w) for i,n,w in h1[:3]]}", flush=True)
            print(f"  {' '*len(v)}  RD2 in {len(h2)} req {[ (i,n[:40],w) for i,n,w in h2[:3]]}", flush=True)
        print("[NestCraft DEBUG] ======================================\n", flush=True)

    # ── 1:1 request pairing (reliable, O(n)) ──────────────────────────────────
    # Match on the STABLE normalized request NAME globally (not the raw txn name —
    # that bucketing silently dropped whole transactions whose label carried a
    # dynamic id). Similarity is only a fallback. used set keeps it 1:1 so the
    # N×M trace explosion never returns.
    from collections import defaultdict as _dd
    by_name = _dd(list)
    rd2_by_txn = _dd(list)
    for j, r2 in enumerate(all_rd2):
        by_name[r2["normalized_request"]].append(j)
        rd2_by_txn[r2["transaction"]].append(j)

    used = set()

    def _best_match(r1):
        # 1) Stable normalized-NAME match, searched GLOBALLY (O(1) dict lookup).
        #    This is what fixes the whole-transaction drop, and it is cheap.
        nm = r1["normalized_request"]
        if nm:
            for j in by_name.get(nm, []):
                if j not in used:
                    return j
            if by_name.get(nm):
                return by_name[nm][0]            # name match, even if reused
        # 2) Similarity fallback ONLY within the same transaction bucket.
        #    A GLOBAL similarity scan here is O(n^2) (≈hours at 20k samplers when
        #    names don't line up) and was the cause of the runtime blow-up.
        best_j, best_sim = None, sim_threshold
        for j in rd2_by_txn.get(r1["transaction"], []):
            if j in used:
                continue
            sim = _url_similarity(r1["path"], all_rd2[j]["path"])
            if sim >= best_sim:
                best_j, best_sim = j, sim
        return best_j

    def _add(txn, req1, req2, field, kind, v1, v2, extra=None):
        v1s = v1 if isinstance(v1, str) else str(v1)
        v2s = v2 if isinstance(v2, str) else str(v2)
        # dedup_by_value collapses every row sharing the same (RD1,RD2) value pair to
        # ONE representative. A correlation tool needs a single extractor per unique
        # dynamic value, applied wherever it occurs — so this preserves every distinct
        # value (and all 8 probes) while cutting the tracer's per-row work from the
        # full diff count down to the unique-pair count. Set dedup_by_value=False to
        # restore one row per (field, request) occurrence.
        key = (v1s, v2s) if dedup_by_value else (kind, field, v1s, v2s, txn, req1)
        if key in seen:
            return
        seen.add(key)
        row = {"Transaction": txn, "Request": req1, "RequestRD2": req2,
               "Field": field, "RD1": v1, "RD2": v2, "Kind": kind}
        if extra:
            row.update(extra)
        all_diffs.append(row)

    for r1 in all_rd1:
        j = _best_match(r1)
        if j is None:
            continue
        used.add(j)
        r2 = all_rd2[j]
        txn = r1["transaction"]; rq1 = r1["request"]; rq2 = r2["request"]

        # 1) PATH + QUERY
        for a, b in extract_dynamic_segments_from_path(r1["path"], r2["path"]):
            _add(txn, rq1, rq2, "Request Path/Query", "path", a, b)

        ct1 = r1.get("content_type", ""); ct2 = r2.get("content_type", "")
        body1 = r1.get("body", "") or ""; body2 = r2.get("body", "") or ""
        body_diffed = False

        # 2) FORM args
        if r1["form_args"] or r2["form_args"]:
            fdiffs = extract_dynamic_values_from_form_args(r1["form_args"], r2["form_args"])
            for field, v1, v2 in fdiffs:
                # A raw JSON/XML body is stored by JMeter as an empty-named argument;
                # skip it here so we don't emit the whole blob as one giant diff —
                # the JSON/XML differ below extracts its individual values instead.
                if (not field) and (str(v1).lstrip()[:1] in ("{", "[", "<")):
                    continue
                if not _keep_fr(v1):
                    continue
                _add(txn, rq1, rq2, f"Form Field: {field}", "form", v1, v2, {"FormField": field})
            if fdiffs:
                body_diffed = True

        # 3) JSON  (no content-type gate — parse anything that looks like JSON)
        def _looks_json(b):
            s = (b or "").strip()
            return s[:1] in ("{", "[")
        _json_ran = (("application/json" in ct1 or _looks_json(body1)) and
                     ("application/json" in ct2 or _looks_json(body2)) and body1 and body2)
        if _json_ran:
            jdiffs = extract_dynamic_values_from_json_bodies(body1, body2)
            for jp, v1, v2 in jdiffs:
                _add(txn, rq1, rq2, f"JSON Body: {jp}", "json", str(v1), str(v2))
            if jdiffs:
                body_diffed = True

        # ── DEBUG PROBE: trace pairs whose body carries a target value ────────
        if _DBG:
            _hit = [v for v in _DBG if v in body1 or v in body2]
            if _hit:
                _dbg_matched_idx.update(_hit)
            if _hit and _dbg_pair_prints[0] < 8:
                _dbg_pair_prints[0] += 1
                import json as _json
                def _pj(b):
                    try:
                        _json.loads(b); return "loads=OK"
                    except Exception as _e:
                        return f"loads=FAIL({type(_e).__name__})"
                _njd = len(extract_dynamic_values_from_json_bodies(body1, body2)) if (body1 or body2) else 0
                print(f"[NestCraft DEBUG] PAIR rq1='{rq1[:45]}' -> rq2='{rq2[:45]}'", flush=True)
                print(f"    probe(s) here: {_hit}", flush=True)
                print(f"    ct1='{ct1[:30]}' ct2='{ct2[:30]}'  len(body1)={len(body1)} len(body2)={len(body2)}", flush=True)
                print(f"    body1[:60]={body1[:60]!r}", flush=True)
                print(f"    body2[:60]={body2[:60]!r}", flush=True)
                print(f"    form_keys1={list((r1.get('form_args') or {}).keys())[:6]}  form_keys2={list((r2.get('form_args') or {}).keys())[:6]}", flush=True)
                print(f"    looks_json1={_looks_json(body1)} looks_json2={_looks_json(body2)}  -> JSON differ {'RAN' if _json_ran else 'SKIPPED'}", flush=True)
                print(f"    json.loads: body1 {_pj(body1)}  body2 {_pj(body2)}", flush=True)
                print(f"    json differ produced {_njd} diffs for this pair", flush=True)
                for v in _hit:
                    inj = any((v in str(d['RD1']) or v in str(d['RD2'])) and d.get('Request')==rq1 for d in all_diffs)
                    print(f"      probe '{v}' emitted as a diff for this pair: {inj}", flush=True)

        # 4) XML / SOAP
        if ("xml" in ct1 or "soap" in ct1) and ("xml" in ct2 or "soap" in ct2) and body1 and body2:
            xdiffs = extract_dynamic_values_from_xml_bodies(body1, body2)
            for xp, v1, v2 in xdiffs:
                _add(txn, rq1, rq2, f"XML Body: {xp}", "xml", v1, v2)
            if xdiffs:
                body_diffed = True

        # 5) MULTIPART
        if "multipart/form-data" in ct1 and "multipart/form-data" in ct2 and body1 and body2:
            mdiffs = extract_dynamic_values_from_multipart(body1, body2, ct1, ct2)
            for field, v1, v2 in mdiffs:
                if not _keep_fr(v1):
                    continue
                _add(txn, rq1, rq2, f"Multipart Field: {field}", "form", v1, v2, {"FormField": field})
            if mdiffs:
                body_diffed = True

        # 6) RAW TOKEN FALLBACK — only when nothing structured fired AND both
        #    bodies are small. On large bodies a token-level SequenceMatcher emits
        #    thousands of diffs from ONE request (≈19.5k on a 77 KB body), each of
        #    which then gets origin-traced — that was the runtime blow-up. Large
        #    bodies are structured (JSON/form/XML) and already handled above.
        if (raw_fallback and not body_diffed and body1 and body2 and body1 != body2
                and len(body1) <= raw_max_chars and len(body2) <= raw_max_chars):
            for v1, v2 in extract_raw_token_diffs(body1, body2):
                if not _keep_fr(v1):
                    continue
                _add(txn, rq1, rq2, "Body (raw token)", "raw", v1, v2)

        # 7) HEADERS
        for h in sorted(set(r1["headers"].keys()) | set(r2["headers"].keys())):
            v1 = r1["headers"].get(h); v2 = r2["headers"].get(h)
            if v1 != v2:
                _add(txn, rq1, rq2, f"Header: {h}", "header", v1, v2, {"HeaderName": h})


    # ── DEBUG PROBE: final verdict per target value ───────────────────────────
    if _DBG:
        print("\n[NestCraft DEBUG] ===== final verdict =====", flush=True)
        for v in _DBG:
            in_any_body = any(v in (r.get("body") or "") for r in all_rd1)
            in_diffs = any(v in str(d["RD1"]) or v in str(d["RD2"]) for d in all_diffs)
            req_hits = _dbg_loc1.get(v, [])
            matched_note = ""
            if req_hits and v not in _dbg_matched_idx:
                matched_note = "  <-- its request was NOT processed as a JSON pair (unmatched, or matched to a non-JSON RD2 request)"
            print(f"  '{v}': in_RD1_body={in_any_body}  emitted_as_diff={in_diffs}{matched_note}", flush=True)
        print("[NestCraft DEBUG] =========================\n", flush=True)

    return all_diffs
