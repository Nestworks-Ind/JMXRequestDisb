# assertion_writer.py
"""
Adds ResponseAssertion to every TransactionController's main request.

For transactions WITH a RegexExtractor:
  - Copies the regex as the assertion pattern
  - useHeaders=true  -> Field to Test = Response Headers
  - useHeaders=false -> Field to Test = Text Response (body)

For transactions WITHOUT a RegexExtractor:
  - Priority 1: Parse XML JTL response body (if JTL is XML format with responseData)
  - Priority 2: Parse CSV JTL URL column to get meaningful path segment
  - Priority 3: Use the sampler's HTTPSampler.path from the JMX itself
  - All three produce a Substring assertion on the Text Response field

All assertions use Contains (test_type=2) with both collectionProp elements.
"""

import re, os, html, csv, io, logging, xml.etree.ElementTree as ET

log = logging.getLogger(__name__)


def _java_hashcode(s: str) -> int:
    result = 0
    for c in s:
        result = (result * 31 + ord(c)) & 0xFFFFFFFF
    if result > 0x7FFFFFFF:
        result -= 0x100000000
    return result


def _xml_encode(raw: str) -> str:
    decoded = html.unescape(raw)
    encoded = html.escape(decoded, quote=True)
    return encoded.replace("&#x27;", "&apos;")


def _make_assertion_block(indent, aname, hashcode, encoded_pattern, use_headers=False):
    """
    JMeter 5.6 ResponseAssertion — both collectionProp elements, Contains always.
    """
    test_field = "Assertion.response_headers" if use_headers else "Assertion.response_data"
    return (
        f'<ResponseAssertion guiclass="AssertionGui" testclass="ResponseAssertion"'
        f' testname="{aname}" enabled="true">\n'
        f'{indent}  <collectionProp name="Asserion.test_strings">\n'
        f'{indent}    <stringProp name="{hashcode}">{encoded_pattern}</stringProp>\n'
        f'{indent}  </collectionProp>\n'
        f'{indent}  <collectionProp name="Assertion.test_strings">\n'
        f'{indent}    <stringProp name="{hashcode}">{encoded_pattern}</stringProp>\n'
        f'{indent}  </collectionProp>\n'
        f'{indent}  <stringProp name="Assertion.custom_message"></stringProp>\n'
        f'{indent}  <stringProp name="Assertion.test_field">{test_field}</stringProp>\n'
        f'{indent}  <boolProp name="Assertion.assume_success">false</boolProp>\n'
        f'{indent}  <intProp name="Assertion.test_type">2</intProp>\n'
        f'{indent}  <stringProp name="Assertion.scope">all</stringProp>\n'
        f'{indent}</ResponseAssertion>'
    )


def _get_extractors(content: str) -> dict:
    """Parse all RegexExtractor blocks. useHeaders appears BEFORE regex in XML."""
    extractors = {}
    for m in re.finditer(
        r'<RegexExtractor[^>]*testname="([^"]+)"[^>]*>(.*?)</RegexExtractor>',
        content, re.DOTALL
    ):
        var_name = m.group(1)
        body     = m.group(2)
        pat_m = re.search(r'<stringProp name="RegexExtractor\.regex">(.*?)</stringProp>', body, re.DOTALL)
        hdr_m = re.search(r'<stringProp name="RegexExtractor\.useHeaders">(.*?)</stringProp>', body, re.DOTALL)
        if pat_m:
            use_headers = hdr_m.group(1).strip().lower() == 'true' if hdr_m else False
            extractors[var_name] = {'pattern': pat_m.group(1), 'use_headers': use_headers}
    return extractors


def _build_jtl_map(jtl_path: str) -> dict:
    """
    Parse JTL file (XML or CSV) into {label: {'body': str}} dict.
    Handles JMeter XML JTLs with illegal XML 1.0 control char refs (&#x00;-&#x1F;).
    """
    if not jtl_path or not os.path.exists(jtl_path):
        return {}

    result = {}
    with open(jtl_path, 'r', encoding='utf-8', errors='ignore') as f:
        raw = f.read()

    # ── XML JTL ──────────────────────────────────────────────────────────────
    if raw.lstrip().startswith(('<?xml', '<testResults', '<httpSample')):
        try:
            # Strip raw illegal bytes
            raw2 = re.sub(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]', '', raw)
            # Remove XML numeric refs to control chars (&#x00;-&#x1F; except tab/LF/CR)
            raw2 = re.sub(r'&#x([0-9a-fA-F]+);',
                          lambda m: '' if int(m.group(1), 16) < 0x20
                                    and int(m.group(1), 16) not in (0x9, 0xA, 0xD)
                                    else m.group(), raw2)
            raw2 = re.sub(r'&#([0-9]+);',
                          lambda m: '' if int(m.group(1)) < 32
                                    and int(m.group(1)) not in (9, 10, 13)
                                    else m.group(), raw2)
            # Fix bare ampersands
            raw2 = re.sub(r'&(?!amp;|lt;|gt;|quot;|apos;|#)', '&amp;', raw2)
            root = ET.fromstring(raw2)
            for s in root.iter():
                if s.tag.lower() not in ('httpsample', 'sample'):
                    continue
                label = s.get('lb') or s.get('label') or ''
                body  = html.unescape(s.findtext('responseData', '') or '')
                if 'Non-TEXT' in body or not body.strip():
                    body = ''
                if label:
                    entry = result.setdefault(label, {'body': ''})
                    if body and not entry['body']:
                        entry['body'] = body[:5000]
            log.info(f"[ASSERT] XML JTL parsed: {len(result)} labels")
            return result
        except ET.ParseError as e:
            log.warning(f"[ASSERT] XML parse failed ({e}), trying CSV")
        except Exception as e:
            log.warning(f"[ASSERT] XML JTL error: {e}")

    # ── CSV JTL (no body column) ─────────────────────────────────────────────
    try:
        for row in csv.DictReader(io.StringIO(raw)):
            label = row.get('label', '').strip()
            if label and label not in result:
                result[label] = {'body': ''}
        log.info(f"[ASSERT] CSV JTL parsed: {len(result)} labels (no body)")
    except Exception as e:
        log.warning(f"[ASSERT] CSV parse error: {e}")

    return {}


def _find_static_text(sampler_name, sampler_path, txn_name, jtl_map1, jtl_map2):
    """
    Extract assertion text from JTL RESPONSE BODY ONLY.

    Requires XML JTL with responseData saved (JMeter: Save Response Data = true).
    If the JTL has no body for this request, returns None — no assertion added.
    Never uses URL path or sampler path as source.

    Priority within body:
      1. HTML <title> identical in both recordings
      2. Common JSON key present in both response bodies
      3. Longest common substring (>=10 chars, non-trivial)
    """
    def _lookup(label, jtl_map):
        for lbl, data in jtl_map.items():
            if label == lbl or label in lbl or lbl.endswith(label):
                return data
        return None

    # Match this sampler in the JTL maps
    path_part = sampler_name.split(' ')[-1] if ' ' in sampler_name else sampler_name
    d1 = d2 = None
    for name in [sampler_name, path_part, txn_name]:
        d1 = _lookup(name, jtl_map1) or _lookup(name, jtl_map2)
        d2 = _lookup(name, jtl_map2) or _lookup(name, jtl_map1)
        if d1 or d2:
            break

    body1 = (d1 or {}).get('body', '').strip()
    body2 = (d2 or {}).get('body', '').strip()

    # No body data available -> skip entirely
    if not body1 and not body2:
        log.info(f"[ASSERT] No body in JTL for: {txn_name} — skipped")
        return None

    b1 = body1 or body2
    b2 = body2 or body1

    # 1. HTML <title> identical in both recordings
    t1 = re.search(r'<title[^>]*>([^<]{4,80})</title>', b1, re.I)
    t2 = re.search(r'<title[^>]*>([^<]{4,80})</title>', b2, re.I)
    if t1 and t2 and t1.group(1).strip() == t2.group(1).strip():
        text = t1.group(1).strip()
        log.info(f"[ASSERT] Body title: {txn_name} -> '{text}'")
        return text

    # 2. Common JSON key
    key_re = r'"([A-Za-z_][A-Za-z0-9_]{2,25})":'
    common = set(re.findall(key_re, b1)) & set(re.findall(key_re, b2))
    if common:
        text = '"' + max(common, key=len) + '":'
        log.info(f"[ASSERT] Body JSON key: {txn_name} -> '{text}'")
        return text

    # 3. Longest common substring (>=10 chars, non-trivial)
    s1, s2 = b1[:3000], b2[:3000]
    best = ''
    for length in range(min(80, len(s1)), 9, -4):
        for start in range(0, len(s1) - length, max(1, length // 3)):
            cand = s1[start:start + length]
            if re.match(r'^[\s\d\-_.:/<>]+$', cand):
                continue
            if cand in s2 and len(cand) > len(best):
                best = cand
        if len(best) >= 30:
            break
    if best.strip() and len(best.strip()) >= 10:
        log.info(f"[ASSERT] Body LCS: {txn_name} -> '{best.strip()}'")
        return best.strip()

    log.info(f"[ASSERT] No useful content in body for: {txn_name} — skipped")
    return None




def _get_immediate_hashtree(jmx_content, ht_start):
    pos = ht_start + len('<hashTree>')
    depth = 1
    while pos < len(jmx_content) and depth > 0:
        op = jmx_content.find('<hashTree', pos)
        cl = jmx_content.find('</hashTree>', pos)
        if cl == -1:
            break
        if op != -1 and op < cl:
            tag_end = jmx_content.find('>', op)
            if jmx_content[tag_end - 1] == '/':
                pos = tag_end + 1
            else:
                depth += 1
                pos = tag_end + 1
        else:
            depth -= 1
            pos = cl + len('</hashTree>')
    return jmx_content[ht_start:pos]


def _get_transactions(jmx_content: str) -> list:
    transactions = []
    for m in re.finditer(
        r'<TransactionController[^>]*testname="([^"]+)".*?</TransactionController>\s*\n\s*<hashTree>',
        jmx_content, re.DOTALL
    ):
        txn_name = m.group(1)
        ht_start = jmx_content.rfind('<hashTree>', 0, m.end())
        section  = _get_immediate_hashtree(jmx_content, ht_start)
        samplers = []
        for sm in re.finditer(
            r'<HTTPSamplerProxy[^>]*testname="([^"]+)"[^>]*>.*?'
            r'<stringProp name="HTTPSampler\.path">([^<]*)</stringProp>',
            section, re.DOTALL
        ):
            samplers.append({'name': sm.group(1), 'path': sm.group(2)})
        has_extractor = bool(re.search(r'<RegexExtractor', section))
        main_sampler = None
        for s in samplers:
            p = s['path'].lower()
            if not any(ext in p for ext in ['.ico','.png','.jpg','.gif','.css','.js',
                                             '.woff','.svg','.webp','favicon','.ttf','.eot']):
                main_sampler = s
                break
        if not main_sampler and samplers:
            main_sampler = samplers[0]
        transactions.append({
            'txn_name':      txn_name,
            'has_extractor': has_extractor,
            'main_sampler':  main_sampler,
        })
    return transactions


def _insert_assertion(result, aname, anchor_var, anchor_tag,
                       hashcode, encoded, use_headers):
    """Insert new or update existing ResponseAssertion for this specific anchor.

    Scoping strategy: find the anchor element first, then look for an existing
    Assertion WITHIN the same hashTree block — not globally. This means multiple
    transactions can all have an assertion named "Response Assertion" without collision.
    """
    def block(ind):
        return _make_assertion_block(ind, aname, hashcode, encoded, use_headers)

    # ── Find anchor element (RegexExtractor or HTTPSamplerProxy) ─────────────
    ex_idx = result.find(f'testname="{anchor_var}"')
    if ex_idx < 0:
        return result, False

    ex_end = result.find(f'</{anchor_tag}>', ex_idx) + len(f'</{anchor_tag}>')
    ht_idx = result.find('<hashTree', ex_end)
    ht_end = result.find('>', ht_idx) + 1

    # ── Determine the end of this hashTree scope ──────────────────────────────
    # Look for the CLOSING </hashTree> that matches the opening at ht_idx.
    scope_end = ht_end
    depth = 1
    pos   = ht_end
    while pos < len(result) and depth > 0:
        op = result.find('<hashTree', pos)
        cl = result.find('</hashTree>', pos)
        if cl == -1:
            break
        if op != -1 and op < cl:
            tag_e = result.find('>', op)
            if result[tag_e - 1] != '/':
                depth += 1
            pos = tag_e + 1
        else:
            depth -= 1
            pos = cl + len('</hashTree>')
            if depth == 0:
                scope_end = pos

    scope = result[ht_end:scope_end]

    # ── Check if this scope already contains an assertion with this name ──────
    local_ass = scope.find(f'testname="{aname}"')
    if local_ass >= 0:
        # Update the existing assertion within this scope
        ra_start_in_scope = scope.rfind('<ResponseAssertion', 0, local_ass)
        ra_end_in_scope   = scope.find('</ResponseAssertion>', ra_start_in_scope) + len('</ResponseAssertion>')
        ls  = scope.rfind('\n', 0, ra_start_in_scope) + 1
        ind = scope[ls:ra_start_in_scope]
        new_scope = scope[:ra_start_in_scope] + block(ind) + scope[ra_end_in_scope:]
        return result[:ht_end] + new_scope + result[scope_end:], True

    # ── No existing assertion — insert a new one right after the hashTree open ─
    tag_s  = result.rfind(f'<{anchor_tag}', 0, ex_idx)
    ls     = result.rfind('\n', 0, tag_s) + 1
    indent = result[ls:tag_s] if tag_s >= ls else '            '
    return result[:ht_end] + f'\n{indent}{block(indent)}\n{indent}<hashTree/>' + result[ht_end:], True


def _process_jmx(content: str, jtl_map1: dict, jtl_map2: dict) -> tuple:
    result = content
    count  = 0

    # Track which transactions already have an assertion (Fix 2: one per transaction)
    txn_asserted = set()

    # ── Pass 1: extractor-based assertions (Fix 3: ONE assertion per transaction) ──
    # Group extractors by their parent transaction so we pick only the first/best one
    extractors = _get_extractors(content)

    # Build transaction → first extractor mapping
    # Walk transactions in document order and assign the first RegexExtractor found
    txn_to_extractor = {}
    for txn in _get_transactions(content):
        txn_name = txn['txn_name']
        if not txn['has_extractor']:
            continue
        # Find which extractor(s) belong to this transaction's hashTree section
        # We use the transaction name to scope the search in the raw content
        txn_idx = content.find(f'testname="{txn_name}"')
        if txn_idx == -1:
            continue
        ht_start = content.find('<hashTree>', txn_idx)
        if ht_start == -1:
            continue
        section = _get_immediate_hashtree(content, ht_start)
        # Pick the FIRST RegexExtractor found in this transaction's section
        for var_name, info in extractors.items():
            if f'testname="{var_name}"' in section:
                txn_to_extractor[txn_name] = (var_name, info)
                break   # Fix 3: stop after first extractor per transaction

    # Now inject exactly ONE assertion per transaction that has an extractor
    for txn_name, (var_name, info) in txn_to_extractor.items():
        if txn_name in txn_asserted:
            continue
        raw_pattern = info['pattern']
        use_headers = info['use_headers']
        aname       = "Response Assertion"
        decoded     = html.unescape(raw_pattern)
        hashcode    = str(_java_hashcode(decoded))
        encoded     = _xml_encode(raw_pattern)
        result, ok  = _insert_assertion(result, aname, var_name,
                                        'RegexExtractor', hashcode, encoded, use_headers)
        if ok:
            count += 1
            txn_asserted.add(txn_name)
            field = 'Response Headers' if use_headers else 'Text Response'
            log.info(f"[ASSERT] {aname} field={field} pattern='{encoded[:40]}'")

    # ── Pass 2: static text for transactions without extractors (Fix 2: one per txn) ──
    for txn in _get_transactions(result):
        txn_name = txn['txn_name']
        # Fix 2: skip if this transaction already has an assertion
        if txn_name in txn_asserted:
            continue
        if txn['has_extractor'] or not txn['main_sampler']:
            continue
        aname = "Response Assertion"
        # Guard is the txn_asserted set — not testname search — because
        # all assertions share the name "Response Assertion" now.
        if txn_name in txn_asserted:
            continue

        main_sampler = txn['main_sampler']
        static_text = _find_static_text(
            main_sampler['name'], main_sampler['path'],
            txn_name, jtl_map1, jtl_map2
        )
        if not static_text:
            log.info(f"[ASSERT] No text found for: {txn_name} — skipping")
            continue

        encoded  = _xml_encode(static_text)
        hashcode = str(_java_hashcode(html.unescape(static_text)))
        result, ok = _insert_assertion(result, aname, main_sampler['name'],
                                       'HTTPSamplerProxy', hashcode, encoded, False)
        if ok:
            count += 1
            txn_asserted.add(txn_name)

    return result, count


def add_assertions_to_jmx(input_path, output_path,
                           jtl_path1=None, jtl_path2=None,
                           correlation_inputs=None):
    try:
        with open(input_path, 'r', encoding='utf-8', errors='replace') as f:
            content = f.read()
    except Exception as e:
        return f"❌ Could not read JMX: {e}"

    jtl_map1 = _build_jtl_map(jtl_path1)
    jtl_map2 = _build_jtl_map(jtl_path2)
    modified, count = _process_jmx(content, jtl_map1, jtl_map2)

    out_dir = os.path.dirname(output_path)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)

    try:
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(modified)
    except Exception as e:
        return f"❌ Could not write JMX: {e}"

    return f"✅ Assertions: {count} added/updated"
