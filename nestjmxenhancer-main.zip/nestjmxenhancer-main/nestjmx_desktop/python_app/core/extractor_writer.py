# extractor_writer.py — fixed sampler matching + tolerant XML parsing
import os
import re
import logging
from lxml import etree as LET


def _parse_jmx_robust(path: str):
    try:
        parser = LET.XMLParser(remove_blank_text=False, recover=True, encoding="utf-8")
        tree   = LET.parse(path, parser)
        return tree
    except Exception as e:
        logging.error(f"[ERROR] Failed to parse JMX '{path}': {e}")
        return None


def _ensure_dir(p: str):
    d = os.path.dirname(p)
    if d and not os.path.isdir(d):
        os.makedirs(d, exist_ok=True)


def _normalize_label(label: str) -> str:
    """
    Strip leading numeric prefix that JTL recording adds.
    '635 /login' -> '/login'
    'Login Request' -> 'Login Request'  (unchanged)
    """
    return re.sub(r'^\d+\s+', '', (label or '').strip())


def _labels_match(target: str, actual: str) -> bool:
    """
    Tolerant label matching between JTL origin labels and JMX sampler names.
    Handles:
      - Exact match:          '635 /login' == '635 /login'
      - Numeric prefix strip: '635 /login' matches '/login'
      - Suffix containment:   '/login' matches '635 /login'
    """
    if not target or not actual:
        return False
    target = target.strip()
    actual = actual.strip()

    if target == actual:
        return True

    # Strip numeric prefix from both and compare
    t_norm = _normalize_label(target)
    a_norm = _normalize_label(actual)
    if t_norm == a_norm:
        return True

    # Containment: one ends with or contains the other (handles partial names)
    if t_norm and (actual.endswith(t_norm) or t_norm.endswith(a_norm)):
        return True
    if a_norm and (target.endswith(a_norm) or a_norm.endswith(t_norm)):
        return True

    return False


def add_regex_extractors_to_jmx(input_path, output_path, correlation_inputs):
    """
    Inject RegexExtractor elements into the ORIGIN sampler's hashTree.

    Key fix: uses _labels_match() for tolerant JTL label -> JMX sampler matching,
    so '635 /login' correctly finds the '/login' sampler in the JMX.
    """
    logging.basicConfig(level=logging.INFO)
    tree = _parse_jmx_robust(input_path)
    if tree is None:
        return f"❌ Failed to parse input JMX: {input_path}"

    root        = tree.getroot()
    added_count = 0

    try:
        # Build a map of all samplers for efficient lookup
        all_samplers = root.xpath(".//HTTPSamplerProxy")

        for corr in correlation_inputs:
            target_label  = (corr.get("request_label") or "").strip()
            regex_pattern = corr.get("dynamic_value") or ""
            variable_name = corr.get("regex_name") or ""
            default_value = f"{variable_name}_NOVALUE"

            if not (target_label and regex_pattern and variable_name):
                logging.warning(f"[WARN] Skipping — missing fields: {corr}")
                continue

            logging.info(f"[ADD] target='{target_label}' var='{variable_name}'")

            # Find the target sampler.
            # PRIORITY 1 — exact full-label match (number + path). With repeated
            # paths (e.g. 20+ "/app" samplers) the recording number is the ONLY
            # thing that identifies the correct instance, so an exact match must
            # win over any path-only match.
            # PRIORITY 2 — tolerant path match, but ONLY if it is unambiguous
            # (exactly one candidate). If several samplers share the path we
            # cannot tell which instance the origin refers to, so we SKIP rather
            # than silently inject under the wrong sampler.
            matched_sampler = None
            for sampler in all_samplers:
                if (sampler.get("testname") or "").strip() == target_label:
                    matched_sampler = sampler
                    logging.info(f"[MATCH-EXACT] '{target_label}'")
                    break

            if matched_sampler is None:
                tolerant = [s for s in all_samplers
                            if _labels_match(target_label, (s.get("testname") or "").strip())]
                if len(tolerant) == 1:
                    matched_sampler = tolerant[0]
                    logging.info(f"[MATCH-TOLERANT] '{target_label}' -> '{matched_sampler.get('testname')}'")
                elif len(tolerant) > 1:
                    names = ", ".join((s.get("testname") or "") for s in tolerant[:5])
                    logging.warning(
                        f"[WARN] Ambiguous origin '{target_label}' matched {len(tolerant)} "
                        f"samplers by path ({names}...). Skipping to avoid placing the "
                        f"extractor under the wrong sampler.")
                    continue

            if matched_sampler is None:
                logging.warning(f"[WARN] No sampler matched for label: '{target_label}'")
                continue

            # Get the sampler's hashTree sibling
            sampler_hash_tree = matched_sampler.getnext()
            if sampler_hash_tree is None or sampler_hash_tree.tag != "hashTree":
                sampler_hash_tree = LET.Element("hashTree")
                matched_sampler.addnext(sampler_hash_tree)

            # Check if extractor with this variable name already exists (avoid duplicates)
            existing = sampler_hash_tree.xpath(
                f".//RegexExtractor[@testname='{variable_name}']"
            )
            if existing:
                logging.info(f"[SKIP] Extractor '{variable_name}' already exists")
                continue

            # Build RegexExtractor element
            # use_headers=true  → extract from response headers
            # match_number      → which occurrence to extract (1=first, -1=random, >1=Nth)
            use_headers  = str(corr.get("use_headers",  False)).lower() == "true"
            match_number = str(corr.get("match_number", 1) or 1)
            template     = corr.get("template", "$1$") or "$1$"    # NEW: $2$ for multi-capture

            rex = LET.Element("RegexExtractor", {
                "guiclass":  "RegexExtractorGui",
                "testclass": "RegexExtractor",
                "testname":  variable_name,
                "enabled":   "true"
            })
            LET.SubElement(rex, "stringProp", name="RegexExtractor.useHeaders").text   = "true" if use_headers else "false"
            LET.SubElement(rex, "stringProp", name="RegexExtractor.refname").text      = variable_name
            LET.SubElement(rex, "stringProp", name="RegexExtractor.regex").text        = regex_pattern
            LET.SubElement(rex, "stringProp", name="RegexExtractor.template").text     = template   # NEW
            LET.SubElement(rex, "stringProp", name="RegexExtractor.default").text      = default_value
            LET.SubElement(rex, "stringProp", name="RegexExtractor.match_number").text = match_number

            sampler_hash_tree.append(rex)
            sampler_hash_tree.append(LET.Element("hashTree"))

            added_count += 1
            logging.info(f"[OK] Added extractor '{variable_name}' under '{matched_sampler.get('testname')}'")

        _ensure_dir(output_path)
        tree.write(output_path, encoding="utf-8", xml_declaration=True, pretty_print=True)
        logging.info(f"[SUMMARY] Injected {added_count} extractor(s) -> {output_path}")
        return f"✅ Injected {added_count} extractor(s) into {output_path}"

    except Exception as e:
        logging.error(f"[ERROR] add_regex_extractors_to_jmx: {e}")
        return f"❌ Failed to inject extractors: {e}"
