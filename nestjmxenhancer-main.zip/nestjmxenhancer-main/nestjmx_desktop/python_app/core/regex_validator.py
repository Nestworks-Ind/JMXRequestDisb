import re

def validate_regex_on_response(regex, response, expected_value):
    """
    Validates if the regex correctly extracts the expected value from the given response text.
    Returns True if a match is found and equals expected_value, else False.
    """
    try:
        matches = re.findall(regex, response)
        print(f"[DEBUG] Testing regex: {regex}")
        print(f"[DEBUG] Regex Matches: {matches}")
        print(f"[DEBUG] Expected Value: {expected_value}")

        if expected_value in matches:
            print("[DEBUG] Regex validated in RD2.")
            return True
        else:
            print("[DEBUG] ❌ Regex did not extract the expected value.")
            return False
    except re.error as e:
        print(f"[ERROR] Invalid regex: {regex} — {e}")
        return False
