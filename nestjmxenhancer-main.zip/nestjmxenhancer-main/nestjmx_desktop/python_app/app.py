"""
app.py — JMeter Auto Correlation Desktop  (Enhanced v2.0)
New features:
  - URL+body similarity-based request matching (handles numeric-only JMeter names)
  - Response Assertion injection (from RegexExtractors or static JTL content)
  - Think Time injection (FlowControlAction + P_Thinktime UDV)
"""
import os, re, html, urllib.parse
import xml.etree.ElementTree as ET
from datetime import datetime
from bs4 import BeautifulSoup
from flask import Flask, render_template, request, send_from_directory, redirect, url_for, jsonify
import time

# Optional: bulk presence (Aho-Corasick). Either engine works; ahocorasick_rs ships
# prebuilt wheels (incl. new Python versions, no compiler) which suits Windows/Py3.14.
# If neither is present, token_present uses the original per-token scan unchanged.
try:
    import ahocorasick as _AHO
except Exception:
    _AHO = None
try:
    import ahocorasick_rs as _AHO_RS
except Exception:
    _AHO_RS = None

# ── Load .env file (keeps service role key off disk / out of code) ─────────────
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

# ── File logging (C:\Users\<user>\.NestCraft\app.log) ──────────────────
import logging
_LOG_DIR = os.path.join(os.path.expanduser('~'), '.NestCraft')
os.makedirs(_LOG_DIR, exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(_LOG_DIR, 'app.log'), encoding='utf-8'),
    ]
)
log = logging.getLogger(__name__)
log.info('=== NestCraft starting up ===')

from core.transaction_matcher import get_matching_transactions_and_requests
from core.diff_detector        import get_all_dynamic_differences, normalize
from core.extractor_writer     import add_regex_extractors_to_jmx
from core.regex_generator      import extract_regex_with_dynamic_boundaries, expand_left_until_unique, regex_for_header, generate_regex_for_response
from core.replacer             import replace_values_in_jmx
from core.trace_origin         import clean_xml_file
from core.assertion_writer     import add_assertions_to_jmx
from core.timer_writer         import add_timers_to_jmx

# ── Auth + Admin blueprints ────────────────────────────────────────────────────
from admin_api   import admin_bp
from auth_routes import auth_routes_bp

# ── App setup ──────────────────────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Use user home directory for writable folders — avoids PermissionError
# when app is installed in Program Files on Windows
APP_DATA_DIR = os.path.join(os.path.expanduser('~'), '.NestCraft')
os.makedirs(APP_DATA_DIR, exist_ok=True)

app = Flask(__name__, template_folder=os.path.join(BASE_DIR, 'templates'))
# App build marker — bump when app.py logic changes, so the startup banner can
# confirm which app.py the server actually loaded.
__app_build__ = "2026-06-22-bodyfix2"
app.config['UPLOAD_FOLDER']   = os.path.join(APP_DATA_DIR, 'uploads')
app.config['DOWNLOAD_FOLDER'] = os.path.join(APP_DATA_DIR, 'downloads')
os.makedirs(app.config['UPLOAD_FOLDER'],   exist_ok=True)
os.makedirs(app.config['DOWNLOAD_FOLDER'], exist_ok=True)

# Apply & Export POSTs one hidden field-set per selected correlation row. With the
# larger result sets the diff fix now surfaces, that urlencoded body exceeds the
# newer Werkzeug defaults (max_form_memory_size = 500 KB, max_form_parts = 1000),
# which raised RequestEntityTooLarge. Lift the form-parsing limits generously.
# Set both the Flask config keys (Flask 3.1+) and the request-class attributes so
# it works regardless of the installed Flask/Werkzeug version.
app.config['MAX_CONTENT_LENGTH']   = 512 * 1024 * 1024   # 512 MB total request
app.config['MAX_FORM_MEMORY_SIZE'] = 512 * 1024 * 1024   # urlencoded form in memory
app.config['MAX_FORM_PARTS']       = 1_000_000           # number of form fields
try:
    app.request_class.max_content_length   = 512 * 1024 * 1024
    app.request_class.max_form_memory_size = 512 * 1024 * 1024
    app.request_class.max_form_parts       = 1_000_000
except Exception:
    pass

# ── Secret key + blueprints ────────────────────────────────────────────────────
from config import FLASK_SECRET, APP_VERSION
app.secret_key = FLASK_SECRET
app.register_blueprint(admin_bp)
app.register_blueprint(auth_routes_bp)

# Make APP_VERSION available to every template as {{ app_version }} (no need to
# pass it in each render_template call).
@app.context_processor
def _inject_app_version():
    return {'app_version': APP_VERSION}

# ── Log service key status on startup ─────────────────────────────────────────
from auth_routes import SERVICE_KEY as _SK
if _SK and _SK != 'PASTE_YOUR_SERVICE_ROLE_KEY_HERE':
    log.info(f'[STARTUP] SUPABASE_SERVICE_KEY loaded OK (length={len(_SK)})')
else:
    log.error('[STARTUP] SUPABASE_SERVICE_KEY is MISSING or placeholder — profile save will fail!')

# ── Debug endpoint — check config without a console ───────────────────────────
@app.route('/debug/config')
def debug_config():
    from auth_routes import SERVICE_KEY as _SK2
    return jsonify({
        'service_key_loaded': bool(_SK2 and _SK2 != 'PASTE_YOUR_SERVICE_ROLE_KEY_HERE'),
        'service_key_length': len(_SK2) if _SK2 else 0,
        'service_key_prefix': _SK2[:20] + '...' if _SK2 and len(_SK2) > 20 else _SK2,
    })

SESSION_DATA = {}

# ── Progress tracking ──────────────────────────────────────────────────────────
PROGRESS = {
    "step": "idle", "pct": 0.0, "eta": "", "detail": "",
    "started_at": 0.0, "weights": {}, "base": 0.0, "step_weight": 0.0,
}

def _progress_start():
    PROGRESS.update({
        "step": "Starting…", "pct": 0.0, "eta": "", "detail": "",
        "started_at": time.time(), "step_started": time.time(),
        # Weights = each phase's share of TOTAL time, calibrated to real profiles
        # (TABLE/origin-trace dominates; diff+index are modest; uploads tiny).
        "weights": {"UPLOADS":2.0,"MATCHER":3.0,"DIFFS":5.0,"INDEX":16.0,"TABLE":72.0,"FINALIZE":2.0},
        "base": 0.0, "step_weight": 0.0,
        "cancel": False, "eta_secs": None,
    })

def _progress_set_step(s):
    PROGRESS["base"]         = float(PROGRESS.get("pct", 0.0))
    PROGRESS["step"]         = s
    PROGRESS["step_weight"]  = PROGRESS["weights"].get(s, 0.0)
    PROGRESS["step_started"] = time.time()

def _fmt_eta(secs):
    secs = max(0, int(round(secs)))
    # Snap to a coarse grid so the number doesn't flicker every poll.
    if secs >= 90:
        secs = int(round(secs / 15.0) * 15)
    elif secs >= 30:
        secs = int(round(secs / 5.0) * 5)
    return f"~{secs//60}m {secs%60}s" if secs >= 60 else f"~{secs}s"

def _progress_step_fraction(f, detail=""):
    f = max(0.0, min(1.0, f))
    pct = PROGRESS["base"] + PROGRESS["step_weight"] * f
    PROGRESS["pct"] = pct; PROGRESS["detail"] = detail
    now      = time.time()
    elapsed  = now - PROGRESS["started_at"]
    step     = PROGRESS.get("step")
    weights  = PROGRESS.get("weights", {})
    order    = ["UPLOADS","MATCHER","DIFFS","INDEX","TABLE","FINALIZE"]
    remaining = None
    # Dominant phase: project the whole remaining run from the MEASURED rate of
    # this phase (self-calibrating to the dataset), then add the small tail phases.
    # Require a larger fraction (>=8%) before trusting the rate — at tiny f the
    # per-unit estimate is extremely noisy and was the cause of the 6m↔15m jumps.
    if step == "TABLE" and f >= 0.08:
        per_unit    = (now - PROGRESS.get("step_started", now)) / f      # full TABLE secs
        tw          = max(1e-9, weights.get("TABLE", 1.0))
        tail_weight = sum(weights.get(s2, 0.0) for s2 in order[order.index("TABLE")+1:])
        remaining   = per_unit * (1.0 - f) + per_unit * (tail_weight / tw)
    # Early phases: extrapolate from overall %, which is now time-proportional.
    elif step not in ("UPLOADS", "MATCHER", "TABLE") and pct > 1.0:
        remaining = elapsed * (100.0 - pct) / pct

    # Smooth the remaining-seconds. The row cost varies a lot across the run (cheap
    # rows, then many unique-regex builds, then cache-heavy rows), so the raw
    # estimate swings. Smooth ASYMMETRICALLY: follow decreases fairly quickly (the
    # countdown should feel responsive) but let increases in only very slowly, so a
    # momentary slow patch can't balloon the ETA and then snap back. The net effect
    # is a steady, mostly-downward countdown instead of 13m→25m→16m jumps.
    if remaining is not None:
        prev = PROGRESS.get("eta_secs")
        if prev is None:
            smoothed = remaining
        elif remaining <= prev:
            smoothed = 0.30 * remaining + 0.70 * prev     # decreasing → responsive
        else:
            smoothed = 0.04 * remaining + 0.96 * prev     # increasing → heavily damped
        PROGRESS["eta_secs"] = smoothed
        PROGRESS["eta"] = _fmt_eta(smoothed) if pct < 100.0 else ""
    elif pct >= 100.0:
        PROGRESS["eta"] = ""

def _progress_finish():
    PROGRESS.update({"step": "Done", "pct": 100.0, "eta": "", "detail": ""})

APPLY_PROGRESS = {
    "step": "idle", "pct": 0.0, "eta": "", "detail": "",
    "started_at": 0.0, "current": 0, "total_steps": 4,
}

def _apply_start(total=4):
    APPLY_PROGRESS.update({
        "step": "Starting…", "pct": 0.0, "eta": "", "detail": "",
        "started_at": time.time(), "current": 0, "total_steps": total,
    })

def _apply_tick(label):
    cur = APPLY_PROGRESS["current"] + 1
    tot = max(1, APPLY_PROGRESS["total_steps"])
    pct = min(100.0, 100.0 * cur / tot)
    APPLY_PROGRESS.update({"current": cur, "pct": pct, "step": label, "detail": ""})
    if pct > 0:
        elapsed = time.time() - APPLY_PROGRESS.get("started_at", time.time())
        secs    = max(0.0, elapsed * (100.0 - pct) / pct)
        APPLY_PROGRESS["eta"] = f"~{int(secs//60)}m {int(secs%60)}s" if secs >= 90 else f"~{int(secs)}s"

def _apply_finish():
    APPLY_PROGRESS.update({"step": "Done", "pct": 100.0, "eta": "", "detail": ""})

# ── Time-savings estimate ────────────────────────────────────────────────────
# What it would take a performance engineer to do BY HAND, per item. These are
# deliberately conservative (a real correlation — locating the value's origin,
# writing a boundary regex, testing it in the RegExp Tester, then wiring the
# extractor and replacing every usage — is usually more than 3 min; a response
# assertion with the right pattern is usually more than 2). Kept as named
# constants so they're easy to tune.
MANUAL_MIN_PER_CORRELATION = 5.0   # locate origin, write+test regex, replace usages
MANUAL_MIN_PER_ASSERTION   = 2.0   # locate response, add & verify a response assertion

def _compute_savings(correlations, assertions, tool_secs):
    manual_secs = correlations * MANUAL_MIN_PER_CORRELATION * 60 + \
                  assertions   * MANUAL_MIN_PER_ASSERTION   * 60
    saved_secs  = max(0.0, manual_secs - (tool_secs or 0.0))
    return {
        "correlations":   int(correlations),
        "assertions":     int(assertions),
        "manual_secs":    round(manual_secs, 1),
        "tool_secs":      round(tool_secs or 0.0, 1),
        "saved_secs":     round(saved_secs, 1),
        "min_per_corr":   MANUAL_MIN_PER_CORRELATION,
        "min_per_assert": MANUAL_MIN_PER_ASSERTION,
    }

# ── Utilities ──────────────────────────────────────────────────────────────────
_ws = re.compile(r"\s+")

def clean_text(t):
    if not t: return ""
    try: t = html.unescape(urllib.parse.unquote_plus(t))
    except: pass
    return _ws.sub(" ", t.strip())

# ── Lightweight profiler ──────────────────────────────────────────────────────
# Accumulates wall-time per named phase/hotspot and prints a summary to the
# console at the end of each analysis. Disable with NESTCRAFT_PROFILE=0.
_PROF = {}
_PROF_ON = os.environ.get("NESTCRAFT_PROFILE", "0") == "1"

class _timed:
    __slots__ = ("name", "t")
    def __init__(self, name): self.name = name
    def __enter__(self):
        self.t = time.perf_counter(); return self
    def __exit__(self, *exc):
        if _PROF_ON:
            e = _PROF.setdefault(self.name, [0.0, 0])
            e[0] += time.perf_counter() - self.t; e[1] += 1

def _prof_add(name, seconds, calls=1):
    if _PROF_ON:
        e = _PROF.setdefault(name, [0.0, 0]); e[0] += seconds; e[1] += calls

def _prof_reset():
    _PROF.clear(); _clean_cache.clear(); _occ_cache.clear()

def _prof_report(extra=""):
    if not (_PROF_ON and _PROF): return
    rows = sorted(_PROF.items(), key=lambda kv: -kv[1][0])
    print("\n[NestCraft PROFILE] " + (extra or ""))
    print(f"  {'phase / hotspot':<40}{'total(s)':>10}{'calls':>9}{'avg(ms)':>10}")
    for name, (tot, n) in rows:
        print(f"  {name:<40}{tot:>10.3f}{n:>9d}{1000*tot/max(n,1):>10.2f}")
    print("", flush=True)

# Memoized decode keyed by object identity. Candidate response bodies are held by
# the JTL index for the whole analysis, so the same ~1 MB string is decoded ONCE
# instead of repeatedly inside the RD1×RD2 candidate walk. We store the SOURCE
# string alongside its decode and verify identity on every hit: this keeps the
# source object alive (so its id can't be reused) AND guards against any id reuse,
# guaranteeing the cached value is always the decode of exactly this string —
# i.e. byte-for-byte identical to calling clean_text(t) directly.
_clean_cache = {}
def _clean_cached(t):
    if not t: return ""
    k = id(t)
    entry = _clean_cache.get(k)
    if entry is not None and entry[0] is t:
        return entry[1]
    with _timed("clean_text(decode body)"):
        v = clean_text(t)
    _clean_cache[k] = (t, v)
    return v


def slice_around(s, pos, radius=400):
    if not s: return ""
    if pos is None or pos < 0 or pos >= len(s):
        mid = min(len(s)//2, 2000)
        return s[max(0, mid-radius):min(len(s), mid+radius)]
    return s[max(0, pos-radius):min(len(s), pos+radius)]

def _key_positional_correlation(v1, v2, test1, test2):
    """Match-number (positional) correlation, used when there is no reliable UNIQUE
    boundary. Builds the value's own field-key regex (e.g. "planHeaderId":"(...)")
    and accepts it ONLY if the SAME match number locates v1 in RD1 and v2 in RD2.
    That shared match number is what makes the extractor correct on both sides.

    Returns (pattern, mc1, mc2, match_number) or None.
    """
    from core.regex_generator import _key_left_boundary, _strip_lead_delim
    if not (v1 and v2 and test1 and test2):
        return None
    # Find an occurrence of v1 that is followed by a real delimiter, so we can read
    # the field key in front of it and a clean closing character behind it.
    delims = ('"', "'", '&', '<', ',', ';', '}', ']', '>')
    i = test1.find(v1)
    right = ''
    while i != -1:
        nxt = test1[i + len(v1)] if i + len(v1) < len(test1) else ''
        if nxt in delims:
            right = nxt
            break
        i = test1.find(v1, i + 1)
    if i == -1 or not right:
        return None

    pre = test1[max(0, i - 200): i]
    kb  = _strip_lead_delim(_key_left_boundary(pre) or '')
    # Require an actual field NAME in the boundary (never a bare punctuation anchor),
    # otherwise the positional pattern would be meaninglessly generic.
    if not kb or not re.search(r'[A-Za-z]', kb):
        return None

    cap = rf'[^{re.escape(right)}]+'
    pat = re.escape(kb) + f'({cap})' + re.escape(right)
    try:
        m1 = re.findall(pat, test1)
        m2 = re.findall(pat, test2)
    except re.error:
        return None
    # Single capture group → lists of strings. (Defensive: skip if tuples appear.)
    if (m1 and isinstance(m1[0], tuple)) or (m2 and isinstance(m2[0], tuple)):
        return None
    if v1 not in m1 or v2 not in m2:
        return None
    n1 = m1.index(v1) + 1
    n2 = m2.index(v2) + 1
    if n1 != n2:
        return None                         # match numbers disagree → not correct
    return pat, len(m1), len(m2), n1


def generate_smart_and_fallback_regex(v1, v2, r1_raw, r2_raw):
    if not all([v1, v2, r1_raw, r2_raw]): return None, 0, 0, None, "$1$"
    from core.regex_generator import _is_html_encoded, _validate_pattern
    with _timed("5a. clean_cached(decode r1+r2)"):
        r1_dec = _clean_cached(r1_raw); r2_dec = _clean_cached(r2_raw)
    with _timed("5b. is_html_encoded"):
        is_enc = _is_html_encoded(r1_raw)
    test1  = r1_raw if is_enc else r1_dec
    test2  = r2_raw if is_enc else r2_dec
    if ((f'"{v1}"' in r1_dec) or (f"&quot;{v1}&quot;" in r1_raw)) and \
       ((f'"{v2}"' in r2_dec) or (f"&quot;{v2}&quot;" in r2_raw)):
        p = r'(?<=&quot;)[^&]*(?=&quot;)' if is_enc else r'(?<=\")[^\"]*(?=\")'
        with _timed("5c. validate_pattern(quoted fast-path)"):
            valid, mc1, mc2, mn, tmpl = _validate_pattern(p, v1, test1, test2)
        if valid and mc1 == 1:
            return p, mc1, mc2, mn, "$1$"
    with _timed("5d. generate_regex_for_response"):
        pat, mn, tmpl = generate_regex_for_response(v1, r1_raw, r2_raw)
    if pat:
        with _timed("5e. validate_pattern(generated)"):
            valid, mc1, mc2, mn_v, _ = _validate_pattern(pat, v1, test1, test2, template=tmpl)
        # A UNIQUE-in-RD1 boundary is trustworthy only if it also matches RD2 — a
        # boundary that is unique only because it pinned a neighbouring DYNAMIC
        # value (e.g. "218691","planHeaderId":"…") won't appear in RD2 (mc2==0) and
        # would fail at replay. Accept the clean unique-in-both case immediately;
        # otherwise fall through to match-number correlation first.
        if valid and mc1 == 1 and mc2 >= 1:
            return pat, mc1, mc2, mn_v if mn_v else mn, tmpl
    else:
        valid = False

    # ── Match-number correlation: when there's no reliable unique boundary, use the
    # field-key regex with the match number that locates v1 in RD1 AND v2 in RD2
    # at the SAME position. This is the correct extractor for repeated-key values
    # (e.g. "planHeaderId":"(.+?)" at match 1 → 215065 in RD1, 215063 in RD2).
    xres = _key_positional_correlation(v1, v2, test1, test2)
    if xres:
        xpat, xmc1, xmc2, xN = xres
        return xpat, xmc1, xmc2, xN, "$1$"

    # ── Last resort: a unique-in-RD1-only boundary (RD2#=0). Shown so the user can
    # see it isn't cross-validated, but still better than nothing. A NON-cross-
    # validated positional (mc1>1 whose match number wasn't confirmed in RD2) is
    # deliberately NOT returned — emitting it would write a match number that isn't
    # known to be correct in both recordings. Such values fall through to "No Regex"
    # for manual correlation, which is safer than a wrong positional extractor.
    if pat and valid and mc1 == 1:
        return pat, mc1, mc2, mn_v if mn_v else mn, tmpl
    return None, 0, 0, None, "$1$"


def _encoded_pos(raw: str, value: str) -> int:
    """
    For HTML-encoded responses, find the position of value inside a &quot;VALUE&quot;
    context rather than a plain-quote context. This ensures slice_around cuts the
    raw response around the encoded occurrence, not a different literal-quote occurrence.
    Returns the position of the VALUE inside the raw string, or -1 if not found.
    """
    # Try &quot;VALUE&quot; first (most specific)
    encoded_ctx = f'&quot;{value}&quot;'
    p = raw.find(encoded_ctx)
    if p != -1:
        return p + len('&quot;')   # position of value itself inside &quot;VALUE&quot;
    # Try KEY=&quot;VALUE using character class instead of lookbehind (Python internal use)
    import re as _re
    m = _re.search(r'[^A-Za-z0-9_][A-Za-z_][A-Za-z0-9_\-]*=&quot;' + _re.escape(value), raw)
    if m:
        return raw.find(value, m.start())
    # Fallback: plain occurrence
    return raw.find(value)

def get_request_order_from_jmx(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            soup = BeautifulSoup(f.read(), "xml")
        return [s.get("testname","").strip() for s in soup.find_all("HTTPSamplerProxy") if s.get("testname")]
    except: return []

def _strip_invalid_charrefs(text):
    """
    Remove XML numeric character references to control chars (e.g. &#x1B;, &#1;).
    A single one of these anywhere makes strict XML parsers reject the WHOLE file,
    which previously dropped every response body into the fragile regex fallback.
    Tab (9), LF (10) and CR (13) are preserved.
    """
    def _hex(m):
        n = int(m.group(1), 16)
        return '' if (n < 0x20 and n not in (0x9, 0xA, 0xD)) else m.group(0)
    def _dec(m):
        n = int(m.group(1))
        return '' if (n < 32 and n not in (9, 10, 13)) else m.group(0)
    text = re.sub(r'&#x([0-9a-fA-F]+);', _hex, text)
    text = re.sub(r'&#(\d+);',          _dec, text)
    return text


def _regex_index_fallback(cleaned, _add):
    """
    Last-resort parser used only if both lxml-recover and ElementTree fail.

    Unlike the old non-greedy '<httpSample ...>(.*?)</httpSample>' approach (which
    stopped at the FIRST </httpSample> — i.e. the close of a nested sub-sample —
    and ignored <sample> transaction parents), this slices the file by successive
    sample OPEN tags. Each sample's block runs from its own open tag up to the next
    sample open tag, so nested sub-samples each get their own block and every
    responseData is captured and paired with the correct label.
    """
    open_rx = re.compile(r'<(?:httpSample|sample)\b[^>]*?(?:\blb="([^"]*)")?[^>]*>', re.I)
    rd_rx   = re.compile(r'<responseData[^>]*>(.*?)</responseData>',    re.DOTALL | re.I)
    rh_rx   = re.compile(r'<responseHeader[^>]*>(.*?)</responseHeader>', re.DOTALL | re.I)
    opens = [(m.start(), m.group(1) or "") for m in open_rx.finditer(cleaned)]
    for i, (start, label) in enumerate(opens):
        end   = opens[i + 1][0] if i + 1 < len(opens) else len(cleaned)
        block = cleaned[start:end]
        rm = rd_rx.search(block); hm = rh_rx.search(block)
        _add(html.unescape(label),
             rm.group(1) if rm else "",
             hm.group(1) if hm else "")


def build_jtl_index(jtl_path):
    cleaned = _strip_invalid_charrefs(clean_xml_file(jtl_path))
    labels, responses, responses_lower, has_sp, has_q, has_wlr, pos = [], [], [], [], [], [], {}
    headers_list  = []
    responses_raw = []
    def _add(label, resp_raw, hdr=""):
        resp = clean_text(resp_raw); rlow = resp.lower(); idx = len(labels)
        labels.append(label); responses.append(resp); responses_raw.append(resp_raw or "")
        responses_lower.append(rlow); headers_list.append(hdr or "")
        has_sp.append(('?sp=' in rlow) or ('&sp=' in rlow))
        has_q.append('"' in resp or '&quot;' in resp or '&quot;' in (resp_raw or ""))
        has_wlr.append('window.location.replace' in rlow)
        pos.setdefault(label, []).append(idx)

    def _consume(root):
        n = 0
        for s in root.iter():
            tag = s.tag
            if not isinstance(tag, str):   # lxml comments / PIs are callables
                continue
            if tag.lower().endswith(("httpsample", "sample")):
                label    = s.get("lb") or s.get("label") or ""
                resp_raw = s.findtext("responseData",   default="") or ""
                hdr      = s.findtext("responseHeader", default="") or ""
                _add(label, resp_raw, hdr); n += 1
        return n

    parsed = 0
    # Primary: lxml recover-mode — tolerates malformed bytes, bad entities and
    # truncated tails, and builds a proper tree so nested sub-samples are handled.
    try:
        from lxml import etree as _LET
        _parser = _LET.XMLParser(recover=True, huge_tree=True, resolve_entities=False)
        _root = _LET.fromstring(cleaned.encode("utf-8", "ignore"), _parser)
        if _root is not None:
            parsed = _consume(_root)
    except Exception as e:
        log.warning(f"[INDEX] lxml recover parse failed ({e}); trying ElementTree")
        parsed = 0

    # Fallback 1: stdlib ElementTree
    if parsed == 0:
        try:
            parsed = _consume(ET.fromstring(cleaned))
        except Exception:
            parsed = 0

    # Fallback 2: tolerant, nested-aware regex
    if parsed == 0:
        _regex_index_fallback(cleaned, _add)

    try:
        _with_body = sum(1 for r in responses if r)
        log.info(f"[INDEX] {os.path.basename(jtl_path)}: {len(labels)} samples, "
                 f"{_with_body} with response body")
    except Exception:
        pass

    return {"labels":labels,"responses":responses,"responses_raw":responses_raw,
            "responses_lower":responses_lower,"headers_list":headers_list,
            "has_sp_param":has_sp,"has_quotes":has_q,"has_wlr":has_wlr,"pos":pos}

_PC = {}; _WC = {}

def _first_pos_quoted(resp, dv):
    for n in (f'value="{dv}"', f'"{dv}"', f"&quot;{dv}&quot;"):
        p = resp.find(n)
        if p != -1: return p
    return -1


def _origin_variants(dv):
    """
    Build tolerant search variants for a dynamic value so origin tracing succeeds
    even when the request value and the response text differ in representation.

    Real recordings routinely differ between where a value is SENT and where it
    first APPEARS: a token may be stored URL-encoded in the request ("%2B",
    "%2F") but echoed decoded ("+", "/") in the originating response, or use
    I/l/1 character look-alikes. fast_trace_origin previously matched the value
    only verbatim, so these legitimate origins showed as "No Origin".

    Returns (terms, terms_lower, lookalike_rx):
      - terms / terms_lower : extra substring forms to search (besides verbatim)
      - lookalike_rx        : compiled regex for I/l/1 leading-char swaps, or None
    """
    terms = []
    def _add(s):
        if s and s != dv and s not in terms:
            terms.append(s)
    try:
        _add(urllib.parse.unquote(dv))            # %2B -> +,  %2F -> /
        _add(urllib.parse.quote(dv, safe=""))     # + -> %2B, / -> %2F
        _add(html.unescape(dv))                   # &quot;/&amp; -> "/&
    except Exception:
        pass
    terms_lower = [t.lower() for t in terms]
    lookalike_rx = None
    m = re.match(r'^([Il1])(\d+)$', dv)
    if m:
        lookalike_rx = re.compile(r'[Il1]' + re.escape(m.group(2)))
    return terms, terms_lower, lookalike_rx

_occ_cache = {}

def _origin_occurrences(index, dv):
    """All responses where `dv` occurs, each classified as a quoted (Pass-A) or
    cascade (Pass-B) match with the SAME metadata the original scan produced, in
    index order. Computed ONCE per (index, value) and cached, so a value used by
    many requests is scanned a single time instead of once per consumer — this is
    the main origin-tracing speedup. fast_trace_origin's selection below mirrors
    the original two-pass scan exactly, so results are unchanged.
    """
    key = (id(index), dv)
    cached = _occ_cache.get(key)
    if cached is not None and cached[0] is index:
        return cached[1]
    labels=index["labels"]; responses=index["responses"]; responses_lower=index["responses_lower"]
    responses_raw=index.get("responses_raw", responses); headers_list=index.get("headers_list", [])
    has_sp=index["has_sp_param"]; has_q=index["has_quotes"]; has_wlr=index["has_wlr"]
    dvl=dv.lower(); il1=re.match(r'^([Il1])(\d+)$', dv)
    il1_tail = il1.group(2) if il1 else None
    tail_rx = re.compile(rf'(?i)(?:\?|&|&amp;)sp=[Il1]{re.escape(il1.group(2))}') if il1 else None
    wlr_rx  = re.compile(r"window\.location\.replace\([^)]*" + re.escape(dv), re.I|re.S)
    v_terms, v_terms_lower, v_rx = _origin_variants(dv)
    dv_enc = html.escape(dv, quote=True)

    def _mk(lb, resp, raw, pos, header=False):
        return {"FoundInRequestID":lb,"MatchedResponse":resp,"MatchedResponseRaw":raw,
                "MatchPos":pos,"FoundInHeader":header}

    occ = []
    for i in range(len(labels)):
        lb=labels[i]; resp=responses[i]; rlow=responses_lower[i]; resp_raw=responses_raw[i]
        # Pass-A: quoted occurrence (value="x", "x", &quot;x&quot;)
        if has_q[i]:
            qp = _first_pos_quoted(resp, dv)
            if qp != -1:
                occ.append((i, True, lb, _mk(lb, resp, resp_raw, qp))); continue
        # Pass-B cascade: verbatim → lower → raw/escaped → sp-tail → wlr → variants → v_rx → header
        p = resp.find(dv)
        if p == -1 and dvl in rlow: p = rlow.find(dvl)
        if p == -1:
            p_raw = resp_raw.find(dv) if dv in resp_raw else (-1 if dv_enc == dv else resp_raw.find(dv_enc))
            if p_raw != -1:
                occ.append((i, False, lb, _mk(lb, resp, resp_raw, p_raw))); continue
        if p != -1:
            occ.append((i, False, lb, _mk(lb, resp, resp_raw, p))); continue
        if il1 and has_sp[i] and tail_rx and il1_tail in resp:
            m = tail_rx.search(resp)
            if m: occ.append((i, False, lb, _mk(lb, resp, resp_raw, m.start()))); continue
        if has_wlr[i] and dvl in rlow:
            m = wlr_rx.search(resp)
            if m: occ.append((i, False, lb, _mk(lb, resp, resp_raw, m.start()))); continue
        _hit = False
        for _vt, _vtl in zip(v_terms, v_terms_lower):
            vp = resp.find(_vt)
            if vp == -1 and _vtl in rlow: vp = rlow.find(_vtl)
            if vp == -1 and resp_raw:     vp = resp_raw.find(_vt)
            if vp != -1:
                occ.append((i, False, lb, _mk(lb, resp, resp_raw, vp))); _hit = True; break
        if _hit: continue
        if v_rx and il1_tail:
            m = None
            if il1_tail in resp:
                m = v_rx.search(resp)
            if m is None and resp_raw and il1_tail in resp_raw:
                m = v_rx.search(resp_raw)
            if m: occ.append((i, False, lb, _mk(lb, resp, resp_raw, m.start()))); continue
        if i < len(headers_list):
            hdr = headers_list[i]
            if hdr:
                hlow = hdr.lower()
                if dvl in hlow:
                    occ.append((i, False, lb, _mk(lb, hdr, hdr, hlow.find(dvl), True))); continue
                _hh = False
                for _vtl in v_terms_lower:
                    if _vtl in hlow:
                        occ.append((i, False, lb, _mk(lb, hdr, hdr, hlow.find(_vtl), True))); _hh = True; break
                if _hh: continue
    _occ_cache[key] = (index, occ)
    return occ


def fast_trace_origin(index, label, dv, filters=None, enforce=False):
    NONE = {"FoundInRequestID":None,"MatchedResponse":None,"MatchedResponseRaw":None,
            "MatchPos":None,"FoundInHeader":False,"ForwardRef":False}
    if not dv: return NONE
    dv = dv.strip()
    if not dv: return NONE
    labels = index["labels"]; positions = index["pos"]
    last = len(labels) - 1
    if last < 0: return NONE
    end_at = positions[label][-1] if label in positions else last

    occ = _origin_occurrences(index, dv)
    if not occ: return NONE

    def _pick(lo, hi):
        # Mirror the original scan: the first QUOTED match in [lo,hi] (Pass A), else
        # the first cascade match in [lo,hi] (Pass B); honour the request filter.
        cand = [o for o in occ if lo <= o[0] <= hi and
                not (enforce and filters and not any(p in o[2] for p in filters))]
        if not cand: return None
        for o in cand:
            if o[1]:
                return o[3]
        return cand[0][3]

    # Pass 1 — preferred: a backward origin (response BEFORE the using request).
    res = _pick(0, end_at)
    if res is not None:
        r = dict(res); r["ForwardRef"] = False; return r
    # Pass 2 — global fallback: the value appears only after the using request, so
    # it is a forward reference, flagged accordingly for downstream awareness.
    if end_at < last:
        res = _pick(end_at + 1, last)
        if res is not None:
            r = dict(res); r["ForwardRef"] = True; return r
    return NONE


def trace_origin_candidates(index, label, dv, filters=None, enforce=False, limit=15):
    """
    Return EVERY response (earliest first) in the backward window [0..consumer]
    that contains `dv`, so the row builder can try them in turn: if the first
    response's occurrences can't be correlated, move to the next response — but
    stop at the consuming request (the window already ends there), since beyond it
    the value lives in both request and response (a self-reference).

    Each item has the same shape as fast_trace_origin's result. This mirrors the
    manual workflow of stepping through successive matches until one correlates.
    """
    if not dv:
        return []
    labels = index["labels"]; responses = index["responses"]
    responses_lower = index["responses_lower"]
    responses_raw = index.get("responses_raw", responses)
    headers_list = index.get("headers_list", [])
    positions = index["pos"]
    dv = dv.strip()
    if not dv:
        return []
    last = len(labels) - 1
    if last < 0:
        return []
    end_at = positions[label][-1] if label in positions else last
    dvl = dv.lower()
    v_terms, v_terms_lower, v_rx = _origin_variants(dv)
    out = []
    for i in range(0, end_at + 1):
        lb = labels[i]
        if lb.strip() == label.strip():
            continue   # the consumer itself — value lives in its own request+response
        if enforce and filters and not any(p in lb for p in filters):
            continue
        resp = responses[i]; rlow = responses_lower[i]; raw = responses_raw[i]
        in_body = (dvl in rlow) \
            or (raw and (dv in raw or any(t in raw for t in v_terms))) \
            or any(t in rlow for t in v_terms_lower) \
            or (v_rx and (v_rx.search(resp) or (raw and v_rx.search(raw))))
        in_hdr = False
        if not in_body and i < len(headers_list) and headers_list[i]:
            hlow = headers_list[i].lower()
            in_hdr = (dvl in hlow) or any(t in hlow for t in v_terms_lower)
        if in_body or in_hdr:
            src = headers_list[i] if in_hdr else resp
            src_raw = (headers_list[i] if in_hdr else raw) or src
            out.append({"FoundInRequestID": lb, "MatchedResponse": src,
                        "MatchedResponseRaw": src_raw, "MatchPos": None,
                        "FoundInHeader": in_hdr, "ForwardRef": False})
            if len(out) >= limit:
                break
    return out

# ── Routes ─────────────────────────────────────────────────────────────────────
@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'GET':
        PROGRESS.update({"step":"idle","pct":0.0,"eta":"","detail":""})
        return render_template('index.html')

    _progress_start()
    file1=request.files['jmx1']; file2=request.files['jmx2']
    jtl1=request.files['jtl1'];  jtl2=request.files['jtl2']
    datafile=request.files.get('datafile')

    _progress_set_step("UPLOADS")
    path1     = os.path.join(app.config['UPLOAD_FOLDER'], file1.filename)
    path2     = os.path.join(app.config['UPLOAD_FOLDER'], file2.filename)
    # If both JMX were uploaded with the SAME filename, path1 and path2 would point
    # to the same file — file2.save() would overwrite file1, and the diff would then
    # compare a recording against itself (0 diffs, empty results). Force RD2 to a
    # distinct path in that case so the two recordings are preserved separately.
    if os.path.abspath(path1) == os.path.abspath(path2):
        _root, _ext = os.path.splitext(file2.filename or "RD2.jmx")
        path2 = os.path.join(app.config['UPLOAD_FOLDER'], f"{_root}__RD2{_ext or '.jmx'}")
    jtl_path  = os.path.join(app.config['UPLOAD_FOLDER'], 'RJTL1.jtl')
    jtl_path2 = os.path.join(app.config['UPLOAD_FOLDER'], 'RJTL2.jtl')
    file1.save(path1);  _progress_step_fraction(0.25, "Saved JMX1")
    file2.save(path2);  _progress_step_fraction(0.50, "Saved JMX2")
    jtl1.save(jtl_path); _progress_step_fraction(0.75, "Saved JTL1")
    jtl2.save(jtl_path2); _progress_step_fraction(1.0, "Saved JTL2")

    request_filters = []
    if datafile:
        fp = os.path.join(app.config['UPLOAD_FOLDER'], 'filters.txt')
        datafile.save(fp)
        with open(fp,'r',encoding='utf-8',errors='ignore') as f:
            request_filters = [l.strip() for l in f if l.strip()]

    restrict_origin = request.form.get('restrict_origins') == 'on'

    # Minimum value length to attempt correlation. Values shorter than this still
    # appear in the table (so nothing is hidden) but get no regex — a 1–2 char
    # value (a flag flip, a single date digit) is never a real correlation target,
    # and skipping it also avoids the most expensive token_present scans, since
    # such values occur all over the responses. Configurable from the form
    # (min_corr_len); default 3 means 1- and 2-char values are shown but not
    # correlated. Set to 0/1 to correlate everything.
    try:
        min_corr_len = int(request.form.get('min_corr_len', '3'))
    except (TypeError, ValueError):
        min_corr_len = 3

    import json as _json
    excluded_domains_raw = request.form.get('excluded_domains', '')
    excluded_domains = set()
    if excluded_domains_raw:
        try: excluded_domains = set(_json.loads(excluded_domains_raw))
        except: pass

    _progress_set_step("MATCHER")
    _, matched_reqs = get_matching_transactions_and_requests(path1, path2)
    _progress_step_fraction(1.0, f"Matched {len(matched_reqs)} requests")

    _prof_reset()
    _analysis_t0 = time.perf_counter()
    _progress_set_step("DIFFS")
    with _timed("1. diff_detection"):
        diffs = get_all_dynamic_differences(path1, path2)
    _progress_step_fraction(1.0, f"{len(diffs)} diffs")

    diffs_by_req = {}
    for d in diffs:
        diffs_by_req.setdefault(normalize(d["Request"]), []).append(d)

    _progress_set_step("INDEX")
    with _timed("2. build_index RD1"):
        idx1 = build_jtl_index(jtl_path)
    _progress_step_fraction(0.5, "Indexed RD1")
    with _timed("2. build_index RD2"):
        idx2 = build_jtl_index(jtl_path2)
    _progress_step_fraction(1.0, "Indexed RD2")

    presence_cache = {}
    _PSEP = "\x00"                      # separator that can't appear in a token/variant
    _BLOB_CAP = 250_000_000            # ~250M chars/index; above this keep the per-response loop
    def _presence_blobs(ix):
        if "_pblobs" in ix: return ix["_pblobs"]
        rlow = ix["responses_lower"]
        total = 0
        for r in rlow:
            total += len(r)
            if total > _BLOB_CAP:
                ix["_pblobs"] = None    # too large to concatenate safely — use the loop
                return None
        raws = ix.get("responses_raw", ix["responses"])
        hdrs = ix.get("headers_list", [])
        b = {"lower": _PSEP.join(rlow),
             "raw":   _PSEP.join(raws),
             "hdr":   _PSEP.join(h.lower() for h in hdrs) if hdrs else ""}
        ix["_pblobs"] = b
        return b

    def token_present(ix, token):
        if not token: return False
        k = (id(ix), token)
        c = presence_cache.get(k)
        if c is not None: return c
        with _timed("3a. token_present"):
            tl = token.lower()
            il1 = re.match(r'^([Il1])(\d+)$', token); il1_tail = il1.group(2) if il1 else None
            # ── Bulk fast path: this value was pre-resolved by the Aho-Corasick pass.
            # Only trust the set for values we actually pre-analysed (_bulk_values);
            # the I/l/1 regex look-alike isn't in the automaton, so keep it as a
            # fallback. Proven byte-identical to the scan below on synthetic parity.
            bp = ix.get("_bulk_present"); bv = ix.get("_bulk_values")
            if bp is not None and bv is not None and (token in bv) and (_PSEP not in token):
                res = (token in bp)
                if not res and il1_tail:
                    v_terms, v_terms_lower, v_rx = _origin_variants(token)
                    blobs = _presence_blobs(ix)
                    if blobs is not None and v_rx and (
                        (v_rx.search(blobs["raw"]) and il1_tail in blobs["raw"]) or
                        (v_rx.search(blobs["lower"]) and il1_tail in blobs["lower"])):
                        res = True
                presence_cache[k] = bool(res)
                return bool(res)
            v_terms, v_terms_lower, v_rx = _origin_variants(token)
            blobs = _presence_blobs(ix)
            res = False
            if blobs is not None and _PSEP not in token:
                # Fast path: one C-level scan per condition over the whole index.
                # `qt`/`hq` (quoted forms) are subsumed by `tl in lower` — if the token
                # isn't present case-insensitively, a quoted form can't be either.
                if (tl in blobs["lower"]
                        or token in blobs["raw"] or any(t in blobs["raw"] for t in v_terms)
                        or any(t in blobs["lower"] for t in v_terms_lower)
                        or (blobs["hdr"] and (tl in blobs["hdr"] or any(t in blobs["hdr"] for t in v_terms_lower)))):
                    res = True
                elif v_rx and il1_tail:
                    # I-l-1 look-alike — only il1 tokens, only when the plain checks miss.
                    responses = ix["responses"]; raws = ix.get("responses_raw", responses)
                    for i in range(len(responses)):
                        resp = responses[i]; raw = raws[i]
                        if (il1_tail in resp and v_rx.search(resp)) or (raw and il1_tail in raw and v_rx.search(raw)):
                            res = True; break
            else:
                # Exact original per-response loop (very large index, or null in token).
                qt=f'"{token}"'; hq=f"&quot;{token}&quot;"
                hdrs = ix.get("headers_list", []); raws = ix.get("responses_raw", ix["responses"])
                for i in range(len(ix["labels"])):
                    rlow = ix["responses_lower"][i]; resp = ix["responses"][i]; raw = raws[i]
                    if tl in rlow or qt in resp or hq in resp: res=True; break
                    if raw and (token in raw or any(t in raw for t in v_terms)): res=True; break
                    if any(t in rlow for t in v_terms_lower): res=True; break
                    if v_rx and il1_tail and ((il1_tail in resp and v_rx.search(resp)) or (raw and il1_tail in raw and v_rx.search(raw))): res=True; break
                    if i < len(hdrs) and hdrs[i]:
                        hlow = hdrs[i].lower()
                        if tl in hlow or any(t in hlow for t in v_terms_lower): res=True; break
        presence_cache[k] = bool(res)
        return bool(res)

    def _bulk_matched_needles(needles, haystacks):
        """Set of needles occurring in any haystack, via whichever Aho-Corasick
        engine is installed. Overlapping/exact substring — matches `x in blob`."""
        needles = [n for n in needles if n]
        if not needles:
            return set()
        found = set()
        if _AHO is not None:                       # pyahocorasick
            A = _AHO.Automaton()
            for n in needles: A.add_word(n, n)
            A.make_automaton()
            for hay in haystacks:
                if hay:
                    for _e, n in A.iter(hay): found.add(n)
            return found
        if _AHO_RS is not None:                    # ahocorasick_rs (Rust wheels)
            ac = _AHO_RS.AhoCorasick(needles)
            for hay in haystacks:
                if hay:
                    for (i, _s, _en) in ac.find_matches_as_indexes(hay, overlapping=True):
                        found.add(needles[i])
            return found
        return None

    def _build_bulk_present(ix, values):
        if _AHO is None and _AHO_RS is None:
            return
        blobs = _presence_blobs(ix)
        if blobs is None:
            return                                 # index too large — keep the loop
        vals = [v for v in values if v and _PSEP not in v]
        Lneedle = {}; Rneedle = {}                 # needle -> set(value)
        for v in vals:
            tl = v.lower(); vt, vtl, _ = _origin_variants(v)
            for n in {tl, *vtl}:
                if n: Lneedle.setdefault(n, set()).add(v)
            for n in {v, *vt}:
                if n: Rneedle.setdefault(n, set()).add(v)
        present = set()
        for n in (_bulk_matched_needles(list(Lneedle), [blobs["lower"], blobs["hdr"]]) or ()):
            present.update(Lneedle[n])
        for n in (_bulk_matched_needles(list(Rneedle), [blobs["raw"]]) or ()):
            present.update(Rneedle[n])
        ix["_bulk_present"] = present
        ix["_bulk_values"]  = set(vals)

    with _timed("2b. bulk_presence precompute"):
        _vals1 = {str(d.get("RD1")) for d in diffs if d.get("RD1") is not None and len(str(d.get("RD1")).strip()) >= min_corr_len}
        _vals2 = {str(d.get("RD2")) for d in diffs if d.get("RD2") is not None and len(str(d.get("RD2")).strip()) >= min_corr_len}
        _build_bulk_present(idx1, _vals1)
        _build_bulk_present(idx2, _vals2)

    origin_cache={}; table_output=[]
    regex_index=1;   regex_cache={}; _used_varnames=set()
    _progress_set_step("TABLE")
    total=max(1,len(diffs)); built=0
    _loop_t0 = time.perf_counter()

    def _is_excluded(req_name):
        if not excluded_domains: return False
        for domain in excluded_domains:
            if domain and domain.lower() in (req_name or '').lower():
                return True
        return False

    # Iterate the diffs directly and attribute each value to ITS OWN request
    # (diff["Request"]/["RequestRD2"]), not a single collapsed "/app" representative
    # from matched_reqs. Collapsing all "/app" calls onto the first one (e.g. 766)
    # both mislabeled the request column and anchored the origin window at the wrong
    # sampler, which turned valid backward origins (e.g. 895 -> consumer 898) into
    # bogus forward references.
    # ── step-by-step progress for the correlation (table) phase ──────────────
    _tbl_total = len(diffs)
    _tbl_t0    = time.perf_counter()
    _tbl_done  = 0      # rows processed
    _tbl_miss  = 0      # unique value-pairs that triggered actual regex generation
    _tbl_hit   = 0      # rows served from regex_cache
    for diff in diffs:
        _tbl_done += 1
        if PROGRESS.get("cancel"):
            _progress_finish()
            log.info(f"[CANCEL] analysis cancelled by user at row {_tbl_done}/{_tbl_total}")
            # 204 = browser keeps the current page (no navigation), so the client
            # stays on Configure with all selections intact.
            return ("", 204)
        rd1_req  = (diff.get("Request") or "").strip()
        rd2_req  = (diff.get("RequestRD2") or rd1_req).strip()
        txn_name = diff.get("Transaction") or ""
        if not rd1_req: continue
        if _is_excluded(rd1_req): continue
        if restrict_origin and request_filters and not any(p in rd1_req for p in request_filters): continue
        for _ in (0,):   # single pass — preserves the body indentation below
            v1=diff.get("RD1"); v2=diff.get("RD2")
            if v1 is None or v2 is None: continue
            # JSON body diffs can produce non-string values (int, bool, list, dict)
            # Convert to str so they are hashable as dict keys and work in regex logic
            v1=str(v1); v2=str(v2)
            if not v1.strip() or not v2.strip(): continue
            # Values below min_corr_len still get a table row (nothing hidden) but
            # no correlation: skip the origin trace entirely. Empty origins leave
            # r1/r2 empty, which bypasses the regex block below, so the row ends up
            # regex=NA / used=No. This also removes the costliest token_present
            # scans, since 1–2 char values occur all over the responses.
            if len(v1.strip()) < min_corr_len or len(v2.strip()) < min_corr_len:
                origin1 = {"FoundInRequestID":None,"MatchedResponse":None,"MatchPos":None}
                origin2 = {"FoundInRequestID":None,"MatchedResponse":None,"MatchPos":None}
            else:
                k1=("RD1",rd1_req,v1); k2=("RD2",rd2_req,v2)
                with _timed("3. origin_trace (fast_trace+token_present)"):
                    origin1 = origin_cache.get(k1) or (fast_trace_origin(idx1,rd1_req,v1,request_filters,restrict_origin) if token_present(idx1,v1) else {"FoundInRequestID":None,"MatchedResponse":None,"MatchPos":None})
                    origin2 = origin_cache.get(k2) or (fast_trace_origin(idx2,rd2_req,v2,request_filters,restrict_origin) if token_present(idx2,v2) else {"FoundInRequestID":None,"MatchedResponse":None,"MatchPos":None})
                origin_cache[k1]=origin1; origin_cache[k2]=origin2
            rd1_origin=origin1.get("FoundInRequestID") or "NA"
            rd2_origin=origin2.get("FoundInRequestID") or "NA"
            found_in_header = origin1.get("FoundInHeader", False) or origin2.get("FoundInHeader", False)

            fwd_ref = bool(origin1.get("ForwardRef")) or bool(origin2.get("ForwardRef"))
            # Self-reference = the value originates in the SAME request instance
            # that uses it. Compare the FULL recorded label (number + path) — do
            # NOT collapse by path, or every distinct "/app" call (766 vs 871 vs
            # 895) gets mistaken for one request and its correlation wrongly
            # suppressed. A forward reference is a different, later sample and is
            # therefore never a self-reference.
            self_ref = (rd1_origin != "NA" and not fwd_ref
                        and rd1_origin.strip() == (rd1_req or "").strip())

            regex="NA"; used=False; regex_name=""; mc1=mc2=0
            use_headers=False; match_number=None; template="$1$"
            r1=origin1.get("MatchedResponse") or ""; r2=origin2.get("MatchedResponse") or ""
            r1_raw=origin1.get("MatchedResponseRaw") or r1
            r2_raw=origin2.get("MatchedResponseRaw") or r2
            if not self_ref and r1 and r2:
                ck=(v1,v2)
                if ck in regex_cache:
                    _tbl_hit += 1
                    pat,mc1,mc2  = regex_cache[ck]
                    use_headers  = regex_cache.get((ck,"use_headers"),  False)
                    match_number = regex_cache.get((ck,"match_number"), None)
                    template     = regex_cache.get((ck,"template"),     "$1$")
                else:
                    _tbl_miss += 1
                    if found_in_header:
                        hdr_result   = regex_for_header(r1, v1)
                        pat          = hdr_result.get("pattern")
                        use_headers  = True; match_number = None; template = "$1$"
                        if pat:
                            try: mc1 = 1 if re.search(pat, r1) else 0
                            except re.error: mc1 = 0
                            try: mc2 = 1 if re.search(pat, r2) else 0
                            except re.error: mc2 = 0
                        else:
                            mc1 = mc2 = 0
                    else:
                        # Pass the FULL response (capped) and WALK candidates: try the
                        # primary origin first, then later backward responses (up to —
                        # not including — the consumer) until one yields a usable regex.
                        # Whichever response correlates becomes the origin, so the
                        # extractor is injected there. The generator scans every
                        # occurrence within a response, preferring quoted fields and
                        # falling back to unquoted ones — i.e. it behaves like a human
                        # stepping through matches until correlation succeeds.
                        # Cap high enough that real v3locity /app responses (~1 MB)
                        # pass through INTACT. Slicing them truncated the quoted field
                        # buried deep in the HTML and forced "No Regex". Only genuinely
                        # huge bodies (>2 MB) are sliced, and then the window is centered
                        # on a QUOTED occurrence of the value so the clean boundary and
                        # enough context survive. Uniqueness is checked across whatever
                        # text we pass, so passing the full body keeps mc1 accurate.
                        _CAP = 2_000_000
                        def _center_on_value(raw, val):
                            for needle in (f'"{val}"', f'>{val}<', f'={val}&', f'={val}'):
                                q = raw.find(needle)
                                if q != -1:
                                    return raw.find(val, q)
                            return max(raw.find(val), 0)
                        # Build RD1 and RD2 origin-candidate lists. A correlation
                        # is only trustworthy when the SAME pattern matches EXACTLY
                        # ONCE in BOTH recordings (mc1==1 AND mc2==1). If it matches
                        # once in RD1 but many times in RD2 (mc2>1) the boundary is
                        # too generic and would extract the wrong value on different
                        # data; if it matches zero times in RD2 (mc2==0) it is
                        # record-specific. Both are rejected for export.
                        #
                        # RD1 and RD2 frequently resolve the value to DIFFERENT
                        # endpoints (e.g. RD1 a single-result /world/bek response,
                        # RD2 the full search grid), which is exactly what makes a
                        # naive mc2 look like 20. So for each RD1 pattern we also
                        # scan RD2's OWN candidate responses to find the one where
                        # the pattern matches uniquely — that becomes the RD2 origin.
                        def _cap_slice(raw, val):
                            return raw if len(raw) <= _CAP else slice_around(raw, _center_on_value(raw, val), 250000)
                        in2_primary = _cap_slice(r2_raw, v2)
                        from core.regex_generator import _is_html_encoded as _ihe
                        def _mc2_count(pat, c2raw, is_enc, tmpl):
                            """How many times `pat` matches in an RD2 candidate body."""
                            txt = c2raw if is_enc else _clean_cached(c2raw)
                            with _timed("mc2_count(findall)"):
                                try:
                                    ms = re.findall(pat, txt)
                                except re.error:
                                    return 999
                            if ms and isinstance(ms[0], tuple):
                                gi = 0
                                _m = re.match(r'\$(\d+)\$', tmpl or "$1$")
                                if _m: gi = int(_m.group(1)) - 1
                                ms = [t[gi] if gi < len(t) else "" for t in ms]
                            return len(ms)

                        pat = None; use_headers = False
                        with _timed("4. trace_origin_candidates"):
                            _cands1 = (trace_origin_candidates(idx1, rd1_req, v1, request_filters, restrict_origin)
                                       if (token_present(idx1, v1) and not fwd_ref) else [])
                        if rd1_origin != "NA":
                            _cands1 = ([{"FoundInRequestID": rd1_origin, "MatchedResponse": r1,
                                         "MatchedResponseRaw": r1_raw}]
                                       + [c for c in _cands1 if (c.get("FoundInRequestID") or "") != rd1_origin])
                        with _timed("4. trace_origin_candidates"):
                            _cands2 = (trace_origin_candidates(idx2, rd2_req, v2, request_filters, restrict_origin)
                                       if token_present(idx2, v2) else [])
                        if rd2_origin != "NA":
                            _cands2 = ([{"FoundInRequestID": rd2_origin, "MatchedResponse": r2,
                                         "MatchedResponseRaw": r2_raw}]
                                       + [c for c in _cands2 if (c.get("FoundInRequestID") or "") != rd2_origin])
                        _cands1 = _cands1[:6]; _cands2 = _cands2[:6]   # bound cost on ~1 MB bodies

                        _unique = None   # (pat,mc1,mc2,mn,tmpl,c1,c2) mc1==1 & mc2==1  ← best
                        _multi  = None   # (... )                       mc1==1 & mc2>1   (ambiguous RD2)
                        _rd1    = None   # (... )                       mc1==1 & mc2==0  (RD1 only)
                        _pos    = None   # (... )                       mc1>1            (positional)
                        for _c1 in _cands1:
                            _r1raw = _c1.get("MatchedResponseRaw") or _c1.get("MatchedResponse") or ""
                            if not _r1raw:
                                continue
                            _in1 = _cap_slice(_r1raw, v1)
                            with _timed("5. generate_regex (per candidate)"):
                                _pat,_mc1,_mc2,_mn,_tmpl = generate_smart_and_fallback_regex(v1, v2, _in1, in2_primary)
                            if not _pat:
                                continue
                            _isenc = _ihe(_r1raw)
                            if _mc1 == 1:
                                # Find the RD2 candidate where this pattern is UNIQUE.
                                _bm2 = _mc2; _bc2 = None
                                for _c2 in _cands2:
                                    _c2raw = _c2.get("MatchedResponseRaw") or _c2.get("MatchedResponse") or ""
                                    if not _c2raw:
                                        continue
                                    _n = _mc2_count(_pat, _c2raw, _isenc, _tmpl)
                                    if _n == 1:
                                        _bm2 = 1; _bc2 = _c2; break
                                    if _n >= 1 and (_bm2 == 0 or _n < _bm2):
                                        _bm2 = _n; _bc2 = _c2
                                if _bm2 == 1 and _unique is None:
                                    _unique = (_pat,1,1,_mn,_tmpl,_c1,_bc2); break
                                elif _bm2 > 1 and _multi is None:
                                    _multi = (_pat,1,_bm2,_mn,_tmpl,_c1,_bc2)
                                elif _bm2 == 0 and _rd1 is None:
                                    _rd1 = (_pat,1,0,_mn,_tmpl,_c1,None)
                            elif _mc1 > 1 and _pos is None:
                                _pos = (_pat,_mc1,_mc2,_mn,_tmpl,_c1,None)
                        # Priority: unique-in-both → cross-validated positional →
                        # (risky) RD2-multiple → (risky) RD1-only. The positional
                        # bucket is now always cross-validated (same match number in
                        # both recordings), so it outranks the record-specific ones.
                        _pick = _unique or _pos or _multi or _rd1
                        if _pick:
                            _pat,mc1,mc2,match_number,template,_c1,_c2 = _pick
                            pat = _pat
                            rd1_origin = _c1.get("FoundInRequestID") or rd1_origin
                            r1 = _c1.get("MatchedResponse") or r1
                            r1_raw = _c1.get("MatchedResponseRaw") or r1_raw
                            if _c2:
                                rd2_origin = _c2.get("FoundInRequestID") or rd2_origin
                        if pat is None:
                            mc1 = mc2 = 0; match_number = None; template = "$1$"
                        use_headers = False
                    regex_cache[ck]                  = (pat, mc1, mc2)
                    regex_cache[(ck,"use_headers")]  = use_headers
                    regex_cache[(ck,"match_number")] = match_number
                    regex_cache[(ck,"template")]     = template
                if pat:
                    regex=pat; used=True
                    # ── Meaningful variable name derived from request path + field ────
                    # Priority: JSON/XML/Form field name → path last segment → txn name
                    # Guaranteed unique within this analysis by appending regex_index
                    # only when the base name already exists.
                    _field_raw = diff.get("FormField") or diff.get("HeaderName") or ""
                    _kind      = diff.get("Kind","")
                    if not _field_raw and _kind == "json":
                        # "JSON Body: meta.checkoutToken" → "checkoutToken"
                        _fp = diff.get("Field","").replace("JSON Body:","").strip()
                        _field_raw = _fp.split(".")[-1].split("[")[0].strip()
                    if not _field_raw and _kind in ("xml","soap"):
                        _fp = diff.get("Field","").replace("XML Body:","").strip()
                        _field_raw = _fp.split("/")[-1].strip()
                    if not _field_raw and _kind == "path":
                        # path param: use last non-empty path segment of rd1_req
                        _segs = [s for s in (rd1_req or "").split("/") if s and not s.isdigit()]
                        _field_raw = _segs[-1] if _segs else ""
                    if not _field_raw:
                        # Fallback: last meaningful segment of the request label
                        _segs = [s for s in (rd1_req or "").split("/") if s and not s.isdigit()]
                        _field_raw = _segs[-1] if _segs else (txn_name or "VAR")
                    # Sanitise: keep alphanumeric + underscore, TitleCase, max 20 chars
                    _clean = re.sub(r'[^A-Za-z0-9_]', '_', _field_raw).strip('_')
                    _clean = re.sub(r'_+', '_', _clean)          # collapse consecutive _
                    _base  = _clean[:20].strip('_') or "Var"
                    # Ensure uniqueness: only add numeric suffix when base already used
                    _cand  = f"C_{_base}"
                    if _cand in _used_varnames:
                        _cand = f"C_{_base}_{regex_index}"
                    _used_varnames.add(_cand)
                    regex_name = _cand
                    regex_index += 1
            # ── Display / status helpers ─────────────────────────────────────
            # A cross-validated POSITIONAL correlation (mc1>1, with a match number
            # that locates the value at the SAME position in both recordings) is a
            # valid, exportable correlation — just like a unique one.
            _rd2_match = (used and mc1 == 1 and mc2 == 1)
            _pos_ok    = (used and mc1 > 1 and bool(match_number) and mc2 >= 1)
            _corr_ok   = _rd2_match or _pos_ok or use_headers
            # The "#" columns show the MATCH NUMBER the extractor uses (what matters
            # for a positional correlation) for valid rows — equal on both sides —
            # and fall back to the raw match counts for non-correlated rows so the
            # RD2 No Match (0) / RD2 Multiple (N) diagnostics still read correctly.
            if _rd2_match or _pos_ok:
                _disp_rd1 = match_number or mc1
                _disp_rd2 = match_number or mc2
            else:
                _disp_rd1 = mc1
                _disp_rd2 = mc2
            table_output.append({
                "screen_name":txn_name,"rd1_req":rd1_req,"rd2_req":rd2_req,
                "rd1_val":v1,"rd2_val":v2,"rd1_origin":rd1_origin,"rd2_origin":rd2_origin,
                "regex":regex,"used":"Yes" if used else "No","regex_name":regex_name,
                "match_count_rd1":mc1,"match_count_rd2":mc2,
                "disp_rd1":_disp_rd1,"disp_rd2":_disp_rd2,
                "rd2_match":   _rd2_match,
                "pos_ok":      _pos_ok,
                "correlated_ok": _corr_ok,
                "self_ref":    self_ref,
                "forward_ref": fwd_ref,
                "use_headers": use_headers,
                "match_number":match_number,
                "template":    template
            })
            built+=1
            _progress_step_fraction(min(1.0,built/float(total)), f"Row {built}/{total}")

    _prof_add("0. table_loop TOTAL", time.perf_counter() - _loop_t0)
    _prof_add("0. analysis TOTAL",   time.perf_counter() - _analysis_t0)
    _prof_report(f"diffs={len(diffs)} rows={len(table_output)} "
                 f"unique_pairs={len(regex_cache)} responses_RD1={len(idx1.get('labels',[]))} "
                 f"responses_RD2={len(idx2.get('labels',[]))}")

    _progress_set_step("FINALIZE")
    unique={}; order=[]
    for row in table_output:
        k=(row.get("rd1_val"),row.get("rd2_val"))
        if k not in unique: unique[k]=row; order.append(k)
        elif unique[k].get("used")!="Yes" and row.get("used")=="Yes": unique[k]=row
    dedup=[unique[k] for k in order]
    order_map={r:i for i,r in enumerate(get_request_order_from_jmx(path1))}
    dedup=sorted(dedup, key=lambda x: order_map.get(x["rd1_req"],999999))
    add_assertions = request.form.get('add_assertions','') == 'on'
    add_timers     = request.form.get('add_timers','')     == 'on'
    thinktime_ms   = request.form.get('thinktime_ms','3000').strip() or '3000'
    add_vrt        = request.form.get('add_vrt','on')      == 'on'
    add_ar         = request.form.get('add_ar','on')       == 'on'

    SESSION_DATA['correlation_data']=dedup
    SESSION_DATA['input_jmx_path']=path1
    SESSION_DATA['input_jmx_path2']=path2
    SESSION_DATA['request_filters']=request_filters
    SESSION_DATA['jtl_path1']=jtl_path
    SESSION_DATA['jtl_path2']=jtl_path2
    SESSION_DATA['excluded_domains']=list(excluded_domains)
    SESSION_DATA['add_assertions']=add_assertions
    SESSION_DATA['add_timers']=add_timers
    SESSION_DATA['thinktime_ms']=thinktime_ms
    SESSION_DATA['add_vrt']=add_vrt
    SESSION_DATA['add_ar']=add_ar
    _analysis_secs = round(max(0.0, time.time() - PROGRESS.get("started_at", time.time())), 1)
    SESSION_DATA['last_analysis_secs'] = _analysis_secs
    _progress_finish()
    return render_template('index.html', results={
        "table":         dedup,
        "add_assertions": 'on' if add_assertions else '',
        "add_timers":     'on' if add_timers else '',
        "thinktime_ms":   thinktime_ms,
        "add_vrt":        'on' if add_vrt else '',
        "add_ar":         'on' if add_ar else '',
        "elapsed_secs":   _analysis_secs,
        "analysis_secs":  _analysis_secs,
    })

@app.route('/progress')
def progress():
    _el = time.time() - PROGRESS.get("started_at", time.time()) if PROGRESS.get("started_at") else 0.0
    d = {k: PROGRESS.get(k) for k in ("step","pct","eta","detail")}
    d["elapsed"] = round(max(0.0, _el), 1)
    return jsonify(d)

@app.route('/cancel_analysis', methods=['POST'])
def cancel_analysis():
    # Signal the in-flight analysis to stop at its next row check. The client also
    # aborts its request and returns to the Configure screen; this just frees the
    # server thread so it isn't left grinding through the remaining rows.
    PROGRESS["cancel"] = True
    log.info("[CANCEL] cancel requested")
    return ("", 204)

@app.route('/progress_apply')
def progress_apply():
    _el = time.time() - APPLY_PROGRESS.get("started_at", time.time()) if APPLY_PROGRESS.get("started_at") else 0.0
    d = {k: APPLY_PROGRESS.get(k) for k in ("step","pct","eta","detail")}
    d["elapsed"] = round(max(0.0, _el), 1)
    return jsonify(d)


def clear_listener_filenames(jmx_path: str):
    """
    Clears hardcoded JTL filename paths from all ResultCollector elements.
    Only removes machine-specific paths — does not disable any listeners.
    """
    try:
        from lxml import etree as _ET
        parser = _ET.XMLParser(remove_blank_text=True, recover=True)
        tree   = _ET.parse(jmx_path, parser)
        root   = tree.getroot()
        count  = 0
        for collector in root.xpath(".//ResultCollector"):
            fn_el = collector.find("stringProp[@name='filename']")
            if fn_el is not None and fn_el.text and fn_el.text.strip():
                log.info(f"[CLEAN] Cleared listener filename: {fn_el.text.strip()}")
                fn_el.text = None
                count += 1
        if count:
            tree.write(jmx_path, encoding="utf-8", xml_declaration=True, pretty_print=True)
            log.info(f"[CLEAN] Cleared {count} hardcoded filename(s)")
    except Exception as e:
        log.error(f"[CLEAN] clear_listener_filenames error: {e}")


def clean_recorder_artifacts(jmx_path: str):
    """
    Removes Test Script Recorder artifacts from the enhanced JMX:
    1. ProxyControl element + its hashTree (the recorder itself)
    2. Embedded httpSample / sample elements (recorded responses inside the JMX)
    Leaves all ResultCollector (View Results Tree) elements untouched and enabled.
    """
    try:
        from lxml import etree as _ET
        parser = _ET.XMLParser(remove_blank_text=True, recover=True)
        tree   = _ET.parse(jmx_path, parser)
        root   = tree.getroot()
        removed = 0

        # 1. Remove ProxyControl + its immediately following hashTree sibling
        for proxy in root.xpath(".//ProxyControl"):
            parent   = proxy.getparent()
            children = list(parent)
            idx      = children.index(proxy)
            if idx + 1 < len(children) and children[idx + 1].tag == "hashTree":
                parent.remove(children[idx + 1])
                removed += 1
            parent.remove(proxy)
            removed += 1
            log.info("[CLEAN] Removed ProxyControl (HTTP Test Script Recorder)")

        # 2. Remove any embedded httpSample / sample elements anywhere in the JMX
        for tag in ("httpSample", "sample"):
            for el in root.xpath(f".//{tag}"):
                parent = el.getparent()
                if parent is not None:
                    parent.remove(el)
                    removed += 1

        if removed:
            tree.write(jmx_path, encoding="utf-8", xml_declaration=True, pretty_print=True)
            log.info(f"[CLEAN] Removed {removed} recorder artifact(s)")
    except Exception as e:
        log.error(f"[CLEAN] clean_recorder_artifacts error: {e}")


def add_standard_listeners(jmx_path: str, add_vrt: bool = True, add_ar: bool = True):
    """
    Adds standard listeners to the Test Plan level based on user choices:
      - View Results Tree   (add_vrt=True)
      - Aggregate Report    (add_ar=True)

    Skips adding a listener if the user unchecked it OR if it already exists.
    """
    if not add_vrt and not add_ar:
        log.info("[LISTENERS] Both listeners disabled by user — skipping")
        return
    try:
        from lxml import etree as _ET
        parser = _ET.XMLParser(remove_blank_text=True, recover=True)
        tree   = _ET.parse(jmx_path, parser)
        root   = tree.getroot()

        # Check entire JMX for existing listener types — avoids duplicates
        existing = set()
        for rc in root.xpath(".//ResultCollector"):
            gui = rc.get("guiclass", "")
            if gui:
                existing.add(gui)

        log.info(f"[LISTENERS] Existing listeners found: {existing}")

        # Find the Test Plan's hashTree — inject at Test Plan level
        tp_ht = None
        for tp in root.xpath(".//TestPlan"):
            ht = tp.getnext()
            if ht is not None and ht.tag == "hashTree":
                tp_ht = ht
                break

        if tp_ht is None:
            log.warning("[LISTENERS] No TestPlan hashTree found — skipping")
            return

        def _make_listener(guiclass, testclass, testname):
            rc = _ET.Element("ResultCollector", {
                "guiclass":  guiclass,
                "testclass": testclass,
                "testname":  testname,
                "enabled":   "true",
            })
            _ET.SubElement(rc, "boolProp", name="ResultCollector.error_logging").text = "false"
            obj = _ET.SubElement(rc, "objProp")
            _ET.SubElement(obj, "name").text = "saveConfig"
            val = _ET.SubElement(obj, "value")
            val.set("class", "SampleSaveConfiguration")
            for prop, txt in [("time","true"),("latency","true"),("timestamp","true"),
                               ("success","true"),("label","true"),("code","true"),
                               ("message","true"),("threadName","true"),("dataType","true"),
                               ("encoding","false"),("assertions","true"),("subresults","true"),
                               ("responseData","false"),("samplerData","false"),("xml","false"),
                               ("fieldNames","true"),("responseHeaders","false"),
                               ("requestHeaders","false"),("responseDataOnError","false"),
                               ("saveAssertionResultsFailureMessage","true"),
                               ("bytes","true"),("sentBytes","true"),("url","true"),
                               ("threadCounts","true"),("idleTime","true"),
                               ("connectTime","true")]:
                _ET.SubElement(val, prop).text = txt
            _ET.SubElement(rc, "stringProp", name="filename")   # empty — no popup
            return rc

        added = 0

        # 1. View Results Tree — only if user enabled AND not already present
        if add_vrt and "ViewResultsFullVisualizer" not in existing:
            vrt = _make_listener("ViewResultsFullVisualizer", "ResultCollector", "View Results Tree")
            tp_ht.append(vrt)
            tp_ht.append(_ET.Element("hashTree"))
            added += 1
            log.info("[LISTENERS] Added View Results Tree at Test Plan level")
        elif not add_vrt:
            log.info("[LISTENERS] View Results Tree skipped — disabled by user")

        # 2. Aggregate Report — only if user enabled AND not already present
        if add_ar and "StatVisualizer" not in existing:
            ar = _make_listener("StatVisualizer", "ResultCollector", "Aggregate Report")
            tp_ht.append(ar)
            tp_ht.append(_ET.Element("hashTree"))
            added += 1
            log.info("[LISTENERS] Added Aggregate Report at Test Plan level")
        elif not add_ar:
            log.info("[LISTENERS] Aggregate Report skipped — disabled by user")

        if added:
            tree.write(jmx_path, encoding="utf-8", xml_declaration=True, pretty_print=True)
            log.info(f"[LISTENERS] Added {added} standard listener(s) at Test Plan level")
        else:
            log.info("[LISTENERS] No new listeners needed")
    except Exception as e:
        log.error(f"[LISTENERS] add_standard_listeners error: {e}")


def disable_excluded_samplers(jmx_path: str, excluded_domains: list):
    if not excluded_domains: return
    try:
        from lxml import etree as _ET
        parser = _ET.XMLParser(remove_blank_text=True, recover=True)
        tree   = _ET.parse(jmx_path, parser)
        root   = tree.getroot()
        count  = 0
        for sampler in root.xpath(".//HTTPSamplerProxy"):
            label     = (sampler.get("testname") or "").lower()
            domain_el = sampler.find(".//stringProp[@name='HTTPSampler.domain']")
            domain    = (domain_el.text or "").lower() if domain_el is not None else ""
            for excl in excluded_domains:
                if excl and (excl.lower() in label or excl.lower() in domain):
                    sampler.set("enabled", "false")
                    count += 1
                    break
        tree.write(jmx_path, encoding="utf-8", xml_declaration=True, pretty_print=True)
        log.info(f"[DOMAINS] Disabled {count} sampler(s) for excluded domains")
    except Exception as e:
        log.error(f"[DOMAINS] error: {e}")


_XML_ILLEGAL_RE = re.compile(r'[\x00-\x08\x0B\x0C\x0E-\x1F]')
_NUM_CHARREF_RE = re.compile(r'&#(x[0-9A-Fa-f]+|\d+);')

def _charref_ok(m):
    s = m.group(1)
    try:
        cp = int(s[1:], 16) if s[0] in 'xX' else int(s)
    except ValueError:
        return m.group(0)
    if cp in (0x9, 0xA, 0xD) or 0x20 <= cp <= 0xD7FF or 0xE000 <= cp <= 0xFFFD or 0x10000 <= cp <= 0x10FFFF:
        return m.group(0)          # valid codepoint — keep
    return ''                      # invalid (e.g. &#0;) — drop

def _sanitize_jmx_for_export(src_path):
    """Remove XML-1.0-illegal characters and invalid numeric character references
    from the JMX BEFORE parsing. Without this, lxml recover-mode silently drops
    the &quot; entities around a bad byte and corrupts request bodies
    ({&quot;a&quot;:1} -> {a:1}). Returns a cleaned copy's path, or src if clean."""
    try:
        with open(src_path, 'r', encoding='utf-8', errors='replace') as f:
            txt = f.read()
    except Exception as e:
        log.warning(f"[APPLY] Could not read input for sanitize: {e}")
        return src_path
    cleaned = _NUM_CHARREF_RE.sub(_charref_ok, _XML_ILLEGAL_RE.sub('', txt))
    if cleaned == txt:
        return src_path            # nothing illegal — use original untouched
    safe = os.path.join(app.config['DOWNLOAD_FOLDER'], '_sanitized_input.jmx')
    with open(safe, 'w', encoding='utf-8') as f:
        f.write(cleaned)
    log.info(f"[APPLY] Removed invalid XML characters from input before export "
             f"({len(txt) - len(cleaned)} char(s)).")
    return safe

def _restore_stringprop_quotes(path):
    """lxml serializes a quote in element text as a raw " (valid XML, but JMeter
    stores body quotes as &quot;). Re-escape raw " back to &quot; INSIDE stringProp
    text only. Safe-guards: (1) skip self-closing <stringProp .../>, (2) match only
    text with no '<' so it can never span into sibling elements/attributes,
    (3) refuse to write if the result is not well-formed XML."""
    try:
        with open(path, 'r', encoding='utf-8') as f:
            txt = f.read()
    except Exception:
        return
    def _esc(m):
        return m.group(1) + m.group(2).replace('"', '&quot;') + m.group(3)
    # opening tag NOT ending in '/>'  +  text containing no '<'  +  closing tag
    new = re.sub(r'(<stringProp\b[^>]*(?<!/)>)([^<]*)(</stringProp>)', _esc, txt)
    if new == txt:
        return
    try:
        from lxml import etree as _et
        _et.fromstring(new.encode('utf-8'), _et.XMLParser(recover=False))
    except Exception as e:
        log.warning(f"[APPLY] quote-restore would break XML — skipping ({e})")
        return
    with open(path, 'w', encoding='utf-8') as f:
        f.write(new)


@app.route('/apply_selected', methods=['POST'])
def apply_selected():
    try:
        return _apply_selected_inner()
    except Exception as e:
        import traceback
        tb = traceback.format_exc()
        log.error(f"[APPLY] Unhandled exception:\n{tb}")
        return f"<pre>Internal Error in apply_selected:\n\n{tb}</pre>", 500


def _apply_selected_inner():
    # Guard: SESSION_DATA is cleared on server restart — redirect to upload if empty
    input_jmx = SESSION_DATA.get('input_jmx_path')
    if not input_jmx or not os.path.exists(input_jmx):
        log.warning("[APPLY] SESSION_DATA missing or input JMX gone — redirecting to index")
        return render_template('index.html', results={
            "error": "Session expired. Please re-upload your files and run the analysis again."
        })

    # Count steps: extractors + replacements + optional assertions + optional timers
    # Read from SESSION_DATA first (set during analysis), then form hidden inputs as fallback
    _sd_assert = SESSION_DATA.get('add_assertions', None)
    _sd_timers = SESSION_DATA.get('add_timers', None)
    add_assertions = _sd_assert if _sd_assert is not None else (request.form.get('add_assertions') == 'on')
    add_timers     = _sd_timers if _sd_timers is not None else (request.form.get('add_timers')     == 'on')
    thinktime_ms   = SESSION_DATA.get('thinktime_ms') or request.form.get('thinktime_ms', '3000').strip() or '3000'
    add_vrt        = SESSION_DATA.get('add_vrt', True) if SESSION_DATA.get('add_vrt') is not None else (request.form.get('add_vrt', 'on') == 'on')
    add_ar         = SESSION_DATA.get('add_ar',  True) if SESSION_DATA.get('add_ar')  is not None else (request.form.get('add_ar',  'on') == 'on')
    # +1 reserved slot so the (slow) assertion step doesn't tick straight to 100%;
    # 100% is set only by _apply_finish() once everything is actually written.
    total_steps    = 4 + (1 if add_timers else 0)   # extractors + replace + assertions + finalize (+timers)
    _apply_start(total_steps)

    selected_keys=request.form.getlist("selected_regex")
    table_data=SESSION_DATA.get('correlation_data',[])
    base_name=os.path.splitext(os.path.basename(input_jmx))[0]
    ts=datetime.now().strftime("%Y%m%d_%H%M")
    out_path=os.path.join(app.config['DOWNLOAD_FOLDER'], f"{base_name}_{ts}_enhanced.jmx")

    corr_inputs=[]; replacements=[]
    for k in selected_keys:
        rn=request.form.get(f"regex_name_{k}"); rx=request.form.get(f"regex_{k}")
        rl=request.form.get(f"request_label_{k}"); ov=request.form.get(f"original_value_{k}")
        if not all([rn,rx,rl,ov]): continue
        uh     = request.form.get(f"use_headers_{k}",  "false").lower() == "true"
        mn_raw = request.form.get(f"match_number_{k}", "")
        mn     = int(mn_raw) if mn_raw.isdigit() else 1
        tmpl   = request.form.get(f"template_{k}", "$1$") or "$1$"
        corr_inputs.append({"request_label":rl,"dynamic_value":rx,"regex_name":rn,
                            "use_headers":uh,"match_number":mn,"template":tmpl})
        replacements.append({"original_value":ov,"regex_name":rn})

    safe_input = _sanitize_jmx_for_export(input_jmx)
    _apply_tick("Writing extractors…")
    add_regex_extractors_to_jmx(safe_input, out_path, corr_inputs)

    _apply_tick("Replacing values…")
    replace_values_in_jmx(out_path, replacements)

    # ── Timers (lxml-based — must run BEFORE assertions) ─────────────────────
    timer_result = ""
    if add_timers:
        _apply_tick("Adding think time…")
        timer_result = add_timers_to_jmx(out_path, out_path, thinktime_ms)

    # Disable excluded domains (lxml-based — must run BEFORE assertions)
    excl = SESSION_DATA.get('excluded_domains', [])
    if excl:
        disable_excluded_samplers(out_path, excl)

    # ── Clear listener filenames (lxml-based — must run BEFORE assertions) ────
    clear_listener_filenames(out_path)

    # ── Remove recorder artifacts (lxml-based — must run BEFORE assertions) ──
    clean_recorder_artifacts(out_path)

    # ── Add standard listeners (lxml-based — must run BEFORE assertions) ─────
    add_standard_listeners(out_path, add_vrt=add_vrt, add_ar=add_ar)

    # ── Assertions — ALWAYS LAST (string-based, preserves &quot; encoding) ──────
    _apply_tick("Adding assertions…")
    APPLY_PROGRESS["detail"] = "Parsing JTL and writing assertions — this is the longest step…"
    jtl1 = SESSION_DATA.get('jtl_path1')
    jtl2 = SESSION_DATA.get('jtl_path2')
    assert_result = add_assertions_to_jmx(out_path, out_path, jtl1, jtl2)

    # Restore JMeter's &quot; body encoding (lxml writes raw "); cosmetic, both
    # forms read identically, but keeps the exported body matching the original.
    APPLY_PROGRESS.update({"step": "Finalizing…", "detail": "Writing JMX file…"})
    _restore_stringprop_quotes(out_path)

    _apply_secs = round(max(0.0, time.time() - APPLY_PROGRESS.get("started_at", time.time())), 1)
    _apply_finish()

    # ── Time-savings estimate ────────────────────────────────────────────────
    _n_corr = len(corr_inputs)
    _m = re.search(r'(\d+)', assert_result or "")
    _n_assert = int(_m.group(1)) if _m else 0
    _analysis_secs = SESSION_DATA.get('last_analysis_secs', 0.0) or 0.0
    _tool_secs = _analysis_secs + _apply_secs
    _savings = _compute_savings(_n_corr, _n_assert, _tool_secs)

    return render_template('index.html',
        results={
            "table":          table_data,
            "output_jmx":     os.path.basename(out_path),
            "assert_result":  assert_result,
            "timer_result":   timer_result,
            "add_assertions": 'on' if add_assertions else '',
            "add_timers":     'on' if add_timers else '',
            "thinktime_ms":   thinktime_ms,
            "export_secs":    _apply_secs,
            "analysis_secs":  _analysis_secs,
            "savings":        _savings,
        }
    )


# ── Standalone assertion endpoint ─────────────────────────────────────────────

@app.route('/rerun', methods=['POST'])
def rerun():
    """Re-run analysis using already-uploaded files stored in SESSION_DATA."""
    if 'input_jmx_path' not in SESSION_DATA:
        return redirect(url_for('index'))

    path1     = SESSION_DATA['input_jmx_path']
    jtl_path  = SESSION_DATA.get('jtl_path1', '')
    jtl_path2 = SESSION_DATA.get('jtl_path2', '')

    if not all(os.path.exists(p) for p in [path1, jtl_path, jtl_path2] if p):
        return redirect(url_for('index'))

    # Read settings from form (user may have changed them on Screen 2)
    restrict_origin      = request.form.get('restrict_origins') == 'on'
    excluded_domains_raw = request.form.get('excluded_domains', '[]')
    import json as _json
    try:    excluded_domains = set(_json.loads(excluded_domains_raw))
    except: excluded_domains = set()
    request_filters = SESSION_DATA.get('request_filters', [])
    add_assertions  = request.form.get('add_assertions', '') == 'on'
    add_timers      = request.form.get('add_timers', '')     == 'on'
    thinktime_ms    = request.form.get('thinktime_ms', '3000').strip() or '3000'

    _progress_start()
    _progress_set_step("MATCHER")
    _, matched_reqs = get_matching_transactions_and_requests(path1, path1)
    _progress_step_fraction(1.0)

    _progress_set_step("DIFFS")
    diffs = get_all_dynamic_differences(path1, path1)
    _progress_step_fraction(1.0)

    # Re-use same paths
    path2 = path1   # same JMX for both sides when re-running
    # Actually re-use the original second JMX if stored
    path2 = SESSION_DATA.get('input_jmx_path2', path1)

    _progress_set_step("INDEX")
    idx1 = build_jtl_index(jtl_path)
    idx2 = build_jtl_index(jtl_path2)
    _progress_step_fraction(1.0)

    _progress_set_step("TABLE")
    # Re-run with same parameters as before
    diffs_by_req = {}
    for d in diffs:
        diffs_by_req.setdefault(normalize(d["Request"]), []).append(d)

    table_output = SESSION_DATA.get('correlation_data', [])

    _progress_set_step("FINALIZE")
    SESSION_DATA['add_assertions'] = add_assertions
    SESSION_DATA['add_timers']     = add_timers
    SESSION_DATA['thinktime_ms']   = thinktime_ms
    _progress_finish()

    return render_template('index.html', results={
        "table":          table_output,
        "add_assertions": 'on' if add_assertions else '',
        "add_timers":     'on' if add_timers else '',
        "thinktime_ms":   thinktime_ms,
    })


@app.route('/add_assertions_only', methods=['POST'])
def add_assertions_only():
    """Add assertions to an already-correlated JMX (without re-running correlation)."""
    jmx_file = request.files.get('jmx_input')
    if not jmx_file:
        return jsonify({"error": "No JMX file provided"}), 400

    ts = datetime.now().strftime("%Y%m%d_%H%M")
    in_path  = os.path.join(app.config['UPLOAD_FOLDER'],   f"assert_in_{ts}.jmx")
    out_path = os.path.join(app.config['DOWNLOAD_FOLDER'], f"asserted_{ts}.jmx")
    jmx_file.save(in_path)

    jtl1 = SESSION_DATA.get('jtl_path1')
    jtl2 = SESSION_DATA.get('jtl_path2')
    result = add_assertions_to_jmx(in_path, out_path, jtl1, jtl2)

    return jsonify({
        "result":    result,
        "filename":  os.path.basename(out_path),
        "download":  url_for('download_file', filename=os.path.basename(out_path))
    })


# ── Standalone timer endpoint ──────────────────────────────────────────────────
@app.route('/add_timers_only', methods=['POST'])
def add_timers_only():
    """Add think time to an already-correlated JMX."""
    jmx_file      = request.files.get('jmx_input')
    thinktime_ms  = request.form.get('thinktime_ms', '3000')
    if not jmx_file:
        return jsonify({"error": "No JMX file provided"}), 400

    ts = datetime.now().strftime("%Y%m%d_%H%M")
    in_path  = os.path.join(app.config['UPLOAD_FOLDER'],   f"timer_in_{ts}.jmx")
    out_path = os.path.join(app.config['DOWNLOAD_FOLDER'], f"timed_{ts}.jmx")
    jmx_file.save(in_path)

    result = add_timers_to_jmx(in_path, out_path, thinktime_ms)
    return jsonify({
        "result":   result,
        "filename": os.path.basename(out_path),
        "download": url_for('download_file', filename=os.path.basename(out_path))
    })


@app.route('/download/<filename>')
def download_file(filename):
    # Log this JMX download to Supabase (non-blocking — won't break if it fails)
    try:
        token = request.headers.get('Authorization', '').replace('Bearer ', '')
        if token and os.environ.get('SUPABASE_SERVICE_KEY'):
            from auth_routes import _get_user_from_jwt, _sb_post
            user = _get_user_from_jwt(token)
            if user:
                _sb_post('jmx_output_events', {
                    'user_id':  user['id'],
                    'filename': filename,
                })
    except Exception:
        pass
    # Pass download_name so the browser shows the JMX filename in the Save-As
    # dialog instead of the raw URL (which would show the IP:port).
    return send_from_directory(
        app.config['DOWNLOAD_FOLDER'],
        filename,
        as_attachment=True,
        download_name=filename,
    )

@app.route('/reset')
def reset():
    SESSION_DATA.clear()
    PROGRESS.update({"step":"idle","pct":0.0,"eta":"","detail":""})
    APPLY_PROGRESS.update({"step":"idle","pct":0.0,"eta":"","detail":""})
    return redirect(url_for('index'))

# ── Auth routes ────────────────────────────────────────────────────────────────
@app.route('/login')
def login_page():
    return render_template('login.html')

@app.route('/app')
def app_main():
    return render_template('index.html')

@app.route('/admin')
def admin_page():
    return render_template('admin.html')


def find_free_port():
    import socket
    with socket.socket() as s:
        s.bind(('', 0))
        return s.getsockname()[1]

if __name__ == '__main__':
    port = find_free_port()
    # Write port file to user home dir — writable on all platforms
    port_file = os.path.join(os.path.expanduser('~'), '.NestCraft', '.port')
    os.makedirs(os.path.dirname(port_file), exist_ok=True)
    with open(port_file, 'w') as f:
        f.write(str(port))
    print(f"JAC_PORT={port}", flush=True)

    # Engine-version banner: confirms WHICH regex_generator.py this SERVER process
    # actually loaded. A running server keeps the module it imported at startup, so
    # if this build differs from the file on disk you must restart the server.
    try:
        import core.regex_generator as _rg
        print(f"[NestCraft] app build: {__app_build__}  |  regex engine build: {getattr(_rg,'__engine_build__','UNKNOWN')}", flush=True)
    except Exception as _e:
        print(f"[NestCraft] could not read regex engine build: {_e}", flush=True)

    # NOTE: No browser auto-open here — Electron handles the window.
    # When running standalone (not via Electron), open manually at:
    # http://127.0.0.1:PORT/login

    app.run(host='127.0.0.1', port=port, debug=False, threaded=True)
