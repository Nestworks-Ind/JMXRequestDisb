#!/usr/bin/env python3
"""
NestCraft PAIR diagnostic — replicates the EXACT call the row loop makes
========================================================================
The app does NOT correlate RD1 against itself. For each diff it calls:

    generate_smart_and_fallback_regex(v1, v2, RD1_origin_response, RD2_origin_response)

i.e. RD1 value + RD1 origin response, AND RD2 value + RD2 origin response.
This script reproduces that precisely so we can see whether the real
two-recording inputs (not RD1-vs-RD1) produce a regex.

USAGE (run from inside nestjmx_desktop/python_app/):

  python diagnose_pair.py RD1.jtl RD2.jtl  l1947981 l1947984  "917 /app" "1094 /app"

  arg1 = RD1 JTL          arg2 = RD2 JTL
  arg3 = RD1 value (v1)   arg4 = RD2 value (v2)
  arg5 = RD1 consumer label (window anchor, e.g. "917 /app")
  arg6 = RD2 consumer label (e.g. "1094 /app")

Paste the full output back.
"""
import sys, os, re

if len(sys.argv) < 7:
    print(__doc__); sys.exit(1)

RD1_JTL, RD2_JTL, V1, V2, CONS1, CONS2 = sys.argv[1:7]
sys.path.insert(0, os.getcwd())
try:
    import app
    import core.regex_generator as _rg
except Exception as e:
    print(f"[FATAL] import failed from {os.getcwd()} : {e}"); sys.exit(1)

print(f"[ENGINE BUILD] {getattr(_rg,'__engine_build__','UNKNOWN')}")
print("=" * 78)

def first_origin(jtl, consumer, value):
    idx = app.build_jtl_index(jtl)
    cands = app.trace_origin_candidates(idx, consumer, value)
    if cands:
        c = cands[0]
        return c["FoundInRequestID"], (c.get("MatchedResponseRaw") or c.get("MatchedResponse") or "")
    # fall back to plain trace
    o = app.fast_trace_origin(idx, consumer, value)
    return o.get("FoundInRequestID"), (o.get("MatchedResponseRaw") or o.get("MatchedResponse") or "")

lbl1, r1 = first_origin(RD1_JTL, CONS1, V1)
lbl2, r2 = first_origin(RD2_JTL, CONS2, V2)
print(f"RD1: value={V1!r}  consumer={CONS1!r}  -> origin {lbl1!r}  (resp len {len(r1)})")
print(f"RD2: value={V2!r}  consumer={CONS2!r}  -> origin {lbl2!r}  (resp len {len(r2)})")

def ctx(raw, val, n=3):
    out = []
    for m in list(re.finditer(re.escape(val), raw))[:n]:
        p = m.start()
        out.append(raw[max(0,p-50):p+len(val)+50].replace("\n"," "))
    return out

print(f"\nRD1 occurrences of {V1!r}:")
for c in ctx(r1, V1): print("   …"+c+"…")
print(f"RD2 occurrences of {V2!r}:")
for c in ctx(r2, V2): print("   …"+c+"…")

print("\n[EXACT APP CALL] generate_smart_and_fallback_regex(v1, v2, RD1resp, RD2resp)")
pat, mc1, mc2, mn, tmpl = app.generate_smart_and_fallback_regex(V1, V2, r1, r2)
if pat:
    print(f"   ✅ REGEX : {pat}")
    print(f"      mc1={mc1}  mc2={mc2}  match_number={mn}  template={tmpl}")
    print("\n   => Engine produces a regex for the REAL inputs. If the UI still shows")
    print("      'No Regex', click NEW ANALYSIS (re-upload) — the table is cached;")
    print("      a page refresh re-renders the old result.")
else:
    print("   ❌ NO REGEX for the real two-recording inputs.")
    print("      This is the real gap — paste the RD1/RD2 occurrence blocks above")
    print("      and I'll target it. (Likely the RD2 response renders the value")
    print("      differently, or the RD1 origin response chosen here differs.)")
print("=" * 78)
