#!/usr/bin/env python3
"""
NestCraft value diagnostic
==========================
Traces ONE dynamic value through the SAME engine the app uses, against your real
JTL, and prints exactly what the tool sees + the regex it generates.

This tells us whether a "No Regex" is a deployment/cache problem or a real
generation gap — and if it's real, it shows me the actual response context.

USAGE (run from inside  nestjmx_desktop/python_app/  so the imports resolve):

    python diagnose_value.py  /full/path/R1_TC05_LOB_Create_Pension.jtl  l1947981  "917 /app"

  arg1 = RD1 JTL file (the recording whose responses we extract from)
  arg2 = the dynamic VALUE to trace (e.g. l1947981)
  arg3 = (optional) the CONSUMER request label (e.g. "917 /app") to scope the
         backward window; omit to search the whole file.

Paste the full output back to me.
"""
import sys, os, re

if len(sys.argv) < 3:
    print(__doc__); sys.exit(1)

JTL    = sys.argv[1]
VALUE  = sys.argv[2]
CONSUMER = sys.argv[3] if len(sys.argv) > 3 else None

# Make sure we import the app modules from the current working directory
sys.path.insert(0, os.getcwd())
try:
    import app
    import core.regex_generator as _rg
    from core.regex_generator import _is_html_encoded, _resolve_boundaries
except Exception as e:
    print(f"[FATAL] Could not import app/core from {os.getcwd()}")
    print(f"        Run this from inside nestjmx_desktop/python_app/. Error: {e}")
    sys.exit(1)

# FIRST LINE THAT MATTERS: which engine is actually loaded?
_build = getattr(_rg, "__engine_build__", None)
print(f"[ENGINE BUILD] {_build}")
if _build != "2026-06-19-decoded-multiocc-quotedfirst":
    print("  ⚠ The running code is NOT the latest regex_generator.py.")
    print("    Copy the new core/regex_generator.py into place (overwrite), then")
    print("    restart the app / re-run. If you run a packaged build, REBUILD it —")
    print("    editing source .py files does nothing to a PyInstaller/Electron bundle.")
    print()

print("=" * 78)
print(f"JTL    : {JTL}")
print(f"VALUE  : {VALUE!r}")
print(f"CONSUMER (window anchor): {CONSUMER!r}")
print("=" * 78)

if not os.path.exists(JTL):
    print(f"[FATAL] JTL not found: {JTL}"); sys.exit(1)

idx = app.build_jtl_index(JTL)
labels = idx["labels"]
print(f"\n[INDEX] {len(labels)} samples; "
      f"{sum(1 for r in idx['responses'] if r)} with a response body")

# 1) Where does the value appear (response bodies)?
hits = []
for i, resp in enumerate(idx["responses"]):
    raw = idx["responses_raw"][i]
    if VALUE in resp or (raw and VALUE in raw):
        hits.append((i, labels[i]))
print(f"\n[OCCURRENCES] value found in {len(hits)} response(s):")
for i, lb in hits[:25]:
    print(f"   #{i:<5} {lb}")
if not hits:
    print("   (none) — the value never appears in any response body.")
    print("   => This is a genuine 'No Origin' (value is request-only or client-made).")
    sys.exit(0)

# 2) Candidate origins via the SAME function the app uses
if CONSUMER:
    cands = app.trace_origin_candidates(idx, CONSUMER, VALUE)
    print(f"\n[CANDIDATES] backward of {CONSUMER!r} (what the row loop walks): "
          f"{[c['FoundInRequestID'] for c in cands]}")
else:
    cands = [{"FoundInRequestID": lb, "MatchedResponse": idx['responses'][i],
              "MatchedResponseRaw": idx['responses_raw'][i]} for i, lb in hits]

# 3) For the first candidate, dump context around EVERY occurrence + try regex
target = cands[0] if cands else {"FoundInRequestID": hits[0][1],
                                 "MatchedResponse": idx['responses'][hits[0][0]],
                                 "MatchedResponseRaw": idx['responses_raw'][hits[0][0]]}
resp_raw = target.get("MatchedResponseRaw") or target.get("MatchedResponse") or ""
print(f"\n[ORIGIN USED] {target['FoundInRequestID']}  "
      f"(encoded={_is_html_encoded(resp_raw)}, length={len(resp_raw)})")

positions = [m.start() for m in re.finditer(re.escape(VALUE), resp_raw)]
print(f"\n[CONTEXTS] {len(positions)} occurrence(s) in that response "
      f"(showing 60 chars each side):")
for n, p in enumerate(positions[:15], 1):
    ctx = resp_raw[max(0, p-60): p+len(VALUE)+60].replace("\n", " ")
    print(f"   ({n}) …{ctx}…")

# 4) Run the real generator
print("\n[GENERATE] running the SAME generator the app uses…")
pat, mc1, mc2, mn, tmpl = app.generate_smart_and_fallback_regex(
    VALUE, VALUE, resp_raw, resp_raw
)
if pat:
    print(f"   ✅ REGEX : {pat}")
    print(f"      mc1={mc1}  mc2={mc2}  match_number={mn}  template={tmpl}")
else:
    print("   ❌ NO REGEX produced for this response.")
    print("      Paste the [CONTEXTS] block above back to me and I'll target it.")

print("\n" + "=" * 78)
print("If REGEX is produced here but the UI still shows 'No Regex', the running app")
print("is NOT using this code (redeploy core/regex_generator.py + app.py and click")
print("New Analysis — a page refresh reuses cached results).")
print("=" * 78)
