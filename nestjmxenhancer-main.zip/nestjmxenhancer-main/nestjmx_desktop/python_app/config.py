# =============================================================================
# config.py — NestCraft Master Configuration
# =============================================================================
#
# ┌─────────────────────────────────────────────────────────┐
# │  TO SWITCH ENVIRONMENT — change only this one line:     │
# │                                                         │
# │      ENVIRONMENT = 'dev'    ← development               │
# │      ENVIRONMENT = 'prod'   ← production                │
# └─────────────────────────────────────────────────────────┘
#
# ALL keys live here. No other file needs to change.
# =============================================================================

import os

ENVIRONMENT = 'prod'   # ← CHANGE THIS TO 'prod' FOR PRODUCTION BUILD

# =============================================================================
# APP VERSION — change this ONE line to bump the version everywhere
# (shows as the "vX.X" badge in the app + login page, and is reported to the
#  license/admin system as app_version).
# =============================================================================
APP_VERSION = '1.0'

# =============================================================================
# DEV CONFIG
# =============================================================================
DEV = {
    'SUPABASE_URL':         'https://txschnjbpypyqvwehenh.supabase.co',
    'SUPABASE_SERVICE_KEY': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR4c2NobmpicHlweXF2d2VoZW5oIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3NjY1NzA5NCwiZXhwIjoyMDkyMjMzMDk0fQ.G_eWxwiLLa4fGlcqxc7dr_iAQPeYrwK0OnMSjBi7PRM',
    'SUPABASE_ANON_KEY':    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR4c2NobmpicHlweXF2d2VoZW5oIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzY2NTcwOTQsImV4cCI6MjA5MjIzMzA5NH0.jfQmKbG7jNsjVqjpKX4OHSsrpPKq01pabcjOSVE0DQo',
    'ADMIN_EMAILS':         'nestworks99@gmail.com,connect@nest-works.in',
    'FLASK_SECRET':         'nestworks-jmx-2025',
}

# =============================================================================
# PROD CONFIG
# Paste your prod Supabase keys here once you create the prod project
# =============================================================================
PROD = {
    'SUPABASE_URL':         'https://odiiczkvjjrhvlnxkxcs.supabase.co',   # ← paste prod Project URL
    'SUPABASE_SERVICE_KEY': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9kaWljemt2ampyaHZsbnhreGNzIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3NzYwMjM0MSwiZXhwIjoyMDkzMTc4MzQxfQ.Te7Vghd-Ex7eeyY4Ev8sm8UGpqhKcYLrCF-y7dVEOGQ',   # ← paste prod service_role key
    'SUPABASE_ANON_KEY':    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9kaWljemt2ampyaHZsbnhreGNzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzc2MDIzNDEsImV4cCI6MjA5MzE3ODM0MX0.amO2kl3Z-297jzLcO2KC3UdRYLwtQV3xupvgj1GDLJU',   # ← paste prod anon key
    'ADMIN_EMAILS':         'nestworks99@gmail.com,connect@nest-works.in',
    'FLASK_SECRET':         'nestcraft-prod-2025',
}
# =============================================================================
# Active config — selected by ENVIRONMENT above
# Nothing below this line ever needs to change
# =============================================================================

_cfg = DEV if ENVIRONMENT == 'dev' else PROD

SUPABASE_URL         = _cfg['SUPABASE_URL']
SUPABASE_SERVICE_KEY = _cfg['SUPABASE_SERVICE_KEY']
SUPABASE_ANON_KEY    = _cfg['SUPABASE_ANON_KEY']
FLASK_SECRET         = _cfg['FLASK_SECRET']
ADMIN_EMAILS         = {e.strip().lower() for e in _cfg['ADMIN_EMAILS'].split(',')}
