# admin_api.py
# ─────────────────────────────────────────────────────────────────────────────
# Secure backend proxy for the admin panel.
# The SERVICE ROLE key lives ONLY here, in an environment variable.
# The admin panel HTML never sees it — all data calls come through these routes.
#
# HOW TO SET THE ENV VAR:
#   Windows:  set SUPABASE_SERVICE_KEY=your_service_role_key_here
#   Mac/Linux: export SUPABASE_SERVICE_KEY=your_service_role_key_here
#   Or create a .env file (never commit this to git):
#     SUPABASE_SERVICE_KEY=your_service_role_key_here
#     SUPABASE_URL=https://txschnjbpypyqvwehenh.supabase.co
#     ADMIN_EMAILS=nestworks99@gmail.com,connect@nest-works.in
#
# WHERE TO FIND YOUR SERVICE ROLE KEY:
#   Supabase Dashboard → Project Settings → API → service_role (secret)
# ─────────────────────────────────────────────────────────────────────────────

import os
import json
import logging
from datetime import datetime, timezone, timedelta
from functools import wraps

import requests
from flask import Blueprint, request, jsonify, g

log = logging.getLogger(__name__)

# ── Config from environment ───────────────────────────────────────────────────
from config import SUPABASE_URL as SB_URL, SUPABASE_SERVICE_KEY as SERVICE_KEY, ADMIN_EMAILS

if not SERVICE_KEY:
    log.warning(
        '[ADMIN API] ⚠ SUPABASE_SERVICE_KEY not set. '
        'Admin data endpoints will return 503 until this is configured.'
    )

# ── Blueprint ─────────────────────────────────────────────────────────────────
admin_bp = Blueprint('admin_api', __name__, url_prefix='/admin-api')

# ── Supabase REST helpers (service role — bypasses RLS) ──────────────────────

def _sb_headers():
    return {
        'apikey':        SERVICE_KEY,
        'Authorization': f'Bearer {SERVICE_KEY}',
        'Content-Type':  'application/json',
        'Prefer':        'return=representation',
    }

def _sb_get(table, params=None, select='*'):
    """GET rows from a Supabase table using service role."""
    url = f'{SB_URL}/rest/v1/{table}'
    p   = {'select': select, **(params or {})}
    r   = requests.get(url, headers=_sb_headers(), params=p, timeout=10)
    r.raise_for_status()
    return r.json()

def _sb_post(table, data):
    """INSERT a row."""
    url = f'{SB_URL}/rest/v1/{table}'
    r   = requests.post(url, headers=_sb_headers(), json=data, timeout=10)
    r.raise_for_status()
    return r.json()

def _sb_patch(table, match_col, match_val, data):
    """UPDATE rows matching a column value."""
    url    = f'{SB_URL}/rest/v1/{table}'
    params = {match_col: f'eq.{match_val}'}
    r      = requests.patch(url, headers=_sb_headers(),
                            params=params, json=data, timeout=10)
    r.raise_for_status()
    return r.json()

def _sb_delete(table, match_col, match_val):
    """DELETE rows matching a column value."""
    url    = f'{SB_URL}/rest/v1/{table}'
    params = {match_col: f'eq.{match_val}'}
    r      = requests.delete(url, headers=_sb_headers(),
                             params=params, timeout=10)
    r.raise_for_status()
    return r.json()

def _sb_rpc(fn_name, params=None):
    """Call a Supabase stored function."""
    url = f'{SB_URL}/rest/v1/rpc/{fn_name}'
    r   = requests.post(url, headers=_sb_headers(),
                        json=params or {}, timeout=10)
    r.raise_for_status()
    return r.json()

# ── Auth: verify the JWT from the admin browser ───────────────────────────────
def _verify_admin_jwt(token):
    """
    Verify the Supabase JWT using the /auth/v1/user endpoint.
    Returns the user dict if valid and in ADMIN_EMAILS, else None.
    """
    if not token:
        return None
    url = f'{SB_URL}/auth/v1/user'
    headers = {
        'apikey':        SERVICE_KEY,
        'Authorization': f'Bearer {token}',
    }
    try:
        r = requests.get(url, headers=headers, timeout=8)
        if r.status_code != 200:
            return None
        user = r.json()
        email = (user.get('email') or '').lower()
        if email not in ADMIN_EMAILS:
            return None
        return user
    except Exception as e:
        log.warning(f'[ADMIN API] JWT verify error: {e}')
        return None

def require_admin(f):
    """Decorator: verify admin JWT on every data endpoint."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if not SERVICE_KEY:
            return jsonify({'error': 'SUPABASE_SERVICE_KEY not configured on server'}), 503
        auth = request.headers.get('Authorization', '')
        token = auth.replace('Bearer ', '').strip()
        user  = _verify_admin_jwt(token)
        if not user:
            return jsonify({'error': 'Unauthorized — admin session required'}), 401
        g.admin_user = user
        return f(*args, **kwargs)
    return decorated

# ── Auth: create user in Supabase Auth (service role) ────────────────────────
def _create_auth_user(email, password):
    """
    Create a Supabase Auth user using the admin API.
    Returns user_id or raises on error.
    """
    url = f'{SB_URL}/auth/v1/admin/users'
    headers = {
        'apikey':        SERVICE_KEY,
        'Authorization': f'Bearer {SERVICE_KEY}',
        'Content-Type':  'application/json',
    }
    payload = {
        'email':            email,
        'password':         password,
        'email_confirm':    True,   # skip confirmation email
    }
    r = requests.post(url, headers=headers, json=payload, timeout=10)
    if r.status_code == 422:
        # User already exists — resolve their id from Supabase Auth (the
        # authoritative source; user_profiles has no email column).
        uid = _find_auth_user_id(email)
        if uid:
            return uid
        raise ValueError(f'User {email} already exists but could not be located')
    r.raise_for_status()
    return r.json()['id']


def _find_auth_user_id(email):
    """Page through the Auth admin user list and return the id matching email."""
    headers = {'apikey': SERVICE_KEY, 'Authorization': f'Bearer {SERVICE_KEY}'}
    target = (email or '').lower()
    for page in range(1, 11):
        try:
            r = requests.get(f'{SB_URL}/auth/v1/admin/users',
                             headers=headers, params={'page': page, 'per_page': 200}, timeout=10)
        except Exception:
            break
        if not r.ok:
            break
        data = r.json()
        users = data.get('users', data) if isinstance(data, dict) else data
        for u in (users or []):
            if (u.get('email') or '').lower() == target:
                return u.get('id')
        if not users or len(users) < 200:
            break
    return None

# ═══════════════════════════════════════════════════════════════════════════════
# ROUTES
# ═══════════════════════════════════════════════════════════════════════════════

# ── Health check ──────────────────────────────────────────────────────────────
@admin_bp.route('/health')
def health():
    if not SERVICE_KEY:
        return jsonify({'ok': False, 'reason': 'SERVICE_KEY missing'}), 503
    return jsonify({'ok': True, 'service': 'NestCraft Admin API'})

# ── Dashboard stats ───────────────────────────────────────────────────────────
@admin_bp.route('/stats')
@require_admin
def stats():
    try:
        users = _sb_get('user_license_summary')
        total      = len(users)
        active     = sum(1 for u in users if u.get('status') == 'active')
        expired    = sum(1 for u in users if u.get('status') == 'expired')
        suspended  = sum(1 for u in users if u.get('status') == 'suspended')

        # JMX download count
        dl_rows    = _sb_get('jmx_output_events', {}, 'id')
        jmx_dl     = len(dl_rows)

        # Recent activity (last 8 by last_seen_at)
        recent = sorted(
            [u for u in users if u.get('last_seen_at')],
            key=lambda x: x['last_seen_at'], reverse=True
        )[:8]

        return jsonify({
            'total_users':        total,
            'active_licenses':    active,
            'expired_licenses':   expired,
            'suspended_licenses': suspended,
            'jmx_downloads':      jmx_dl,
            'recent_activity':    recent,
        })
    except Exception as e:
        log.error(f'[ADMIN API] stats error: {e}')
        return jsonify({'error': str(e)}), 500

# ── Users list ────────────────────────────────────────────────────────────────
@admin_bp.route('/users')
@require_admin
def list_users():
    try:
        users = _sb_get('user_license_summary')
        return jsonify({'users': users})
    except Exception as e:
        log.error(f'[ADMIN API] users error: {e}')
        return jsonify({'error': str(e)}), 500

# ── Create user + license ─────────────────────────────────────────────────────
@admin_bp.route('/users/create', methods=['POST'])
@require_admin
def create_user():
    d = request.get_json(silent=True) or {}
    required = ['first_name', 'email', 'password', 'plan_id',
                'duration_days', 'max_devices', 'license_key']
    missing = [k for k in required if not d.get(k)]
    if missing:
        return jsonify({'error': f'Missing fields: {", ".join(missing)}'}), 400
    try:
        duration_days = int(d['duration_days'])
        max_devices   = int(d['max_devices'])
    except (TypeError, ValueError):
        return jsonify({'error': 'duration_days and max_devices must be numbers'}), 400

    step = 'create auth user'
    try:
        # 1. Create Auth user (email_confirm=True skips verification email)
        uid = _create_auth_user(d['email'], d['password'])

        # 2. Upsert profile
        step = 'create profile'
        _sb_post('user_profiles', {
            'id':         uid,
            'first_name': d['first_name'],
            'last_name':  d.get('last_name', ''),
            'phone':      d.get('phone', ''),
            'updated_at': datetime.now(timezone.utc).isoformat(),
        })

        # 3. Revoke any existing active license for this user
        try:
            _sb_patch('licenses', 'user_id', uid, {
                'status':     'revoked',
                'updated_at': datetime.now(timezone.utc).isoformat(),
            })
        except Exception:
            pass  # No existing license — fine

        # 4. Create new license
        step = 'create license'
        expires = datetime.now(timezone.utc) + timedelta(days=duration_days)
        _sb_post('licenses', {
            'user_id':     uid,
            'license_key': d['license_key'],
            'plan_id':     d['plan_id'],
            'status':      'active',
            'max_devices': max_devices,
            'expires_at':  expires.isoformat(),
            'notes':       d.get('notes', ''),
        })

        log.info(f"[ADMIN API] Created user {d['email']} with license {d['license_key']}")
        return jsonify({'ok': True, 'user_id': uid})

    except requests.exceptions.RequestException as e:
        # Surface the actual Supabase response body when present.
        detail = ''
        resp = getattr(e, 'response', None)
        if resp is not None:
            try:    detail = resp.json().get('msg') or resp.json().get('message') or resp.text[:300]
            except Exception: detail = (resp.text or '')[:300]
        msg = f'Failed while trying to {step}: {detail or e}'
        log.error(f'[ADMIN API] create_user error ({step}): {e} | {detail}')
        return jsonify({'error': msg}), 502
    except Exception as e:
        log.error(f'[ADMIN API] create_user error ({step}): {e}')
        return jsonify({'error': f'Failed while trying to {step}: {e}'}), 500

# ── License actions (suspend / activate / revoke) ─────────────────────────────
@admin_bp.route('/licenses/action', methods=['POST'])
@require_admin
def license_action():
    d      = request.get_json()
    lid    = d.get('license_id')
    action = d.get('action')
    status_map = {'suspend': 'suspended', 'activate': 'active', 'revoke': 'revoked'}
    if action not in status_map:
        return jsonify({'error': f'Unknown action: {action}'}), 400
    try:
        _sb_patch('licenses', 'id', lid, {
            'status':     status_map[action],
            'updated_at': datetime.now(timezone.utc).isoformat(),
        })
        return jsonify({'ok': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ── Upgrade license (revoke old, create new with new plan + key) ─────────────
@admin_bp.route('/licenses/upgrade', methods=['POST'])
@require_admin
def upgrade_license():
    d       = request.get_json()
    email   = d.get('email', '')
    plan_id = d.get('plan_id')
    key     = d.get('license_key')
    days    = int(d.get('duration_days', 365))
    devices = int(d.get('max_devices', 1))

    if not all([email, plan_id, key]):
        return jsonify({'error': 'Missing required fields'}), 400
    try:
        # Find user_id from email
        profiles = _sb_get('user_profiles', {}, 'id,first_name,last_name')
        # Search auth users for matching email
        auth_url = f'{SB_URL}/auth/v1/admin/users?email={email}'
        ah = {'apikey': SERVICE_KEY, 'Authorization': f'Bearer {SERVICE_KEY}'}
        ar = requests.get(auth_url, headers=ah, timeout=10)
        au = ar.json()
        users_list = au.get('users', []) if isinstance(au, dict) else []
        uid = next((u['id'] for u in users_list
                    if u.get('email','').lower() == email.lower()), None)

        expires = datetime.now(timezone.utc) + timedelta(days=days)
        _sb_post('licenses', {
            'user_id':     uid,
            'license_key': key,
            'plan_id':     plan_id,
            'status':      'active',
            'max_devices': devices,
            'expires_at':  expires.isoformat(),
            'notes':       f'Upgraded on {datetime.now(timezone.utc).strftime("%d %b %Y")}',
        })
        log.info(f'[ADMIN API] Upgraded license for {email}')
        return jsonify({'ok': True})
    except Exception as e:
        log.error(f'[ADMIN API] upgrade_license error: {e}')
        return jsonify({'error': str(e)}), 500

# ── Extend license ────────────────────────────────────────────────────────────
@admin_bp.route('/licenses/extend', methods=['POST'])
@require_admin
def extend_license():
    d    = request.get_json()
    lid  = d.get('license_id')
    days = int(d.get('days', 365))
    try:
        rows = _sb_get('licenses', {'id': f'eq.{lid}'}, 'expires_at,status')
        if not rows:
            return jsonify({'error': 'License not found'}), 404
        current_exp = datetime.fromisoformat(rows[0]['expires_at'].replace('Z', '+00:00'))
        base        = max(current_exp, datetime.now(timezone.utc))
        new_exp     = base + timedelta(days=days)
        _sb_patch('licenses', 'id', lid, {
            'expires_at': new_exp.isoformat(),
            'status':     'active',
            'updated_at': datetime.now(timezone.utc).isoformat(),
        })
        return jsonify({'ok': True, 'new_expires': new_exp.isoformat()})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ── List devices for a license ────────────────────────────────────────────────
@admin_bp.route('/licenses/<license_id>/devices')
@require_admin
def list_devices(license_id):
    try:
        devices = _sb_get('device_activations',
                          {'license_id': f'eq.{license_id}'},
                          '*')
        return jsonify({'devices': devices})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ── Remove a device ───────────────────────────────────────────────────────────
@admin_bp.route('/devices/<device_id>', methods=['DELETE'])
@require_admin
def remove_device(device_id):
    try:
        _sb_delete('device_activations', 'id', device_id)
        # Update activated_devices count on the license
        # (The desktop app recounts on next check-in, so this is cosmetic)
        return jsonify({'ok': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ── Plans list ────────────────────────────────────────────────────────────────
@admin_bp.route('/plans')
@require_admin
def list_plans():
    try:
        plans = _sb_get('plans', {'is_active': 'eq.true', 'order': 'sort_order'})
        return jsonify({'plans': plans})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ── Create plan ───────────────────────────────────────────────────────────────
@admin_bp.route('/plans/create', methods=['POST'])
@require_admin
def create_plan():
    d = request.get_json(silent=True) or {}
    name = (d.get('name') or '').strip()
    if not name:
        return jsonify({'error': 'Plan name required'}), 400
    try:
        duration_days = int(d.get('duration_days', 365))
        max_devices   = int(d.get('max_devices', 1))
    except (TypeError, ValueError):
        return jsonify({'error': 'duration_days and max_devices must be numbers'}), 400

    row = {
        'name':          name,
        'description':   d.get('description', ''),
        'duration_days': duration_days,
        'max_devices':   max_devices,
        'is_active':     True,
    }
    try:
        # sort_order is best-effort — some schemas don't have the column.
        try:
            existing = _sb_get('plans', {'order': 'sort_order.desc', 'limit': '1'}, 'sort_order')
            if existing and existing[0].get('sort_order') is not None:
                row['sort_order'] = existing[0]['sort_order'] + 1
            else:
                row['sort_order'] = 1
        except Exception:
            pass  # no sort_order column — let the DB default it

        _sb_post('plans', row)
        return jsonify({'ok': True})
    except requests.exceptions.RequestException as e:
        detail = ''
        resp = getattr(e, 'response', None)
        if resp is not None:
            try:    detail = resp.json().get('message') or resp.json().get('msg') or resp.text[:300]
            except Exception: detail = (resp.text or '')[:300]
        log.error(f'[ADMIN API] create_plan error: {e} | {detail}')
        return jsonify({'error': f'Could not create plan: {detail or e}'}), 502
    except Exception as e:
        log.error(f'[ADMIN API] create_plan error: {e}')
        return jsonify({'error': f'Could not create plan: {e}'}), 500
