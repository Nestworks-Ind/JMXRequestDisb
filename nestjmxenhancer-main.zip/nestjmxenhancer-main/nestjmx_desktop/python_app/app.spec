# python_app/app.spec
# PyInstaller spec file for NestCraft

import sys
import os

block_cipher = None

a = Analysis(
    ['app.py'],
    pathex=['.'],
    binaries=[],
    datas=[
        ('templates', 'templates'),
        ('core',      'core'),
        ('config.py', '.'),
    ],
    hiddenimports=[
        'flask',
        'flask.templating',
        'jinja2',
        'bs4',
        'lxml',
        'lxml.etree',
        'lxml._elementpath',
        'requests',
        'dotenv',
        'werkzeug',
        'werkzeug.serving',
        'werkzeug.routing',
        'click',
        'difflib',
        'xml.etree.ElementTree',
        'admin_api',
        'auth_routes',
        'config',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='NestCraft',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='NestCraft',
)
