#!/usr/bin/env python3
"""
Trace exactly why specific values are/aren't captured.
Run from inside python_app/ :

    python debug_capture.py "TS13_..._V1.jmx" "TS13_..._V2.jmx"

It runs the REAL diff_detector with a probe list, so the output reflects the
actual pipeline (extraction, matching, JSON parsing) — not a synthetic mock.
Paste the [NestCraft DEBUG] blocks back and the failing stage will be obvious.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from core.diff_detector import get_all_dynamic_differences

PROBES = ["01-035450-00", "681516", "35450",
          "215065", "218691", "218690", "215069", "218695"]

if len(sys.argv) >= 3:
    p1, p2 = sys.argv[1], sys.argv[2]
else:
    print("usage: python debug_capture.py RD1.jmx RD2.jmx [val1 val2 ...]")
    sys.exit(1)
if len(sys.argv) > 3:
    PROBES = sys.argv[3:]

diffs = get_all_dynamic_differences(p1, p2, debug_values=PROBES)
print(f"\nTotal diffs: {len(diffs)}")
