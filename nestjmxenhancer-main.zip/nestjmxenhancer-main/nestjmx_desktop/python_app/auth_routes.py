# auth_routes.py
# ─────────────────────────────────────────────────────────────────────────────
# Flask routes that handle auth + license validation for the desktop app.
# These sit between the desktop app frontend and Supabase.
# Service role key used here — never in the browser.
#
# Register in app.py with:
#   from auth_routes import auth_routes_bp, admin_api_bp
#   app.register_blueprint(auth_routes_bp)
#
# Also import admin_api.py:
#   from admin_api import admin_bp
#   app.register_blueprint(admin_bp)
# ─────────────────────────────────────────────────────────────────────────────

import os
import logging
import random
import string
from datetime import datetime, timezone, timedelta

import requests
from flask import Blueprint, request, jsonify, session, redirect, url_for

logging.basicConfig(level=logging.INFO)
log = logging.getLogger(__name__)

from config import SUPABASE_URL as SB_URL, SUPABASE_SERVICE_KEY as SERVICE_KEY, SUPABASE_ANON_KEY as ANON_KEY

auth_routes_bp = Blueprint('auth_routes', __name__, url_prefix='/auth-api')

# ── Trial license key generator ───────────────────────────────────────────────
def _make_trial_key():
    """Generate a unique trial license key like NW-TRL-XXXX-XXXX."""
    chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
    seg   = lambda: ''.join(random.choices(chars, k=4))
    return f'NW-TRL-{seg()}-{seg()}'

# ── Supabase helpers (service role) ───────────────────────────────────────────
def _svc_headers():
    return {
        'apikey':        SERVICE_KEY,
        'Authorization': f'Bearer {SERVICE_KEY}',
        'Content-Type':  'application/json',
        'Prefer':        'return=representation',
    }

def _sb_get(table, params=None, select='*'):
    url = f'{SB_URL}/rest/v1/{table}'
    p   = {'select': select, **(params or {})}
    r   = requests.get(url, headers=_svc_headers(), params=p, timeout=10)
    r.raise_for_status()
    return r.json()

def _sb_post(table, data):
    url = f'{SB_URL}/rest/v1/{table}'
    r   = requests.post(url, headers=_svc_headers(), json=data, timeout=10)
    r.raise_for_status()
    return r.json()

def _sb_patch(table, match_col, match_val, data):
    url    = f'{SB_URL}/rest/v1/{table}'
    params = {match_col: f'eq.{match_val}'}
    r      = requests.patch(url, headers=_svc_headers(),
                            params=params, json=data, timeout=10)
    r.raise_for_status()
    return r.json()

def _get_user_from_jwt(token: str):
    """Verify a JWT and return the user dict, or None."""
    url = f'{SB_URL}/auth/v1/user'
    headers = {'apikey': SERVICE_KEY, 'Authorization': f'Bearer {token}'}
    try:
        r = requests.get(url, headers=headers, timeout=8)
        if r.status_code == 200:
            return r.json()
    except Exception:
        pass
    return None

# ═══════════════════════════════════════════════════════════════════════════════
# AUTH ROUTES (called by desktop app frontend JS)
# ═══════════════════════════════════════════════════════════════════════════════

# ── OTP: Send ─────────────────────────────────────────────────────────────────
def _email_has_account(email):
    """
    Determine whether an email already has an account.
    Returns True (exists), False (definitely no account), or None (couldn't tell).
    Checks the user_license_summary view first (it exposes email, joined from
    Supabase Auth), then falls back to user_profiles in case a schema differs.
    We only ever REJECT on a definite False, so an inconclusive check never blocks
    a real user from logging in.
    """
    headers = {'apikey': SERVICE_KEY, 'Authorization': f'Bearer {SERVICE_KEY}'}
    for table in ('user_license_summary', 'user_profiles'):
        try:
            r = requests.get(
                f'{SB_URL}/rest/v1/{table}',
                headers=headers,
                params={'email': f'eq.{email}', 'select': 'email', 'limit': '1'},
                timeout=10,
            )
            if r.ok:
                return len(r.json()) > 0          # definitive answer from this source
            # non-OK (e.g. no 'email' column on this table) → try the next source
        except Exception:
            continue
    return None                                    # couldn't determine


@auth_routes_bp.route('/otp/send', methods=['POST'])
def otp_send():
    """
    Login-only OTP send. Accounts are created exclusively through the Admin panel,
    so an email with no account is rejected, and the OTP is always requested with
    create_user=False (no self-signup).
    """
    d     = request.get_json() or {}
    email = d.get('email', '').strip().lower()
    if not email:
        return jsonify({'error': 'Email required'}), 400
    if not SERVICE_KEY:
        return jsonify({'error': 'Server not configured — contact your administrator'}), 503
    try:
        # Reject only when we can confirm there is no account (None = inconclusive → allow).
        if _email_has_account(email) is False:
            return jsonify({
                'error': 'no_account',
                'msg':   'No account found for this email. Please contact your administrator.'
            }), 404

        # Login only — never create a user from this endpoint.
        r = requests.post(
            f'{SB_URL}/auth/v1/otp',
            headers={'apikey': ANON_KEY, 'Content-Type': 'application/json'},
            json={'email': email, 'create_user': False},
            timeout=10
        )
        return jsonify(r.json()), r.status_code
    except Exception as e:
        log.error(f'[OTP/SEND] {e}')
        return jsonify({'error': str(e)}), 500

# ── OTP: Verify ───────────────────────────────────────────────────────────────
@auth_routes_bp.route('/otp/verify', methods=['POST'])
def otp_verify():
    """Proxy OTP verify to Supabase — avoids Electron renderer CSP issues."""
    d     = request.get_json()
    email = d.get('email', '').strip().lower()
    token = d.get('token', '').strip()
    typ   = d.get('type', 'magiclink')   # 'magiclink' or 'signup'
    if not email or not token:
        return jsonify({'error': 'Email and token required'}), 400
    try:
        r = requests.post(
            f'{SB_URL}/auth/v1/verify',
            headers={'apikey': ANON_KEY, 'Content-Type': 'application/json'},
            json={'email': email, 'token': token, 'type': typ},
            timeout=10
        )
        return jsonify(r.json()), r.status_code
    except Exception as e:
        log.error(f'[OTP/VERIFY] {e}')
        return jsonify({'error': str(e)}), 500

# ── Get user profile ──────────────────────────────────────────────────────────
@auth_routes_bp.route('/profile/get')
def get_profile():
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    user  = _get_user_from_jwt(token)
    if not user:
        return jsonify({'error': 'Invalid session'}), 401
    try:
        rows = _sb_get('user_profiles', {'id': f'eq.{user["id"]}'}, '*')
        profile = rows[0] if rows else {}
        # Include email from the JWT user object (not stored in user_profiles table)
        profile['email'] = user.get('email', '')
        return jsonify(profile)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ── Save user profile after signup ────────────────────────────────────────────
@auth_routes_bp.route('/profile/save', methods=['POST'])
def save_profile():
    """
    Called after successful signup.
    1. Saves first_name, last_name, phone to user_profiles.
    2. Auto-creates a 14-day trial license if none exists.
    """
    log.info('[PROFILE/SAVE] Route hit')
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    log.info(f'[PROFILE/SAVE] Token present: {bool(token)}, length: {len(token)}')

    user  = _get_user_from_jwt(token)
    log.info(f'[PROFILE/SAVE] JWT user resolved: {user}')
    if not user:
        log.error('[PROFILE/SAVE] Invalid session — JWT validation failed')
        return jsonify({'error': 'Invalid session'}), 401

    d   = request.get_json()
    uid = user['id']
    log.info(f'[PROFILE/SAVE] uid={uid}, payload={d}')
    try:
        if not SERVICE_KEY:
            log.error('[PROFILE/SAVE] SERVICE_KEY missing — aborting')
            return jsonify({'error': 'Server not configured'}), 503

        # ── Step 1: Save profile ──────────────────────────────────────────────
        log.info(f'[PROFILE/SAVE] Checking existing profile for uid={uid}')
        existing = _sb_get('user_profiles', {'id': f'eq.{uid}'}, 'id')
        log.info(f'[PROFILE/SAVE] Existing profile rows: {existing}')
        if existing:
            log.info('[PROFILE/SAVE] Patching existing profile')
            result = _sb_patch('user_profiles', 'id', uid, {
                'first_name': d.get('first_name', ''),
                'last_name':  d.get('last_name', ''),
                'phone':      d.get('phone', ''),
                'updated_at': datetime.now(timezone.utc).isoformat(),
            })
            log.info(f'[PROFILE/SAVE] Patch result: {result}')
        else:
            log.info('[PROFILE/SAVE] Inserting new profile row')
            result = _sb_post('user_profiles', {
                'id':            uid,
                'first_name':    d.get('first_name', ''),
                'last_name':     d.get('last_name', ''),
                'phone':         d.get('phone', ''),
                'registered_at': datetime.now(timezone.utc).isoformat(),
                'updated_at':    datetime.now(timezone.utc).isoformat(),
            })
            log.info(f'[PROFILE/SAVE] Insert result: {result}')

        # ── Step 2: Auto-create 14-day trial license if none exists ──────────
        existing_lic = _sb_get('licenses', {'user_id': f'eq.{uid}'}, 'id')
        log.info(f'[PROFILE/SAVE] Existing licenses: {existing_lic}')
        if not existing_lic:
            trial_plans = _sb_get('plans',
                                  {'name': 'eq.Trial', 'is_active': 'eq.true'},
                                  'id')
            log.info(f'[PROFILE/SAVE] Trial plan found: {trial_plans}')
            trial_plan_id = trial_plans[0]['id'] if trial_plans else None

            expires = datetime.now(timezone.utc) + timedelta(days=14)
            lic_result = _sb_post('licenses', {
                'user_id':     uid,
                'license_key': _make_trial_key(),
                'plan_id':     trial_plan_id,
                'status':      'active',
                'max_devices': 1,
                'expires_at':  expires.isoformat(),
                'notes':       'Auto-created 14-day trial on signup',
            })
            log.info(f'[PROFILE/SAVE] Trial license created: {lic_result}')

        log.info('[PROFILE/SAVE] Completed successfully')
        return jsonify({'ok': True})
    except Exception as e:
        log.error(f'[PROFILE/SAVE] ERROR: {e}', exc_info=True)
        return jsonify({'error': str(e)}), 500

# ── License check + device registration ───────────────────────────────────────
@auth_routes_bp.route('/license/check', methods=['POST'])
def license_check():
    """
    Called by the desktop app on every launch.
    1. Verifies the user JWT.
    2. Looks up their active license.
    3. Registers/updates the device.
    4. Returns license status + trial info.

    Device fingerprint is hashed on the client — server only stores the hash.
    """
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    user  = _get_user_from_jwt(token)
    if not user:
        return jsonify({'valid': False, 'status': 'unauthenticated',
                        'message': 'Please sign in again'}), 401

    uid = user['id']
    d   = request.get_json() or {}
    device_fp = d.get('device_fingerprint', '')
    machine   = d.get('machine_label', '')
    platform  = d.get('platform', '')
    app_ver   = d.get('app_version', '')

    try:
        if not SERVICE_KEY:
            return jsonify({'valid': False, 'status': 'server_error',
                            'message': 'Server not configured — contact admin'}), 503

        # Find user's active license
        licenses = _sb_get('licenses',
                            {'user_id': f'eq.{uid}', 'order': 'created_at.desc'},
                            '*')
        if not licenses:
            # ── Auto-create 14-day trial license on first login ───────────────
            log.info(f'[AUTH ROUTES] No license for {uid} — auto-creating trial')
            try:
                trial_plans = _sb_get('plans',
                                      {'name': 'eq.Trial', 'is_active': 'eq.true'},
                                      'id')
                log.info(f'[AUTH ROUTES] Trial plan: {trial_plans}')
                trial_plan_id = trial_plans[0]['id'] if trial_plans else None

                expires = datetime.now(timezone.utc) + timedelta(days=14)
                new_lic = _sb_post('licenses', {
                    'user_id':     uid,
                    'license_key': _make_trial_key(),
                    'plan_id':     trial_plan_id,
                    'status':      'active',
                    'max_devices': 1,
                    'expires_at':  expires.isoformat(),
                    'notes':       'Auto-created 14-day trial',
                })
                log.info(f'[AUTH ROUTES] Trial created: {new_lic}')
                # Re-fetch licenses now that trial is created
                licenses = _sb_get('licenses',
                                   {'user_id': f'eq.{uid}', 'order': 'created_at.desc'},
                                   '*')
            except Exception as te:
                log.error(f'[AUTH ROUTES] Trial creation failed: {te}')
                return jsonify({
                    'valid':   False,
                    'status':  'no_license',
                    'message': 'No license found. Contact connect@nest-works.in',
                })

        if not licenses:
            return jsonify({
                'valid':   False,
                'status':  'no_license',
                'message': 'No license found. Contact connect@nest-works.in',
            })

        lic = licenses[0]   # Most recent license

        # Check expiry
        exp = datetime.fromisoformat(lic['expires_at'].replace('Z', '+00:00'))
        now = datetime.now(timezone.utc)
        days_remaining = (exp - now).days

        if lic['status'] == 'revoked':
            return jsonify({
                'valid':   False,
                'status':  'revoked',
                'message': 'Your license has been revoked. Contact connect@nest-works.in',
            })

        if lic['status'] == 'suspended':
            return jsonify({
                'valid':   False,
                'status':  'suspended',
                'message': 'Your license is suspended. Contact connect@nest-works.in',
            })

        if days_remaining < 0 or lic['status'] == 'expired':
            # Auto-expire
            _sb_patch('licenses', 'id', lic['id'], {
                'status':     'expired',
                'updated_at': now.isoformat(),
            })
            return jsonify({
                'valid':   False,
                'status':  'expired',
                'message': 'Your license has expired. Contact connect@nest-works.in to renew.',
            })

        # ── Device check ─────────────────────────────────────────────────────
        if device_fp:
            # Fetch all registered devices for this license
            all_devices = _sb_get('device_activations',
                                  {'license_id': f'eq.{lic["id"]}'}, '*')

            # Check if this exact fingerprint is already registered
            fp_match = next(
                (dv for dv in all_devices
                 if dv.get('device_fingerprint') == device_fp),
                None
            )

            if fp_match:
                # ── Known device — allow and update last seen ─────────────────
                _sb_patch('device_activations', 'id', fp_match['id'], {
                    'last_seen_at': now.isoformat(),
                    'app_version':  app_ver,
                    'is_active':    True,
                })

            elif len(all_devices) == 0:
                # ── First device — register it ────────────────────────────────
                _sb_post('device_activations', {
                    'license_id':         lic['id'],
                    'user_id':            uid,
                    'device_fingerprint': device_fp,
                    'machine_label':      machine,
                    'platform':           platform,
                    'app_version':        app_ver,
                    'is_active':          True,
                })
                _sb_patch('licenses', 'id', lic['id'], {
                    'activated_devices': 1,
                    'updated_at':        now.isoformat(),
                })

            else:
                # ── Different device — check if within limit ──────────────────
                max_dev = lic.get('max_devices', 1)
                if len(all_devices) >= max_dev:
                    # Get registered machine name for helpful message
                    registered_machine = all_devices[0].get('machine_label', 'another device')
                    return jsonify({
                        'valid':   False,
                        'status':  'device_limit',
                        'message': (
                            f'This license is registered to: {registered_machine}. '
                            f'To use NestCraft on this device, '
                            f'please contact connect@nest-works.in '
                            f'to authorise a device change.'
                        ),
                        'registered_machine': registered_machine,
                        'activated_devices':  len(all_devices),
                        'max_devices':        max_dev,
                    })
                else:
                    # Within limit — register additional device
                    _sb_post('device_activations', {
                        'license_id':         lic['id'],
                        'user_id':            uid,
                        'device_fingerprint': device_fp,
                        'machine_label':      machine,
                        'platform':           platform,
                        'app_version':        app_ver,
                        'is_active':          True,
                    })
                    _sb_patch('licenses', 'id', lic['id'], {
                        'activated_devices': len(all_devices) + 1,
                        'updated_at':        now.isoformat(),
                    })

        # ── Get plan name ─────────────────────────────────────────────────────
        plan_name = '—'
        if lic.get('plan_id'):
            plans = _sb_get('plans', {'id': f'eq.{lic["plan_id"]}'}, 'name')
            if plans:
                plan_name = plans[0]['name']

        is_trial = 'trial' in plan_name.lower() or days_remaining <= 14

        return jsonify({
            'valid':           True,
            'status':          lic['status'],
            'license_key':     lic['license_key'],
            'plan_name':       plan_name,
            'expires_at':      lic['expires_at'],
            'days_remaining':  days_remaining,
            'trial':           is_trial,
            'max_devices':     lic.get('max_devices', 1),
            'message':         (
                f'Trial — {days_remaining} days remaining'
                if is_trial else
                f'Licensed until {exp.strftime("%d %b %Y")}'
            ),
        })

    except Exception as e:
        log.error(f'[AUTH ROUTES] license_check error: {e}')
        return jsonify({'valid': False, 'status': 'error',
                        'message': str(e)}), 500

# ── Log JMX download ──────────────────────────────────────────────────────────
@auth_routes_bp.route('/device/deactivate', methods=['POST'])
def device_deactivate():
    """Called on logout — marks current device as inactive."""
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    user  = _get_user_from_jwt(token)
    if not user:
        return jsonify({'ok': False}), 401

    d         = request.get_json() or {}
    device_fp = d.get('device_fingerprint', '')
    if not device_fp:
        return jsonify({'ok': True})  # No fingerprint — nothing to deactivate

    try:
        # Find this device
        lics = _sb_get('licenses', {'user_id': f'eq.{user["id"]}'}, 'id')
        for lic in lics:
            devices = _sb_get('device_activations',
                              {'license_id': f'eq.{lic["id"]}'}, '*')
            match = next(
                (d for d in devices if d.get('device_fingerprint') == device_fp),
                None
            )
            if match:
                # Mark device inactive
                _sb_patch('device_activations', 'id', match['id'], {
                    'is_active':    False,
                    'last_seen_at': datetime.now(timezone.utc).isoformat(),
                })
                # Update active count on license
                active_count = len([d for d in devices
                                    if d.get('is_active', True)
                                    and d['id'] != match['id']])
                _sb_patch('licenses', 'id', lic['id'], {
                    'activated_devices': active_count,
                    'updated_at':        datetime.now(timezone.utc).isoformat(),
                })
                break
        return jsonify({'ok': True})
    except Exception as e:
        log.warning(f'[AUTH ROUTES] device_deactivate: {e}')
        return jsonify({'ok': True})  # Non-critical


@auth_routes_bp.route('/log/jmx-download', methods=['POST'])
def log_jmx_download():
    """
    Called when a user downloads a processed JMX.
    Logged for the admin "JMX Downloads" stat.
    """
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    user  = _get_user_from_jwt(token)
    d     = request.get_json() or {}

    try:
        if SERVICE_KEY and user:
            # Find user's license
            lics = _sb_get('licenses', {'user_id': f'eq.{user["id"]}'}, 'id')
            lid  = lics[0]['id'] if lics else None
            _sb_post('jmx_output_events', {
                'license_id': lid,
                'user_id':    user['id'],
                'filename':   d.get('filename', ''),
            })
        return jsonify({'ok': True})
    except Exception as e:
        log.warning(f'[AUTH ROUTES] log_jmx_download: {e}')
        return jsonify({'ok': True})  # Non-critical — don't fail the download

# ── Log installer download (called from website) ───────────────────────────────
@auth_routes_bp.route('/log/installer-download', methods=['POST'])
def log_installer_download():
    """
    Called by nest-works.in when someone downloads the installer.
    IP is hashed — no PII stored.
    """
    import hashlib
    d        = request.get_json() or {}
    ip_raw   = request.remote_addr or ''
    ip_hash  = hashlib.sha256(ip_raw.encode()).hexdigest()[:16]
    platform = d.get('platform', 'unknown')

    try:
        if SERVICE_KEY:
            _sb_post('download_events', {
                'platform':  platform,
                'ip_hash':   ip_hash,
            })
        return jsonify({'ok': True})
    except Exception as e:
        log.warning(f'[AUTH ROUTES] log_installer_download: {e}')
        return jsonify({'ok': True})
