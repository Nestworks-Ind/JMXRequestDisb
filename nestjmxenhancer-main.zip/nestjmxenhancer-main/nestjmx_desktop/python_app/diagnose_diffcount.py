#!/usr/bin/env python3
"""
Diagnose what is inflating the diff count (and therefore the analysis runtime).
Run from inside python_app/ :

    python diagnose_diffcount.py "RD1.jmx" "RD2.jmx"

It does NOT trace origins or build regexes — it only inspects the raw diffs
returned by diff_detector, so it finishes in seconds and tells you exactly
which categories are producing the 27k rows and how much each light filter
would remove WITHOUT touching the values you actually care about.
"""
import sys, os
from collections import Counter, defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from core.diff_detector import get_all_dynamic_differences

if len(sys.argv) < 3:
    print("usage: python diagnose_diffcount.py RD1.jmx RD2.jmx"); sys.exit(1)
p1, p2 = sys.argv[1], sys.argv[2]

diffs = get_all_dynamic_differences(p1, p2)
N = len(diffs)
print(f"\nTOTAL diffs: {N}\n")

# ---- by Kind ----
by_kind = Counter(d.get("Kind", "?") for d in diffs)
print("By Kind:")
for k, c in by_kind.most_common():
    print(f"   {k:8} {c:7}  ({100*c/N:.1f}%)")

# ---- two-sided vs one-sided (one-sided is dropped by app.py line 778) ----
def s(x): return (x if isinstance(x, str) else str(x)).strip()
two_sided = [d for d in diffs if s(d.get("RD1")) and s(d.get("RD2"))]
print(f"\nTwo-sided (reach the tracer): {len(two_sided)}   "
      f"One-sided (already dropped downstream): {N-len(two_sided)}")

# ---- length distribution of the RD1 value on two-sided diffs ----
buckets = defaultdict(int)
for d in two_sided:
    L = len(s(d.get("RD1")))
    b = "len 1-3" if L <= 3 else "len 4-5" if L <= 5 else "len 6-9" if L <= 9 else "len 10+"
    buckets[b] += 1
print("\nTwo-sided RD1 value length:")
for b in ("len 1-3", "len 4-5", "len 6-9", "len 10+"):
    print(f"   {b:9} {buckets[b]:7}")

# ---- how much would light, ID-preserving filters trim? ----
def survives_lenfloor(d, floor):
    # only apply the floor to form/raw fields; leave json/path/xml/header untouched
    if d.get("Kind") in ("form", "raw"):
        return len(s(d.get("RD1"))) >= floor
    return True
for floor in (4, 6):
    kept = [d for d in two_sided if survives_lenfloor(d, floor)]
    print(f"\nIf form/raw fields with len < {floor} were not traced: "
          f"{len(kept)} traced  (−{len(two_sided)-len(kept)}, "
          f"~{100*(len(two_sided)-len(kept))/max(1,len(two_sided)):.0f}% fewer)")

# ---- pure-numeric vs alpha-numeric on two-sided form/raw ----
fr = [d for d in two_sided if d.get("Kind") in ("form", "raw")]
boolish = sum(1 for d in fr if s(d.get("RD1")).lower() in ("true","false","on","off","yes","no","0","1"))
print(f"\nForm/raw two-sided: {len(fr)}   of which boolean/flag-like: {boolish}")

# ---- top noisy form field names ----
ff = Counter(d.get("FormField","") for d in two_sided if d.get("Kind")=="form" and d.get("FormField"))
if ff:
    print("\nTop 15 form fields by diff count (likely volatile Pega state):")
    for name, c in ff.most_common(15):
        print(f"   {c:5}  {name[:70]}")
