# JMeter Postman / Insomnia Collection Importer

A JMeter GUI plugin that turns a **Postman** (v2.0 / v2.1) or **Insomnia** (v4 JSON/YAML, v5 YAML) collection
into a JMeter test plan.

* The plan is built from JMeter's **Recording** template (`bin/templates/recording.jmx`, a bundled copy is used
  if the file is missing): User Defined Variables, HTTP Request Defaults, HTTP Cookie Manager, Thread Group,
  View Results Tree and the (disabled) HTTP(S) Test Script Recorder are kept.
* Under the **Thread Group**, every API of the collection gets its own **Simple Controller**
  (named `Folder / Sub folder / Request`) holding the sampler and its HTTP Header Manager.
* REST / HTTP(S) calls become **HTTP Request** samplers; GraphQL calls become **GraphQL HTTP Request** samplers
  (query, variables and operation name are filled in).
* Every request is processed, including requests in nested folders.

Tested with JMeter 5.6.3 (Java 8+).

## Install

1. Copy `jmeter-collection-importer-1.0.0.jar` to `JMETER_HOME/lib/ext/`.
2. Restart JMeter.

## Use

1. **Tools > Import from Postman / Insomnia collection...**
2. Choose the collection file. Optionally choose a Postman environment file (its values override the
   collection variables) and where to save the `.jmx`.
3. Choose *Open as a new test plan* or *Merge into the current test plan* and press **Import**.

The plan is saved to disk and opened. A summary lists anything that needs a manual look.

### Command line

```
java -cp "jmeter-collection-importer-1.0.0.jar:$JMETER_HOME/lib/*" io.github.collection2jmx.Cli \
     my.postman_collection.json [-e my.postman_environment.json] [-o plan.jmx] [-t recording.jmx]
```

(use `;` instead of `:` in the classpath on Windows)

## What is converted

| Collection | JMeter |
|---|---|
| Folders (any depth) | Simple Controller name prefix `Folder / Sub / Request` |
| Collection variables, Postman environment, Insomnia base + first sub environment | "Collection Variables" (User Defined Variables) under the Test Plan |
| `{{var}}`, `{{ _.var }}` | `${var}` (nested Insomnia values become `${a.b}`) |
| `{{$guid}}`, `{{$randomUUID}}`, `{{$timestamp}}`, `{{$randomInt}}`, `{% uuid %}`, `{% now %}` … | `${__UUID()}`, `${__time(/1000,)}`, `${__Random(0,1000,)}` … |
| Headers (disabled ones skipped), Insomnia folder headers | HTTP Header Manager under the sampler |
| Query params (disabled ones skipped), Postman `:pathVariables` | Sampler path |
| Raw body (JSON, XML, text) | Body Data |
| x-www-form-urlencoded | Parameters (URL-encoded) |
| form-data with files | multipart/form-data + Files Upload |
| Binary file body | Files Upload without parameter name |
| Postman `graphql` body, Insomnia GraphQL body, or a JSON `{"query": …}` body sent to a `…graphql…` URL | GraphQL HTTP Request |
| Bearer, Basic, API key auth (inherited from collection / folder, `noauth` respected) | `Authorization` header / query parameter |

URLs with a literal host are split into protocol / server / port / path. The most used host is written into the
template's `host` / `scheme` variables and HTTP Request Defaults, and samplers for that host leave the server
empty (like a recording). URLs that start with a variable (`{{baseUrl}}/users`) are kept whole in the path, which
JMeter resolves at run time.

## Not converted (listed in the import summary where relevant)

* Pre-request and test scripts (add JSR223 PreProcessors / Assertions as needed).
* Insomnia response chaining tags (`{% response … %}`) – use a JMeter extractor.
* OAuth 1/2, Digest, NTLM, AWS auth – use the HTTP Authorization Manager.
* gRPC and WebSocket requests.

## Build

```
mvn package
```

The plugin JAR is `target/jmeter-collection-importer-1.0.0.jar` (SnakeYAML is shaded in; everything else is
provided by JMeter). Sample collections are in `samples/`.
