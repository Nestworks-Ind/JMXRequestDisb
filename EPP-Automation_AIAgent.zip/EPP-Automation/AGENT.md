# Using EPP Automation from GitHub Copilot (VS Code Agent mode)

Copilot can run the same four steps as the web page. You ask in plain English; Copilot plans the run, asks you to
confirm, and then the tool does the work in Edge.

## One-time setup

1. Unzip EPP-Automation.zip over your EPP-Automation folder (say Yes to replacing files).
2. In VS Code choose **File > Open Folder** and pick the `EPP-Automation` folder. Click "Yes, I trust the authors".
3. Open `.vscode/mcp.json`. Click **Start** above `"epp-automation"`. VS Code asks for your EPP password once
   and keeps it. It is never written to a file.
4. Open Copilot Chat (`Ctrl+Alt+I`) and choose **Agent** at the bottom. Click the tools icon and check that
   **epp-automation** is ticked.

If Start shows an error about MCP being disabled, your company's Copilot policy blocks MCP servers. Tell me and we
will use the command-line route instead.

## Each time

1. Put the JMX and CSV files in the `test-files` folder.
2. Close the black EPP Automation window if it is open (both use the same Edge profile).
3. Ask Copilot, for example:

   > Using application "ServiceNow OF Performance Testing" and MSID sgali16, upload SN_SC09_Search.jmx and
   > SN_SC09_Logins.csv, create the simulation with 1 smoke user, and create the SmokeTest and LoadTest jobs.
   > Show the browser.

4. Copilot shows a plan. Say yes. When it calls the tool, VS Code asks you to allow it. Click **Allow** (or
   **Continue**).
5. Copilot reports what was created. Screenshots are in `runs\agent-...`.

To stop a run, press the Stop button in Copilot Chat.
