Put the JMX scripts and CSV test data files you want Copilot to use in this folder.
