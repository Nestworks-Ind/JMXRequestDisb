# EPP Automation agent: notes for GitHub Copilot

This folder holds EPP Automation. In Agent mode you have two tools from the `epp-automation` MCP server:

- `list_test_files`: lists the JMX scripts and CSV files in the `test-files` folder.
- `run_epp_steps`: signs in to EPP (https://performance.optum.com), selects the application, runs the chosen steps
  in Microsoft Edge and signs out. The steps are:
  1. `uploadJmx`: upload JMX scripts to GitHub `src/test/jmeter` and check they are there
  2. `uploadCsv`: upload CSV files to GitHub `target/jmeter/bin` and check they are there
  3. `createSimulation`: one simulation per JMX (the file name without .jmx), with SmokeTest_ and LoadTest_ scenarios
  4. `createBatch`: a Smoke job and a Load job that hold the matching scenario of every simulation

## Rules

- Use only these tools for EPP and GitHub work. Do not run terminal commands, write scripts or edit files to do it.
- EPP and GitHub are **production**. Before calling `run_epp_steps` with any step switched on, show the user a short
  plan: application, which steps, which files, smoke and load settings, and job names. Wait for them to say yes.
- Call `list_test_files` first and use its paths. If a file the user names is missing, ask them to put it in `test-files`.
- Ask for anything missing: application name, MSID (userName) and the number of smoke users. Use the defaults for
  the rest unless the user gives values: smoke ramp-up 10, duration 300, load generators 1, CPU cores 0.25,
  heap 2048; load users 10 with the same other values; jobs SmokeTest and LoadTest in environment Test.
- Never ask for, print or store the password. VS Code gives it to the server.
- Run all the steps the user wants in **one** `run_epp_steps` call, so they sign in only once.
- Use `showBrowser: true` when the user wants to watch, or when Microsoft sign-in may need an Authenticator approval.
- Afterwards, summarise the result in plain English: what was created, what was skipped because it already existed,
  and any warnings. If it failed, quote the error line and the screenshots folder. Do not retry more than once
  without asking the user.
- Nothing can delete files, simulations, scenarios or jobs, and you should never try to.
