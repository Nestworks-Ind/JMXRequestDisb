import { DEFAULT_SETTINGS, displayName, exportModel } from '../lib/common.js';
import { snapshotFromModel } from '../lib/baseline.js';
import { buildJmx } from '../lib/jmx.js';
import { buildJtlCsv, buildJtlXml } from '../lib/jtl.js';
import { buildZip } from '../lib/zip.js';

const $ = (id) => document.getElementById(id);
const send = (msg) => chrome.runtime.sendMessage(msg);

let state = null;
const armed = new Map(); // buttons waiting for a confirming second click
const expanded = new Set();

if (new URLSearchParams(location.search).has('popped')) document.body.classList.add('popped');

function stamp() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}`;
}

function download(content, filename, type) {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

function baseName() {
  const run = state.dual ? `_recording${state.dual}` : '';
  return (state.settings.testPlanName || 'recording').replace(/[^\w.-]+/g, '_') + run + '_' + stamp();
}

function shortUrl(url) {
  try {
    const u = new URL(url);
    return u.host + u.pathname + (u.search ? u.search.slice(0, 40) + (u.search.length > 40 ? '…' : '') : '');
  } catch (_) {
    return url;
  }
}

function statusCell(r) {
  if (r.error) return `<span class="s bad" title="${escapeHtml(r.error)}">ERR</span>`;
  if (!r.endTime) return `<span class="s pending">…</span>`;
  return `<span class="s ${r.statusCode < 400 ? 'ok' : 'bad'}">${r.statusCode}</span>`;
}

function escapeHtml(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
}

function render() {
  if (!state) return;
  const st = $('status');
  st.className = 'pill' + (state.recording ? (state.paused ? ' paused' : ' rec') : '');
  st.textContent = (state.recording ? (state.paused ? 'Paused' : 'Recording') : 'Idle') + (state.dual ? ` · ${state.dual} of 2` : '');

  const hasData = state.transactions.length > 0;
  $('start').disabled = state.recording;
  const one = state.settings.dualRecording ? ' 1' : '';
  if (!armed.has($('start'))) $('start').textContent = hasData && !state.recording ? `● New recording${one}` : `● Start recording${one}`;
  $('resume').hidden = state.recording || !hasData;
  $('pause').disabled = !state.recording;
  $('pause').textContent = state.paused ? 'Unpause' : 'Pause';
  $('stop').disabled = !state.recording;
  $('clear').disabled = !hasData;
  for (const id of ['exportJmx', 'exportJtlCsv', 'exportJtlXml']) $(id).disabled = !hasData;

  const reqCount = state.transactions.reduce((n, t) => n + t.requests.length, 0);
  $('captureError').hidden = !state.captureError;
  $('captureError').textContent = state.captureError || '';
  $('summary').textContent = hasData ? `${state.transactions.length} transactions · ${reqCount} requests` : '';

  // Don't clobber an in-progress rename.
  if (document.activeElement && document.activeElement.matches('#transactions input')) return;

  const list = $('transactions');
  const atBottom = list.scrollTop + list.clientHeight >= list.scrollHeight - 4;
  // Names as they will be exported (baseline-aligned when a baseline is active).
  const model = exportModel(state);
  const byId = new Map(model.transactions.map((t) => [t.id, t]));
  const labelOf = new Map(model.transactions.flatMap((t) => t.requests.map((r) => [r.requestId, r])));
  const baselineOn = !!model.baseline;
  list.innerHTML = state.transactions
    .map((tx, i) => {
      const open = expanded.has(tx.id);
      const m = byId.get(tx.id);
      const name = m ? m.name : displayName(tx, i);
      let flag = '';
      if (baselineOn && m && !tx.customName) {
        if (!m.baselineName) flag = '<span class="flag" title="No transaction at this position in recording 1">new</span>';
        else if (m.kindMismatch) flag = '<span class="flag" title="Recording 1 has a different kind of action here; check the steps match">check</span>';
      }
      const reqs = open
        ? `<ul class="reqs">${tx.requests
            .map(
              (r) =>
                `<li><span class="m">${escapeHtml(r.method)}</span><span class="u" title="${escapeHtml((labelOf.get(r.requestId)?.label || '') + '  ' + r.url)}">${escapeHtml(shortUrl(r.url))}</span>${baselineOn && labelOf.get(r.requestId)?.newInRun ? '<span class="flag" title="Not in recording 1">new</span>' : ''}${statusCell(r)}<button class="icon" data-act="del-req" data-req="${escapeHtml(r.requestId)}" title="Remove request">✕</button></li>`
            )
            .join('') || '<li><span class="u">No requests</span></li>'}</ul>`
        : '';
      return `<div class="tx" data-id="${tx.id}">
        <div class="tx-head">
          <button class="toggle" data-act="toggle">${open ? '▾' : '▸'}</button>
          <span class="tx-name" data-act="rename" title="Click to rename">${escapeHtml(name)}</span>${flag}
          <span class="tx-count ${tx.requests.length ? '' : 'zero'}">${tx.requests.length} req</span>
          ${i > 0 ? '<button class="icon" data-act="merge" title="Merge into previous transaction">⤒</button>' : ''}
          <button class="icon" data-act="del" title="Delete transaction">✕</button>
        </div>${reqs}</div>`;
    })
    .join('');
  if (atBottom) list.scrollTop = list.scrollHeight;

  for (const el of document.querySelectorAll('[data-setting]')) {
    const v = state.settings[el.dataset.setting] ?? DEFAULT_SETTINGS[el.dataset.setting];
    if (document.activeElement === el) continue;
    if (el.type === 'checkbox') el.checked = !!v;
    else el.value = v;
  }
}

// ---- Parameters (name/value pairs substituted at export) ----
let paramsDraft = null;
const NAME_RE = /^[A-Za-z_][\w.-]*$/;

function renderParams() {
  const box = $('params');
  if (box.contains(document.activeElement)) return;
  const params = state.settings.parameters || [];
  paramsDraft = params.map((p) => ({ ...p }));
  const valid = params.filter((p) => NAME_RE.test(p.name || '') && p.value).length;
  $('paramCount').textContent = valid ? String(valid) : '';
  box.innerHTML = paramsDraft
    .map(
      (p, i) => `<div class="param-row" data-i="${i}">
        <input type="text" data-field="name" placeholder="Name, e.g. username" value="${escapeHtml(p.name)}" class="${p.name && !NAME_RE.test(p.name) ? 'invalid' : ''}" title="Letters, digits, _ . - ; must not start with a digit" />
        <input type="text" data-field="value" placeholder="Value, e.g. alice" value="${escapeHtml(p.value)}" />
        <button class="icon" data-remove="${i}" title="Remove parameter">✕</button>
      </div>`
    )
    .join('');
}

function saveParams() {
  refresh({ type: 'update-settings', settings: { parameters: paramsDraft.filter((p) => p.name || p.value) } });
}

$('params').addEventListener('input', (e) => {
  const row = e.target.closest('.param-row');
  if (!row) return;
  paramsDraft[row.dataset.i][e.target.dataset.field] = e.target.value;
  if (e.target.dataset.field === 'name') e.target.classList.toggle('invalid', !!e.target.value && !NAME_RE.test(e.target.value));
});
$('params').addEventListener('change', saveParams);
$('params').addEventListener('click', (e) => {
  const i = e.target.dataset.remove;
  if (i == null) return;
  paramsDraft.splice(Number(i), 1);
  saveParams();
});
$('addParam').onclick = () => {
  paramsDraft.push({ name: '', value: '' });
  state.settings.parameters = paramsDraft;
  renderParams();
  $('params').lastElementChild.querySelector('input').focus();
};

// ---- Dual recording: record the flow twice, recording 2 named like recording 1 ----
function renderDual() {
  const on = !!state.settings.dualRecording;
  const phase = state.dual;
  const has = state.transactions.length > 0;
  $('dualToggle').disabled = state.recording;
  $('dualPanel').hidden = !on && !phase;
  let text;
  let run2 = null; // label of the "recording 2" button, or null to hide it
  if (phase === 1 && state.recording) text = 'Recording 1 of 2 in progress. Press Stop when the flow is done.';
  else if (phase === 1 && has) {
    text = 'Recording 1 is done and kept. Start recording 2 and repeat the same steps with other data. At the end you can download both recordings in one go.';
    run2 = '● Start recording 2';
  } else if (phase === 2 && state.recording) text = 'Recording 2 of 2 in progress. Transactions and requests are named like recording 1; steps that were not in recording 1 are tagged "new".';
  else if (phase === 2) {
    text = state.run1
      ? 'Both recordings are done. Download both recordings\' .jmx and .jtl files in one .zip.'
      : 'Recording 2 is done. Download its .jmx and .jtl below.';
    run2 = '● Redo recording 2';
  } else text = 'Press Start to make recording 1. When you stop, it is kept and you can start recording 2, which gets the same transaction and request names. At the end you download both recordings in one .zip.';
  $('dualText').textContent = text;
  $('startRun2').hidden = !run2;
  $('sessionNote').hidden = !(phase === 2 && state.sessionNote);
  $('sessionNote').textContent = state.sessionNote || '';
  $('downloadBoth').hidden = !(phase === 2 && !state.recording && has && state.run1);
  if (run2 && !armed.has($('startRun2'))) $('startRun2').textContent = run2;
}

// recording1/ and recording2/ folders, each with the .jmx and both .jtl formats.
$('downloadBoth').onclick = () => {
  const stamp_ = stamp();
  const plan = (state.settings.testPlanName || 'recording').replace(/[^\w.-]+/g, '_');
  const run1 = { settings: state.settings, transactions: state.run1.transactions, startedAt: state.run1.startedAt, baseline: null };
  const files = [];
  for (const [n, st] of [[1, run1], [2, state]]) {
    const name = `${plan}_recording${n}`;
    files.push({ name: `${name}.jmx`, content: buildJmx(st) });
    files.push({ name: `${name}.jtl`, content: buildJtlCsv(st) });
    files.push({ name: `${name}_xml.jtl`, content: buildJtlXml(st) });
  }
  download(buildZip(files), `${plan}_dual_${stamp_}.zip`, 'application/zip');
};

$('startRun2').onclick = () => {
  if (state.dual === 2) {
    // Redo: keep recording 1's names, discard this recording 2.
    if (state.transactions.length && !confirmClick($('startRun2'), 'Click again: discards recording 2')) return;
    refresh({ type: 'start', mode: 'dual2', baseline: state.baseline });
    return;
  }
  const baseline = snapshotFromModel(exportModel(state).transactions);
  refresh({ type: 'start', mode: 'dual2', baseline });
};

// Inline "click twice" confirmation. Native confirm()/alert() dialogs are
// unreliable in toolbar popups (the popup can close and the click is lost).
function confirmClick(btn, prompt) {
  if (armed.has(btn)) {
    clearTimeout(armed.get(btn).timer);
    btn.textContent = armed.get(btn).text;
    armed.delete(btn);
    return true;
  }
  const text = btn.textContent;
  btn.textContent = prompt;
  armed.set(btn, {
    text,
    timer: setTimeout(() => {
      btn.textContent = text;
      armed.delete(btn);
    }, 4000),
  });
  return false;
}

async function refresh(msg) {
  const res = await send(msg || { type: 'get-state' });
  if (res && !res.error) state = res;
  render();
  renderParams();
  renderDual();
  if (!state.transactions.length && !state.recording && !(state.settings.parameters || []).length) $('paramsBox').open = true;
}

$('start').onclick = () => {
  if (state.transactions.length && !confirmClick($('start'), 'Click again: discards current steps')) return;
  refresh({ type: 'start', mode: state.settings.dualRecording ? 'dual1' : 'single' });
};
$('resume').onclick = () => refresh({ type: 'start', append: true });
$('pause').onclick = () => refresh({ type: 'pause' });
$('stop').onclick = () => refresh({ type: 'stop' });
$('clear').onclick = () => confirmClick($('clear'), 'Click again to clear') && refresh({ type: 'clear' });

function addTx() {
  const name = $('txName').value.trim();
  refresh({ type: 'add-transaction', name });
  $('txName').value = '';
}
$('addTx').onclick = addTx;
$('txName').addEventListener('keydown', (e) => e.key === 'Enter' && addTx());

$('popout').onclick = () => {
  chrome.windows.create({ url: chrome.runtime.getURL('popup/popup.html?popped=1'), type: 'popup', width: 520, height: 720 });
  window.close();
};

$('exportJmx').onclick = () => download(buildJmx(state), baseName() + '.jmx', 'application/xml');
$('exportJtlCsv').onclick = () => download(buildJtlCsv(state), baseName() + '.jtl', 'text/csv');
$('exportJtlXml').onclick = () => download(buildJtlXml(state), baseName() + '_xml.jtl', 'application/xml');

$('transactions').addEventListener('click', (e) => {
  const btn = e.target.closest('[data-act]');
  if (!btn) return;
  const id = btn.closest('.tx').dataset.id;
  switch (btn.dataset.act) {
    case 'toggle':
      expanded.has(id) ? expanded.delete(id) : expanded.add(id);
      render();
      break;
    case 'del':
      refresh({ type: 'delete-transaction', id });
      break;
    case 'merge':
      refresh({ type: 'merge-into-previous', id });
      break;
    case 'del-req':
      refresh({ type: 'delete-request', requestId: btn.dataset.req });
      break;
    case 'rename': {
      const input = document.createElement('input');
      input.type = 'text';
      input.value = btn.textContent;
      btn.textContent = '';
      btn.appendChild(input);
      input.focus();
      input.select();
      let done = false;
      const commit = (save) => {
        if (done) return;
        done = true;
        input.blur();
        if (save) refresh({ type: 'rename-transaction', id, name: input.value.trim() });
        else render();
      };
      input.addEventListener('keydown', (ev) => {
        if (ev.key === 'Enter') commit(true);
        if (ev.key === 'Escape') commit(false);
      });
      input.addEventListener('blur', () => commit(true));
      break;
    }
  }
});

for (const el of document.querySelectorAll('[data-setting]')) {
  el.addEventListener('change', () => {
    let v = el.type === 'checkbox' ? el.checked : el.value;
    if (el.type === 'number') v = parseInt(v, 10) || 0;
    refresh({ type: 'update-settings', settings: { [el.dataset.setting]: v } });
  });
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'state-changed') refresh();
});

refresh();
