# JMX Recorder (Chrome extension)

Records what you do in Chrome (clicks, keyboard entries, form submits) together with the HTTP requests each action triggers, and exports:

- **.jmx**: a JMeter test plan with one **Transaction Controller per user action**, each holding the HTTP Request samplers that action fired.
- **.jtl**: the recorded browser timings as JMeter results, in CSV (default JMeter format) or XML.

It replaces the HTTP(S) Test Script Recorder: no proxy to configure and no certificate to install, because the extension reads traffic straight from Chrome (HTTPS included).

## Install

1. Unzip `jmx-recorder.zip` into a folder you will keep (Chrome loads it from there).
2. Open `chrome://extensions` and turn on **Developer mode** (top right).
3. Click **Load unpacked** and select the unzipped folder (the one containing `manifest.json`).
4. Pin **JMX Recorder** from the puzzle-piece menu so the icon stays in the toolbar.

Works in any Chromium browser (Chrome, Edge, Brave) version 116 or newer.

## Record a script

1. Open the tab of the application you want to script.
2. Click the extension icon and press **Start recording**. The icon badge turns red and counts transactions.
3. Use the application normally. Each click, field entry, Enter key press or URL you open becomes a transaction such as `T04 - Click Sign in`, and the requests it triggers are grouped under it.
4. Optional: type a name in **Name the next transaction** and press **Add** to start a transaction with your own name (like JMeter's recorder transaction naming).
5. Press **Stop**, then **Export .jmx**, **Export .jtl (CSV)** or **Export .jtl (XML)**.

Tip: use **Pop out** to keep the recorder open in its own window while you click through the app. The popup otherwise closes when you click the page, but recording keeps running in the background.

In the transaction list you can click a name to rename it, expand it to see its requests (and remove unwanted ones), merge a transaction into the previous one, or delete it. **Resume** continues recording onto the existing list.

## Parameters (test data)

Before you record, open **Parameters** in the popup and add the data you are going to type, as name/value pairs, for example `username = alice`, `password = s3cret`, `searchTerm = jmeter`.

When you export the .jmx:

- every recorded occurrence of a value (form fields, query strings, JSON/XML bodies, URL paths, headers) is replaced with `${name}`, e.g. `{"q":"${searchTerm}"}`;
- each name and value is added to the test plan's **User Defined Variables**.

Values are matched as whole tokens (not inside a longer word), plain or URL-encoded. Parameters are kept between recordings until you remove them.

## Dual recording (same names for a second run)

Use this to record the same flow twice with different data, so you can compare the two .jmx / .jtl files in your own tool and find the dynamic values.

1. Tick **Dual recording** next to the Start button, then press **Start recording 1** and do the flow.
2. Press **Stop**. Recording 1 is kept by the extension, so you don't need to download anything yet.
3. Press **Start recording 2** and repeat the same steps with other data, then press **Stop**.
   With **Start recording 2 signed out** ticked (the default), the extension first removes the cookies and site data of every site recording 1 used, including the SSO login site, and then opens recording 1's first page in a fresh tab. That way the SSO login is recorded again, and you don't have to restart the browser. To record in an incognito window, turn on **Allow in Incognito** in the extension's Details.
4. Press **Download both recordings (.zip)**. You get one zip with `…_recording1.jmx`, `…_recording1.jtl`, `…_recording1_xml.jtl` and the same three files for recording 2.

Recording 2's transactions and requests get **the same names as recording 1** (`T04 - Click Sign in`, `002 /login`, ...), even if a button label or an id in the URL changed. Transactions are paired by position. Requests are matched by method and path, with id-like path segments ignored. A step or request that wasn't in recording 1 is tagged **new** in the popup and gets a number after recording 1's last one. **Redo recording 2** records it again with recording 1's names.

## What the .jmx contains

The plan follows JMeter's standard **Recording** template (File > Templates > Recording), except that the recorded Transaction Controllers sit directly under the Thread Group (no Recording Controller, no timers):

```
Test Plan
├─ User Defined Variables      host, scheme + your parameters
├─ HTTP Request Defaults       ${scheme}://${host}
├─ HTTP Cookie Manager
├─ Thread Group                threads / ramp-up / loops from Settings
│  ├─ T01 - Open example.com              (Transaction Controller)
│  │   └─ 001 /                           (HTTP Request + HTTP Header Manager)
│  ├─ T02 - Enter Username
│  ├─ T03 - Enter Password
│  ├─ T04 - Click Sign in
│  │   └─ 002 /login                      (username=${username}, password=${password})
│  └─ ...
├─ View Results Tree
└─ HTTP(S) Test Script Recorder (disabled, as in the template)
```

- Requests to the main recorded site use `${host}` and `${scheme}`, so switching environment means editing one variable. Other hosts stay literal.
- Form posts become parameters, JSON/XML bodies become **Body Data**, GET query strings become parameters.
- Cookies are left to the Cookie Manager rather than hard-coded.
- `Accept-Encoding` is set to `gzip, deflate`. Chrome also offers `br, zstd`, and JMeter cannot decode zstd, so those responses would show as blank or binary.
- Conditional cache headers (`If-None-Match`, `If-Modified-Since`, ...) are dropped. Otherwise the server answers `304 Not Modified` with an empty body.
- Redirects are followed by the sampler, so a `POST /login → 302 → /home` chain is one sampler, as with the proxy recorder.
- The typed value and page URL are kept in each Transaction Controller's comment (passwords masked).

## Settings

| Setting | Default | What it does |
|---|---|---|
| Skip static resources | on | Drops images, CSS, JS, fonts, media. |
| URL patterns to exclude | static extensions and common analytics hosts | One regex per line. |
| URL patterns to include | empty (all) | Restrict to your application's host, e.g. `.*myapp\.example\.com.*`. |
| Record all tabs | off | By default only the tab where you pressed Start, plus popups it opens. |
| Keep transactions with no requests | on | A transaction for every entry, even when typing fired no request. Turn off for a leaner plan. |
| Add recorded think time | off | Adds your real pauses between transactions as Flow Control Action + Constant Timer. |
| Generate parent sample | off | Transaction Controller "Generate parent sample". |
| HTTP Header Manager per request | on | Recorded headers (minus Cookie, Host, Content-Length). |
| Response code assertion per request | off | Asserts the recorded status code. |
| Use ${host} / ${scheme} variables | on | Recording-template style host/scheme variables and HTTP Request Defaults. |
| Clear cookies each iteration | on | Each loop starts a fresh session. |

## Notes and limits

- **JTL values come from the browser.** Elapsed and latency are Chrome's timings. `bytes` uses the `Content-Length` header (or the captured body size).
- **Response data is in the XML .jtl only.** With **Capture response bodies** on (the default), the extension reads each response through Chrome's debugger API, so Chrome shows a "JMX Recorder started debugging this browser" bar while you record. Don't press Cancel on that bar, or responses stop being stored. The XML .jtl then holds response data, response and request headers, and post data, which you can see in View Results Tree. JMeter's CSV format has no column for response data. Binary responses (images, PDFs) are not stored, and bodies over 2 MB are truncated.
- **Dynamic values (tokens, session IDs) still need correlation** in JMeter, the same as with the proxy recorder.
- **Form field order**: Chrome reports `application/x-www-form-urlencoded` fields in its own order, which can differ from the page. This rarely matters to servers.
- **File uploads**: the file content is not captured; the sampler gets a placeholder and a comment telling you to set the file in the Files Upload tab.
- WebSocket traffic is not recorded.

## Development

- `background.js` captures requests (`chrome.webRequest`) and groups them by action.
- `content.js` captures clicks and keyboard entries in every frame.
- `lib/jmx.js`, `lib/jtl.js` build the export files; `popup/` is the UI.
- `test/e2e.mjs` loads the extension in Chromium with Playwright, records a session against `test/server.mjs`, and writes the exports to `test/out/`. Run with `node test/e2e.mjs`.
