// Captures user actions (clicks, keyboard entries, form submits) and reports
// them to the background worker, which opens a new transaction for each one.
(() => {
  // A copy left over from before the extension was reloaded/updated can no
  // longer talk to it (chrome.runtime.id is gone), so let a fresh copy take over.
  const prev = window.__jmxRecorder;
  if (prev && prev.alive()) return;
  if (prev) prev.retire();
  let retired = false;
  window.__jmxRecorder = {
    alive: () => !retired && !!(chrome.runtime && chrome.runtime.id),
    retire: () => (retired = true),
  };

  const MAX_LABEL = 40;

  const clean = (s) => (s || '').replace(/\s+/g, ' ').trim().slice(0, MAX_LABEL);

  const INTERACTIVE = 'a,button,input,select,textarea,label,summary,[role=button],[role=link],[role=menuitem],[role=tab],[role=checkbox],[role=option],[onclick]';

  function describe(el) {
    if (!el || el.nodeType !== 1) return 'element';
    const target = el.closest(INTERACTIVE) || el;
    const tag = target.tagName.toLowerCase();
    let text =
      target.getAttribute('aria-label') ||
      (tag === 'input' && ['submit', 'button', 'reset'].includes(target.type) ? target.value : '') ||
      target.innerText ||
      target.getAttribute('title') ||
      target.getAttribute('alt') ||
      target.getAttribute('placeholder') ||
      target.getAttribute('name') ||
      target.id ||
      (target.querySelector && target.querySelector('img[alt]')?.getAttribute('alt')) ||
      '';
    text = clean(text);
    return text || tag;
  }

  function fieldName(el) {
    let label = '';
    if (el.id) {
      const l = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
      if (l) label = l.innerText;
    }
    if (!label && el.closest('label')) label = el.closest('label').innerText;
    return clean(label || el.getAttribute('aria-label') || el.placeholder || el.name || el.id || el.tagName.toLowerCase());
  }

  function send(kind, label, extra = {}) {
    if (retired) return;
    try {
      chrome.runtime.sendMessage({
        type: 'user-action',
        kind,
        label,
        url: location.href,
        time: Date.now(),
        ...extra,
      });
    } catch (_) {
      // Extension was reloaded; this page's content script is orphaned.
    }
  }

  // Clicks (capture phase so we see them before page handlers navigate away).
  document.addEventListener(
    'click',
    (e) => {
      if (!e.isTrusted) return;
      const t = e.target;
      // Clicking into a text field is not interesting; the entry itself is.
      if (t && t.matches && t.matches('input:not([type=submit]):not([type=button]):not([type=checkbox]):not([type=radio]):not([type=reset]):not([type=image]), textarea, select')) return;
      send('click', describe(t));
    },
    true
  );

  // Keyboard entries: one action per field, sent when the field value is committed.
  const pending = new Map();
  function commitField(el) {
    if (!pending.has(el)) return;
    pending.delete(el);
    const masked = el.type === 'password';
    send('input', fieldName(el), { value: masked ? '******' : clean(el.value) });
  }

  document.addEventListener(
    'input',
    (e) => {
      const t = e.target;
      if (!e.isTrusted || !t || !t.matches) return;
      if (t.matches('select, input[type=checkbox], input[type=radio]')) {
        send('select', fieldName(t), { value: clean(t.type === 'checkbox' ? String(t.checked) : t.value) });
        return;
      }
      if (t.matches('input, textarea, [contenteditable]')) pending.set(t, true);
    },
    true
  );

  document.addEventListener('change', (e) => e.isTrusted && commitField(e.target), true);
  document.addEventListener('blur', (e) => e.isTrusted && commitField(e.target), true);

  document.addEventListener(
    'keydown',
    (e) => {
      if (!e.isTrusted) return;
      if (e.key === 'Enter' && e.target && e.target.matches && e.target.matches('input, [contenteditable]')) {
        // Commit the typed value first, then the Enter key itself (often submits / searches).
        commitField(e.target);
        send('enter', fieldName(e.target));
      }
    },
    true
  );

  document.addEventListener(
    'submit',
    (e) => {
      if (!e.isTrusted) return;
      // Flush any field still focused when the form was submitted.
      for (const el of [...pending.keys()]) commitField(el);
      const f = e.target;
      send('submit', clean(f.getAttribute('name') || f.id || f.getAttribute('action') || 'form'));
    },
    true
  );
})();
