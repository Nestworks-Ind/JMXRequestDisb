// Background service worker: owns the recording state, listens to webRequest
// events and groups every captured request under the transaction opened by
// the most recent user action in that tab.
import { DEFAULT_SETTINGS, STATIC_TYPES, compileRegexList } from './lib/common.js';

const STORAGE_KEY = 'jmxRecorderState';
// A main-frame request with no user action this recently is treated as a
// direct navigation (typed URL, bookmark, reload) and gets its own transaction.
const NAV_ACTION_WINDOW_MS = 1500;
// Submit/Enter right after a click/entry that has not produced requests yet
// is the same user gesture, so it does not open another transaction.
const MERGE_WINDOW_MS = 600;

const SKIP_HEADERS = new Set(['cookie', 'content-length', 'host', 'connection', 'proxy-connection', 'keep-alive', 'te', 'trailer', 'transfer-encoding', 'upgrade']);

let state = freshState();
let inflight = new Map(); // requestId -> request record (also referenced from its transaction)
let filters = buildFilters(state.settings);

function freshState(settings, baseline, dual) {
  return {
    baseline: baseline || null,
    dual: dual || null, // 1 or 2 during a dual recording, else null
    run1: null, // during recording 2: recording 1's { transactions, startedAt, hostsSeen, startUrl }
    hostsSeen: [], // every host the recorded tabs contacted (also filtered-out ones), for a clean recording 2
    recording: false,
    paused: false,
    tabs: [],
    startedAt: null,
    txSeq: 0,
    transactions: [],
    lastAction: {}, // tabId -> { time, txId }
    settings: { ...DEFAULT_SETTINGS, ...(settings || {}) },
  };
}

function buildFilters(settings) {
  return {
    exclude: compileRegexList(settings.excludeUrlRegex),
    include: compileRegexList(settings.includeUrlRegex),
  };
}

const ready = chrome.storage.local.get(STORAGE_KEY).then((res) => {
  if (res[STORAGE_KEY]) {
    state = { ...freshState(), ...res[STORAGE_KEY] };
    state.settings = { ...DEFAULT_SETTINGS, ...state.settings };
    filters = buildFilters(state.settings);
    // Rebuild in-flight index for requests that had not completed when the worker slept.
    for (const tx of state.transactions) for (const r of tx.requests) if (!r.endTime && !r.error) inflight.set(r.requestId, r);
  }
  updateBadge();
});

let saveTimer = null;
function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    chrome.storage.local.set({ [STORAGE_KEY]: state });
    broadcast();
  }, 250);
}

function broadcast() {
  chrome.runtime.sendMessage({ type: 'state-changed' }).catch(() => {});
}

function updateBadge() {
  const count = state.transactions.length;
  if (state.recording) {
    chrome.action.setBadgeBackgroundColor({ color: state.paused ? '#b07d00' : '#d93025' });
    chrome.action.setBadgeText({ text: state.paused ? 'II' : count ? String(count) : 'REC' });
  } else {
    chrome.action.setBadgeText({ text: '' });
  }
}

const isCapturing = (tabId) => state.recording && !state.paused && (state.settings.recordAllTabs ? tabId >= 0 : state.tabs.includes(tabId));

function newTransaction(tabId, kind, label, extra = {}) {
  const seq = ++state.txSeq;
  const tx = {
    id: `tx${Date.now()}_${seq}`,
    seq,
    kind,
    label,
    tabId,
    startTime: Date.now(),
    url: extra.url || '',
    value: extra.value,
    requests: [],
  };
  state.transactions.push(tx);
  state.lastAction[tabId] = { time: tx.startTime, txId: tx.id };
  updateBadge();
  save();
  return tx;
}

function currentTransaction(tabId) {
  const last = state.lastAction[tabId];
  const tx = last && state.transactions.find((t) => t.id === last.txId);
  return tx || null;
}

function shouldRecordUrl(details) {
  const url = details.url;
  if (!/^https?:/i.test(url)) return false;
  // Skip the extension's own fetches, but not page loads it starts (recording 2 opens its first page).
  if (details.type !== 'main_frame' && details.initiator && details.initiator.startsWith('chrome-extension://')) return false;
  if (state.settings.excludeStatic && STATIC_TYPES.has(details.type)) return false;
  if (filters.include.length && !filters.include.some((re) => re.test(url))) return false;
  if (filters.exclude.some((re) => re.test(url))) return false;
  return true;
}

function decodeBody(requestBody) {
  if (!requestBody) return null;
  if (requestBody.formData) return { formData: requestBody.formData };
  if (requestBody.raw) {
    const parts = [];
    let hasFile = false;
    for (const p of requestBody.raw) {
      if (p.bytes) parts.push(new TextDecoder('utf-8').decode(p.bytes));
      else if (p.file) {
        hasFile = true;
        parts.push(`<file:${p.file}>`);
      }
    }
    return { raw: parts.join(''), hasFile };
  }
  if (requestBody.error) return { error: requestBody.error };
  return null;
}

// ---- webRequest listeners (registered synchronously at top level) ----

const FILTER = { urls: ['<all_urls>'] };

chrome.webRequest.onBeforeRequest.addListener(
  (d) => {
    ready.then(() => {
      if (isCapturing(d.tabId) && /^https?:/i.test(d.url)) {
        const host = new URL(d.url).hostname;
        if (!state.hostsSeen.includes(host)) state.hostsSeen.push(host);
      }
      if (!isCapturing(d.tabId) || !shouldRecordUrl(d)) return;
      if (inflight.has(d.requestId)) return; // redirect hop: same requestId continues
      let tx = currentTransaction(d.tabId);
      const last = state.lastAction[d.tabId];
      if (d.type === 'main_frame' && (!last || d.timeStamp - last.time > NAV_ACTION_WINDOW_MS)) {
        let label = d.url;
        try {
          const u = new URL(d.url);
          label = u.host + (u.pathname === '/' ? '' : u.pathname);
        } catch (_) {}
        tx = newTransaction(d.tabId, 'navigate', label, { url: d.url });
      } else if (!tx) {
        tx = newTransaction(d.tabId, 'navigate', 'page', { url: d.url });
      }
      const rec = {
        requestId: d.requestId,
        method: d.method,
        url: d.url,
        type: d.type,
        frameId: d.frameId,
        startTime: d.timeStamp,
        body: decodeBody(d.requestBody),
        requestHeaders: [],
        redirects: [],
      };
      tx.requests.push(rec);
      inflight.set(d.requestId, rec);
      save();
    });
  },
  FILTER,
  ['requestBody']
);

chrome.webRequest.onSendHeaders.addListener(
  (d) => {
    ready.then(() => {
      const rec = inflight.get(d.requestId);
      if (!rec) return;
      // Keep the headers from the first hop only; redirect hops are replayed by JMeter itself.
      if (!rec.requestHeaders.length) {
        rec.requestHeaders = (d.requestHeaders || []).filter((h) => !SKIP_HEADERS.has(h.name.toLowerCase()) && !h.name.startsWith(':'));
        rec.requestHeaderBytes = (d.requestHeaders || []).reduce((n, h) => n + h.name.length + (h.value || '').length + 4, 0);
      }
    });
  },
  FILTER,
  ['requestHeaders', 'extraHeaders']
);

chrome.webRequest.onBeforeRedirect.addListener(
  (d) => {
    ready.then(() => {
      const rec = inflight.get(d.requestId);
      if (rec) rec.redirects.push({ statusCode: d.statusCode, redirectUrl: d.redirectUrl });
    });
  },
  FILTER
);

chrome.webRequest.onResponseStarted.addListener(
  (d) => {
    ready.then(() => {
      const rec = inflight.get(d.requestId);
      if (rec && !rec.responseStartTime) rec.responseStartTime = d.timeStamp;
    });
  },
  FILTER
);

chrome.webRequest.onCompleted.addListener(
  (d) => {
    ready.then(() => {
      const rec = inflight.get(d.requestId);
      if (!rec) return;
      inflight.delete(d.requestId);
      rec.endTime = d.timeStamp;
      rec.statusCode = d.statusCode;
      rec.statusLine = d.statusLine;
      rec.fromCache = d.fromCache;
      rec.finalUrl = d.url;
      rec.responseHeaders = d.responseHeaders || [];
      matchBodies();
      save();
    });
  },
  FILTER,
  ['responseHeaders', 'extraHeaders']
);

chrome.webRequest.onErrorOccurred.addListener(
  (d) => {
    ready.then(() => {
      const rec = inflight.get(d.requestId);
      if (!rec) return;
      inflight.delete(d.requestId);
      rec.endTime = d.timeStamp;
      rec.error = d.error;
      save();
    });
  },
  FILTER
);

// Follow popups / new tabs opened from a recorded tab.
chrome.tabs.onCreated.addListener((tab) => {
  ready.then(() => {
    if (state.recording && tab.openerTabId != null && state.tabs.includes(tab.openerTabId) && !state.tabs.includes(tab.id)) {
      state.tabs.push(tab.id);
      attachDebugger(tab.id);
      save();
    }
  });
});

// ---- Response bodies (optional) ----
// chrome.webRequest never exposes response bodies, so when "Capture response
// bodies" is on we attach Chrome's debugger to the recorded tabs and read
// each body over the DevTools protocol. Chrome shows a "started debugging
// this browser" bar meanwhile. Bodies are matched to webRequest records by
// tab, method and URL.
const MAX_BODY_CHARS = 2 * 1024 * 1024;
const attached = new Set();
const cdpRequests = new Map(); // `${tabId}:${cdpRequestId}` -> { method, url, mimeType }
let pendingBodies = []; // bodies not yet matched to a record

async function attachDebugger(tabId) {
  if (!state.settings.captureResponses || attached.has(tabId)) return;
  try {
    await chrome.debugger.attach({ tabId }, '1.3');
    attached.add(tabId);
    await chrome.debugger.sendCommand({ tabId }, 'Network.enable', { maxTotalBufferSize: 100 * 1024 * 1024, maxResourceBufferSize: 10 * 1024 * 1024 });
    state.captureError = null;
  } catch (e) {
    state.captureError = `Response bodies are not being captured: ${e.message}`;
    save();
  }
}

async function detachAll(extraTabs = []) {
  // Include recorded tabs too: the in-memory set is lost if the worker restarted.
  for (const tabId of new Set([...attached, ...state.tabs, ...extraTabs])) {
    attached.delete(tabId);
    await chrome.debugger.detach({ tabId }).catch(() => {});
  }
  cdpRequests.clear();
}

chrome.debugger.onDetach.addListener((source, reason) => {
  attached.delete(source.tabId);
  ready.then(() => {
    if (state.recording && reason === 'canceled_by_user') {
      state.captureError = 'Response capture was cancelled from the debugging bar; responses after this point are not stored.';
      save();
    }
  });
});

chrome.debugger.onEvent.addListener((source, method, params) => {
  const tabId = source.tabId;
  const key = `${tabId}:${params.requestId}`;
  if (method === 'Network.requestWillBeSent') {
    // Redirects reuse the requestId; keep the latest URL.
    cdpRequests.set(key, { method: params.request.method, url: params.request.url });
  } else if (method === 'Network.responseReceived') {
    const r = cdpRequests.get(key);
    if (r) {
      r.url = params.response.url || r.url;
      r.mimeType = params.response.mimeType;
      r.status = params.response.status;
    }
  } else if (method === 'Network.loadingFinished') {
    const r = cdpRequests.get(key);
    cdpRequests.delete(key);
    if (!r || !/^https?:/i.test(r.url)) return;
    chrome.debugger
      .sendCommand({ tabId }, 'Network.getResponseBody', { requestId: params.requestId })
      .then((res) => {
        let body = res.body || '';
        let binary = false;
        if (res.base64Encoded) {
          binary = !/^(text\/|application\/(json|xml|javascript|x-www-form-urlencoded)|.*\+(json|xml))/i.test(r.mimeType || '');
          if (!binary) {
            try {
              body = new TextDecoder('utf-8').decode(Uint8Array.from(atob(body), (c) => c.charCodeAt(0)));
            } catch (_) {
              binary = true;
            }
          }
        }
        pendingBodies.push({ tabId, method: r.method, url: r.url, body: binary ? null : body.slice(0, MAX_BODY_CHARS), truncated: !binary && body.length > MAX_BODY_CHARS, binary, mimeType: r.mimeType, time: Date.now() });
        ready.then(matchBodies);
      })
      .catch(() => {}); // redirects, 204s, evicted buffers: no body
  } else if (method === 'Network.loadingFailed') {
    cdpRequests.delete(key);
  }
});

function matchBodies() {
  if (!pendingBodies.length) return;
  const now = Date.now();
  let changed = false;
  pendingBodies = pendingBodies.filter((b) => {
    for (let i = state.transactions.length - 1; i >= 0; i--) {
      const tx = state.transactions[i];
      if (tx.tabId !== b.tabId && !state.settings.recordAllTabs) continue;
      const rec = tx.requests.find(
        (r) =>
          !r.hasResponseBody &&
          // After a 301/302/303 the browser switches to GET, so a redirected request matches on its final URL alone.
          ((r.method === b.method && (r.finalUrl === b.url || r.url === b.url)) ||
            ((r.redirects || []).length && (r.finalUrl === b.url || r.redirects.some((x) => x.redirectUrl === b.url))))
      );
      if (rec) {
        rec.hasResponseBody = true;
        rec.responseBody = b.body;
        rec.responseBinary = b.binary;
        rec.responseTruncated = b.truncated;
        rec.responseMimeType = b.mimeType;
        changed = true;
        return false;
      }
    }
    return now - b.time < 60000; // keep briefly in case webRequest reports the request later
  });
  if (changed) save();
}

// Chrome can swap a tab's contents for a prerendered page under a new tab id.
chrome.tabs.onReplaced.addListener((addedTabId, removedTabId) => {
  ready.then(() => {
    if (!state.tabs.includes(removedTabId)) return;
    state.tabs = state.tabs.map((id) => (id === removedTabId ? addedTabId : id));
    if (state.lastAction[removedTabId]) state.lastAction[addedTabId] = state.lastAction[removedTabId];
    save();
  });
});

// ---- messages from content scripts and the popup ----

function handleUserAction(msg, sender) {
  const tabId = sender.tab ? sender.tab.id : -1;
  if (!isCapturing(tabId)) return;
  const last = state.lastAction[tabId];
  const prev = currentTransaction(tabId);
  if (
    (msg.kind === 'submit' || msg.kind === 'enter') &&
    prev &&
    last &&
    msg.time - last.time < MERGE_WINDOW_MS &&
    prev.requests.length === 0 &&
    (prev.kind === 'click' || prev.kind === 'enter' || prev.kind === 'input')
  ) {
    // Same gesture (e.g. clicking "Login" fires click then submit). Keep the
    // first, more descriptive transaction, but refresh the window.
    last.time = msg.time;
    return;
  }
  const tx = newTransaction(tabId, msg.kind, msg.label || msg.kind, { url: msg.url, value: msg.value });
  // The message can arrive after the requests the action triggered (e.g. a
  // link click whose navigation is reported first). Pull those into this
  // transaction, and drop an auto-created navigation transaction left empty.
  if (prev && msg.time) {
    tx.startTime = Math.min(tx.startTime, msg.time);
    const moved = prev.requests.filter((r) => r.startTime >= msg.time);
    if (moved.length) {
      prev.requests = prev.requests.filter((r) => r.startTime < msg.time);
      tx.requests.push(...moved);
      if (prev.kind === 'navigate' && !prev.requests.length && prev.startTime >= msg.time - 50) {
        state.transactions = state.transactions.filter((t) => t !== prev);
      }
    }
  }
}

// Pages opened before the extension was installed or reloaded have no (live)
// content script, so clicks there would be missed until a page reload.
async function injectContentScript(tabId) {
  try {
    await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, files: ['content.js'] });
  } catch (_) {
    // chrome:// pages, the Web Store, etc. cannot be scripted; nothing to record there anyway.
  }
}

// First page of a recording: where recording 2 starts when it opens a fresh tab.
function firstUrl(transactions) {
  for (const tx of transactions) {
    const main = tx.requests.find((r) => r.type === 'main_frame');
    if (main) return main.url;
  }
  return transactions[0] && transactions[0].url;
}

// Parent domains a cookie for `host` may be set on (a.b.example.com -> b.example.com, example.com).
function cookieDomains(host) {
  const parts = host.split('.');
  if (/^[\d.]+$/.test(host) || parts.length < 2) return [host];
  const out = [];
  for (let i = 0; i <= parts.length - 2; i++) out.push(parts.slice(i).join('.'));
  return out;
}

// Signs the browser out of every site recording 1 touched: removes their
// cookies from the tab's cookie store (works in incognito too) and their
// local storage, IndexedDB, cache and service workers.
async function clearSession(hosts, tabId) {
  let storeId;
  try {
    const stores = await chrome.cookies.getAllCookieStores();
    const store = tabId != null && stores.find((s) => s.tabIds.includes(tabId));
    if (store) storeId = store.id;
  } catch (_) {}
  const domains = [...new Set(hosts.flatMap(cookieDomains))];
  const seen = new Set();
  let removed = 0;
  for (const domain of domains) {
    const cookies = await chrome.cookies.getAll(storeId ? { domain, storeId } : { domain }).catch(() => []);
    for (const c of cookies) {
      const key = `${c.domain}|${c.path}|${c.name}`;
      if (seen.has(key)) continue;
      seen.add(key);
      const url = `http${c.secure ? 's' : ''}://${c.domain.replace(/^\./, '')}${c.path}`;
      if (await chrome.cookies.remove({ url, name: c.name, storeId: c.storeId }).catch(() => null)) removed++;
    }
  }
  const origins = hosts.flatMap((h) => [`https://${h}`, `http://${h}`]);
  if (origins.length) {
    await chrome.browsingData
      .remove({ origins }, { cacheStorage: true, cache: true, fileSystems: true, indexedDB: true, localStorage: true, serviceWorkers: true, webSQL: true })
      .catch(() => {});
  }
  return `Signed out before recording 2: removed ${removed} cookies and site data for ${hosts.length} sites, and opened a fresh tab.`;
}

// The tab the user is working in (the popup may be popped out into its own window).
async function targetTab() {
  try {
    const win = await chrome.windows.getLastFocused({ windowTypes: ['normal'] });
    const [tab] = await chrome.tabs.query({ active: true, windowId: win.id });
    return tab;
  } catch (_) {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    return tab;
  }
}

async function handlePopup(msg) {
  switch (msg.type) {
    case 'get-state':
      return state;
    case 'start': {
      let tab = msg.tabId != null ? { id: msg.tabId } : await targetTab();
      const keep = msg.append && state.transactions.length;
      let openUrl = null;
      const settings = state.settings;
      // mode: 'single' | 'dual1' | 'dual2'. Recording 2 of a dual recording
      // names its steps after recording 1, passed in as msg.baseline.
      if (!keep) {
        const mode = msg.mode || 'single';
        // Keep recording 1 so both recordings can be downloaded together at the end.
        let run1 = null;
        if (mode === 'dual2') {
          run1 =
            state.dual === 1
              ? { transactions: state.transactions, startedAt: state.startedAt, hostsSeen: state.hostsSeen, startUrl: firstUrl(state.transactions) }
              : { ...state.run1, hostsSeen: [...new Set([...(state.run1.hostsSeen || []), ...state.hostsSeen])] };
        }
        const prevTabs = state.tabs;
        state = freshState(settings, mode === 'dual2' ? msg.baseline : null, mode === 'dual1' ? 1 : mode === 'dual2' ? 2 : null);
        state.run1 = run1;
        // SSO: start recording 2 signed out, in a fresh tab (new sessionStorage),
        // at recording 1's first page, so the login is recorded again.
        if (mode === 'dual2' && settings.cleanSessionForRun2 && run1) {
          await detachAll(prevTabs);
          const src = tab && tab.id != null ? await chrome.tabs.get(tab.id).catch(() => null) : null;
          state.sessionNote = await clearSession(run1.hostsSeen || [], src ? src.id : null);
          tab = await chrome.tabs.create({ url: 'about:blank', active: true, ...(src ? { windowId: src.windowId } : {}) });
          openUrl = run1.startUrl;
        } else state.sessionNote = null;
      }
      state.recording = true;
      state.paused = false;
      state.startedAt = state.startedAt || Date.now();
      if (tab && !state.tabs.includes(tab.id)) state.tabs.push(tab.id);
      if (tab) await injectContentScript(tab.id);
      state.captureError = null;
      for (const id of state.tabs) await attachDebugger(id);
      if (openUrl) await chrome.tabs.update(tab.id, { url: openUrl });
      break;
    }
    case 'pause':
      state.paused = !state.paused;
      break;
    case 'stop':
      state.recording = false;
      state.paused = false;
      await detachAll();
      break;
    case 'clear':
      await detachAll();
      const run1 = state.run1;
      state = freshState(state.settings, state.baseline, state.dual);
      state.run1 = run1;
      inflight = new Map();
      break;
    case 'add-transaction': {
      const tab = await targetTab();
      const tabId = tab ? tab.id : -1;
      const tx = newTransaction(tabId, 'manual', msg.name || 'Transaction');
      if (msg.name) tx.customName = msg.name;
      tx.manual = true;
      break;
    }
    case 'rename-transaction': {
      const tx = state.transactions.find((t) => t.id === msg.id);
      if (tx) tx.customName = msg.name || undefined;
      break;
    }
    case 'delete-transaction':
      state.transactions = state.transactions.filter((t) => t.id !== msg.id);
      break;
    case 'merge-into-previous': {
      const i = state.transactions.findIndex((t) => t.id === msg.id);
      if (i > 0) {
        const [tx] = state.transactions.splice(i, 1);
        state.transactions[i - 1].requests.push(...tx.requests);
        for (const [tabId, last] of Object.entries(state.lastAction)) if (last.txId === tx.id) last.txId = state.transactions[i - 1].id;
      }
      break;
    }
    case 'delete-request':
      for (const tx of state.transactions) tx.requests = tx.requests.filter((r) => r.requestId !== msg.requestId);
      break;
    case 'set-baseline':
      state.baseline = msg.baseline || null;
      break;
    case 'update-settings':
      state.settings = { ...state.settings, ...msg.settings };
      filters = buildFilters(state.settings);
      break;
    default:
      return undefined;
  }
  updateBadge();
  save();
  return state;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'user-action') {
    ready.then(() => handleUserAction(msg, sender));
    return false;
  }
  if (msg.type === 'state-changed') return false;
  ready.then(() => handlePopup(msg)).then(sendResponse, (e) => sendResponse({ error: String(e) }));
  return true;
});
