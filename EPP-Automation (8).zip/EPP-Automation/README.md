# EPP Automation

A local web page that runs the EPP flows for you:

1. Upload JMX scripts to Git (`src/test/jmeter`), then check each file is there
2. Upload CSV test data files to Git (`target/jmeter/bin`), then check each file is there
3. Create a simulation per JMX script, with `SmokeTest_<name>` and `LoadTest_<name>` scenarios
4. Create batch (on hold, shown but disabled)

You sign in once per run and are signed out at the end, whichever steps you pick. The browser is hidden
by default and the page shows plain-language progress. Tick **Show browser** to watch it.

## Run it (Windows)

Needs only Java 8 or newer (`java -version`) and Microsoft Edge or Google Chrome. Node.js, which Playwright runs on,
is shipped in the `node` folder as `node.exe.gz.001` and `node.exe.gz.002`, so that every file stays under GitHub's
25 MB upload limit. The app joins them into `node\node.exe` on the first run.

1. Unzip `EPP-Automation.zip`, `EPP-Node-part1.zip` and `EPP-Node-part2.zip` into the same folder, such as `C:\`.
   You should end up with `C:\EPP-Automation\epp-automation.jar` and `C:\EPP-Automation\node\node.exe.gz.001` and `.002`.
2. Double-click `run.bat`. The page opens at http://localhost:8080. Keep the black window open while you use it.
3. Fill in the Global Parameters and one row per scenario, pick the steps and press **Run**.

The first run takes about 20 seconds longer while Node.js and Playwright unpack. Nothing is downloaded.
To use Chrome instead of Edge, set `browser.channel=chrome` in `epp-automation.properties`.

## What each step does

- **Sign in:** opens EPP in a private (incognito-style) window and signs in with UserName and Password.
  If Microsoft asks for an extra step such as an authenticator approval, the run stops and asks you to tick
  **Show browser** and run again, so you can approve it in the window.
- **Application:** opens the application dropdown in the black bar and picks Application Name.
- **Flows 1 and 2:** clicks "Access your GitHub Repository", continues through single sign-on, opens the
  upload page of the folder, adds all files, commits to `main`, then opens each file's page to confirm it
  exists. Any missing file is listed and the run stops.
- **Flow 3:** Test Execution > Simulations > ADD SIMULATION with Simulation Name = file name without `.jmx`
  and JMeter Test Plan = file name. It switches to 100 rows per page when needed, opens the simulation's
  scenarios, and creates the Smoke and Load scenarios (Users, TG1.RampUpPeriod, TG1.Duration, load generators,
  CPU cores, heap memory). Records that already exist are skipped, so a run can be repeated safely.
- **Sign out:** avatar at the top right > Logout.

Every step saves a screenshot under `runs\<run id>\`. If a run stops, open **Screenshots** on the page to see where.

## Settings

To change a setting, edit `epp-automation.properties` next to the jar:

| Setting | Default | Meaning |
| --- | --- | --- |
| `epp.url` | https://performance.optum.com | EPP portal |
| `github.branch` | main | Branch the files are committed to |
| `github.jmxFolder` | src/test/jmeter | Folder for JMX scripts |
| `github.csvFolder` | target/jmeter/bin | Folder for CSV files |
| `browser.channel` | msedge | `msedge` or `chrome` |
| `server.port` | 8080 | Port of the local page |
| `timeout.step.ms` | 30000 | How long to wait for a page element |
| `timeout.long.ms` | 180000 | How long to wait for sign-in, uploads and commits |

## Building from source

`mvn package` creates `target/epp-automation.jar` (compiled for Java 8; Playwright for Java, Javalin 4). That jar holds Playwright
drivers for every OS (about 200 MB). The shipped jar keeps only `driver/win32_x64` and drops `node.exe`, `lib/vite`,
`types`, `api.json` and `PrintDeps.exe`, which brings it to about 10 MB:

```
zip -d target/epp-automation.jar "driver/linux/*" "driver/linux-arm64/*" "driver/mac/*" "driver/mac-arm64/*" "driver/win32_x64/node.exe" "driver/win32_x64/package/lib/vite/*" "driver/win32_x64/package/bin/PrintDeps.exe" "driver/win32_x64/package/types/*" "driver/win32_x64/package/api.json"
```
The code is in `src/main/java/com/epp/automation`:

- `App.java`: the local web server and the run queue
- `EppFlows.java`: every browser step
- `src/main/resources/public/index.html`: the page
