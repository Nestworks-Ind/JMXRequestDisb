@echo off
rem Starts EPP Automation and opens it in the browser. Keep this window open while you use it.
cd /d "%~dp0"
java -jar epp-automation.jar
pause
