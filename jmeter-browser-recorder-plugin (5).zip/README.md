# JMeter Browser Recorder

A JMeter plugin that records a browser flow **without setting up a proxy**.
Click **Start** and JMeter opens Chrome or Edge. You use the site, then click
**Stop**. The plugin saves a `.jmx` with one Transaction Controller per click
or entry, plus an XML `.jtl` that holds the response bodies.

It does the same job as the JMX Recorder Chrome extension, but nothing is
installed into the browser. That makes it usable where company policy blocks
extensions.

## Install

1. Copy `jmeter-browser-recorder.jar` into `<JMeter>/lib/ext/`.
2. Restart JMeter.
3. Open **Tools > Browser Recorder (no proxy)**.

Requirements:

- JMeter 5.x.
- Java 8 or newer (the same Java that runs JMeter).
- Google Chrome or Microsoft Edge (Chromium-based).

## Record

1. Choose the **Browser**. Chrome and Edge are found automatically. For any
   other Chromium browser, or a non-standard install, pick **Custom path** and
   browse to the executable.
2. Enter the **Start URL**, which is the page the browser opens on. Under it,
   **Save files to** (with **Browse...**) chooses where the files go.
3. Optionally fill in **Parameters** (name and value) for data you will type,
   such as `username` = `alice`. In the script each value is replaced with
   `${username}` and added to User Defined Variables.
4. Click **Start**. A new browser window opens. Use the site as normal.
   - Each click, field entry, Enter key, form submit, or typed URL becomes a
     transaction, for example `T04 - Click Sign in`. Its requests are named
     `002 /login`.
   - **Name next action** starts a transaction with your own name.
   - **Pause** / **Resume** stops and restarts capturing.
5. Click **Stop**, or just close the browser window. Nothing is lost either way.
   - Both files are saved to the output folder (default `~/jmx-recorder`).
   - The recording is also added to the open test plan as a Thread Group.
     You can turn that off on the *Test plan* tab.

The browser opens as an incognito (Chrome) or InPrivate (Edge) window. You can
turn that off with the checkbox under Browser.

On top of that, each recording uses a brand-new, temporary browser profile, which is deleted
afterwards. So every recording starts signed out (good for SSO), and your own
browser profile, cookies and passwords are never touched.

## Dual recording (to find dynamic values)

1. Tick **Dual recording** next to Start.
2. Record the flow and click **Stop**. Recording 1 is saved right away.
3. Optionally change the parameter values to the second user's data.
4. Click **Start recording 2**. A new, signed-out browser opens at the same
   start page. Repeat the same steps and click **Stop**.

Recording 2 gets the same transaction and request names as recording 1. You
can then compare the two `.jmx` / `.jtl` files in your own tool.

The output folder will contain:

- `<plan>_<time>_recording1.jmx` and `.jtl`
- `<plan>_<time>_recording2.jmx` and `.jtl`
- `<plan>_<time>_both.zip`, which holds all four files

In the test plan, recording 2 is added as a disabled Thread Group, so running
the plan does not replay both.

## What the .jmx contains

The .jmx is built from the Recording template **of the JMeter you run it in**,
`<JMeter>/bin/templates/recording.jmx`. Any customisations in that template
(extra config elements, thread settings, listeners, ...) are kept as they are.
To use another template file, pick it under *Test plan > Recording template*.

The plugin makes only these changes to the template:

- The **Recording Controller** is replaced by the recorded Transaction
  Controllers, so the Thread Group holds the recorded transactions directly.
  No timers are added.
- `host` and `scheme` are filled in (the template's `[=hostToRecord]` /
  `[=schemeToRecord]` placeholders), and your parameters are added to the
  template's User Defined Variables.
- The Test Plan gets the name you entered. In dual mode, the Thread Group is
  named "Recording 1" / "Recording 2".

Transactions that have no HTTP requests, such as typing into a field, are left
out. Tick *Keep transactions without HTTP requests* on the Test plan tab if you
want them. If no template is found, the plugin falls back to a built-in copy of
the standard layout.

Request headers are cleaned up so the script replays correctly:

- `Accept-Encoding` becomes `gzip, deflate`, because JMeter cannot decode zstd
  or brotli.
- Conditional headers (`If-None-Match`, `If-Modified-Since`, ...) are dropped.
- `Cookie`, `Host`, `Content-Length` and connection headers are left to JMeter.

## Options

- **Test plan tab:**
  - recording template, plan name, threads / ramp-up / loops (used only without a template);
  - response bodies in the .jtl;
  - skip static resources;
  - keep transactions without HTTP requests (off by default);
  - header managers;
  - `${host}`/`${scheme}` variables;
  - clear cookies each iteration;
  - add the recording to the open plan.
- **Filters tab:**
  - URL exclude/include regular expressions. Analytics and browser-update
    traffic are excluded by default.
  - Extra browser switches, one per line, for example
    `--ignore-certificate-errors`, `--proxy-server=host:port` or `--lang=en-GB`.

Settings are remembered between JMeter sessions.

## If the browser does not start

The plugin starts the browser with `--remote-debugging-port` and a temporary
`--user-data-dir`, and talks to it over the DevTools protocol on 127.0.0.1.

- If your company sets the Chrome/Edge policy **RemoteDebuggingAllowed** to
  false, the browser refuses that switch. Ask IT to allow it for this use, or
  try the other browser, since the policies are often set per browser.
- The browser uses your normal system proxy settings. To force a proxy, add
  `--proxy-server=...` under Filters > Extra browser switches.
- Details of any error are written to `jmeter.log`.

## Limits

- File-upload contents are not captured, only the request as sent. Use the
  sampler's *Files Upload* tab.
- WebSocket traffic is not recorded.
- `bytes` and timings in the .jtl come from the browser. They describe the
  recording session, not a load test.

## Build from source

```sh
JMETER_HOME=/path/to/apache-jmeter-5.6.3 ./build.sh   # -> build/jmeter-browser-recorder.jar
```

Tests (Node + Playwright, Chromium):

- `test/e2e-plugin.mjs` records the demo app in `test/server.mjs`:
  - `MODE=single` or `MODE=dual` runs headless;
  - `GUI=1` runs the real JMeter window under Xvfb.
- `test/run-in-jmeter.sh` replays a recorded .jmx in JMeter.
- `test/check-jtl.groovy` loads a .jtl with JMeter's own SaveService.
